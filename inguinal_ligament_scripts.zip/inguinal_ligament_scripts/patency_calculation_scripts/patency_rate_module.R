# patency_rate_workflow.R

# This overarching script is responsible for performing patency calculations
# on the provided cohort of data/patients. The code assumes that, at the time of
# the followup startdate, the patient begins in Primary Patency. In addition,
# the follow patency calculation code is configured to calculate patency for lower extremity conditions
# only. The code assumes that either left lower extremity or IVC procedures count as a re-intervention
# toward left leg patency calculations, while either right lower extremity or IVC procedures count as a
# re-intervention toward right leg patency calculations.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

source(paste(patency.calculation.code.directory, 'identify_thrombotic_complications.R', sep = '/'))

# Procedures that do not count toward patency calculations
non.patency.procedure.list = non.patency.procedures %>%
  select(Record.ID.Procedure.Number.Identifier) %>%
  unique()

non.patency.procedure.list = non.patency.procedure.list[, 1]

source(paste(patency.calculation.code.directory, 'identify_balloon_angioplasty_procedures.R', sep = '/'))

source(paste(patency.calculation.code.directory, 'identify_stenting_procedures.R', sep = '/'))

source(paste(patency.calculation.code.directory, 'identify_recanalization_procedures.R', sep = '/'))

source(paste(patency.calculation.code.directory, 'identify_thrombectomy_procedures.R', sep = '/'))

source(paste(patency.calculation.code.directory, 'identify_thrombolysis_procedures.R', sep = '/'))

source(paste(patency.calculation.code.directory, 'identify_last_patency_procedure.R', sep = '/'))

source(paste(patency.calculation.code.directory, 'determine_vein_imaging_data.R', sep = '/'))

source(paste(patency.calculation.code.directory, 'identify_permanent_occlusion_status.R', sep = '/'))

source(paste(patency.calculation.code.directory, 'calculate_patency_status.R', sep = '/'))