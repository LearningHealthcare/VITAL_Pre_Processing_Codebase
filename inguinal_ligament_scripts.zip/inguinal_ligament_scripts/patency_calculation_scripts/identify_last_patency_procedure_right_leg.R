# identify_last_patency_procedure_right_leg.R

# This script identifies the latest right leg procedure that counts toward patency calculations
# for a cohort of patients.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

right.leg.last.patency.procedure.date = rep(NA, times = nrow(patency.rate.dataframe))

right.leg.last.patency.procedure.span = rep(NA, times = nrow(patency.rate.dataframe))

for(i in 1:nrow(patency.rate.dataframe)){
  patency.rate.patient.data = patency.rate.dataframe[i, ]
  if(!is.na(patency.rate.dataframe$Right.Limb.Status[i])){
    balloon.angioplasty.right.leg.date = patency.rate.patient.data$last.post.start.date.balloon.angioplasty.Right.Leg[1]
    # Examine balloon angioplasty re-intervention
    if(!is.na(balloon.angioplasty.right.leg.date)){
      right.leg.last.patency.procedure.date[i] = as.character(balloon.angioplasty.right.leg.date)
      right.leg.last.patency.procedure.span[i] = round(as.numeric(difftime(balloon.angioplasty.right.leg.date, 
          patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
    }
    stent.right.leg.date = patency.rate.patient.data$last.post.start.date.stenting.Right.Leg[1]
    # Examine stent re-intervention
    if(!is.na(stent.right.leg.date)){
      stent.right.leg.date = as.Date(stent.right.leg.date)
      stent.span = round(as.numeric(difftime(stent.right.leg.date, 
                                             patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(right.leg.last.patency.procedure.span[i]) | (right.leg.last.patency.procedure.span[i] < stent.span)){
        right.leg.last.patency.procedure.span[i] = stent.span
        right.leg.last.patency.procedure.date[i] = as.character(stent.right.leg.date)
      }
    }
    recanalization.right.leg.date = patency.rate.patient.data$last.post.start.date.recanalization.Right.Leg[1]
    # Examine Recanalization re-intervention
    if(!is.na(recanalization.right.leg.date)){
      recanalization.right.leg.date = as.Date(recanalization.right.leg.date)
      recanalization.span = round(as.numeric(difftime(recanalization.right.leg.date, 
                                                      patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(right.leg.last.patency.procedure.span[i]) | (right.leg.last.patency.procedure.span[i] < recanalization.span)){
        right.leg.last.patency.procedure.span[i] = recanalization.span
        right.leg.last.patency.procedure.date[i] = as.character(recanalization.right.leg.date)
      }
    }
    thrombectomy.right.leg.date = patency.rate.patient.data$last.post.start.date.thrombectomy.Right.Leg[1]
    # Examine thrombectomy re-intervention
    if(!is.na(thrombectomy.right.leg.date)){
      thrombectomy.right.leg.date = as.Date(thrombectomy.right.leg.date)
      thrombectomy.span = round(as.numeric(difftime(thrombectomy.right.leg.date, 
                                                    patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(right.leg.last.patency.procedure.span[i]) | (right.leg.last.patency.procedure.span[i] < thrombectomy.span)){
        right.leg.last.patency.procedure.span[i] = thrombectomy.span
        right.leg.last.patency.procedure.date[i] = as.character(thrombectomy.right.leg.date)
      }
    }
    # Examine thrombolysis re-intervention
    thrombolysis.right.leg.date = patency.rate.patient.data$last.post.start.date.thrombolysis.Right.Leg[1]
    if(!is.na(thrombolysis.right.leg.date)){
      thrombolysis.right.leg.date = as.Date(thrombolysis.right.leg.date)
      thromobolysis.span = round(as.numeric(difftime(thrombolysis.right.leg.date, 
          patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(right.leg.last.patency.procedure.span[i]) | (right.leg.last.patency.procedure.span[i] < thromobolysis.span)){
        right.leg.last.patency.procedure.span[i] = thromobolysis.span
        right.leg.last.patency.procedure.date[i] = as.character(thrombolysis.right.leg.date)
      }
    }
  }
}

patency.rate.dataframe = cbind.data.frame(patency.rate.dataframe, right.leg.last.patency.procedure.date, right.leg.last.patency.procedure.span)