# identify_stenting_procedures.R

# This script identifies stenting procedures that occur after the followup-start date.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

stent.location.date.procedure.data$Stent.Date = stent.location.date.procedure.data$proc_date

stent.location.date.procedure.data = select(stent.location.date.procedure.data, -proc_date)

# Dataframe containing Stenting reintervention data
stenting.reintervention.data = patency.rate.dataframe %>%
  select(record_id, Followup.Start.Date, Left.Limb.Status, Right.Limb.Status) %>%
  left_join(stent.location.date.procedure.data, by = "record_id") %>%
  # Remove procedures that do not count toward patency calculations
  filter(!(Record.ID.Procedure.Identifier) %in% non.patency.procedure.list) %>%
  # Span between Stent Date and Followup start date
  mutate(Stenting.Followup.Span = round(as.numeric(difftime(Stent.Date, 
        Followup.Start.Date, units = "days")), digits = 0)) %>%
  filter(Stenting.Followup.Span > 0) %>%
  select(-Stenting.Followup.Span, -Followup.Start.Date)

# patients with stenting procedures
stenting.patients = stenting.reintervention.data %>%
  select(record_id) %>%
  unique()

stenting.patients = stenting.patients[, 1]

first.post.start.date.stenting.Left.Leg = rep(NA, times = length(stenting.patients))

first.post.start.date.stenting.Right.Leg = rep(NA, times = length(stenting.patients))

last.post.start.date.stenting.Left.Leg = rep(NA, times = length(stenting.patients))

last.post.start.date.stenting.Right.Leg = rep(NA, times = length(stenting.patients))

for(i in 1:length(stenting.patients)){
  stenting.patient = stenting.patients[i]
  stenting.patient.data = stenting.reintervention.data %>%
    filter(record_id == stenting.patient) %>%
    arrange(Stent.Date)
  # Check if Left Leg is being considered in analysis
  if(!is.na(stenting.patient.data$Left.Limb.Status[1])){
    stenting.patient.left.leg.data = filter(stenting.patient.data, Vein %in% left.leg.veins)
    if(nrow(stenting.patient.left.leg.data) > 0){
      # Identify first left leg stenting procedure
      stenting.patient.left.leg.data = arrange(stenting.patient.left.leg.data, Stent.Date)
      first.stent.date = as.character(stenting.patient.left.leg.data$Stent.Date[1])
      first.post.start.date.stenting.Left.Leg[i] = first.stent.date
      stenting.patient.left.leg.data = stenting.patient.left.leg.data %>%
        mutate(First.Stenting.Procedure.Span = round(as.numeric(difftime(Stent.Date, as.Date(first.stent.date))), digits = 0)) %>%
        filter(First.Stenting.Procedure.Span >= 0) %>%
        arrange(desc(Stent.Date))
      if(nrow(stenting.patient.left.leg.data) > 0){
        last.post.start.date.stenting.Left.Leg[i] = as.character(stenting.patient.left.leg.data$Stent.Date[1])
      }
    }
  }
  # Check if Right Leg is being considered in analysis
  if(!is.na(stenting.patient.data$Right.Limb.Status[1])){
    stenting.patient.right.leg.data = filter(stenting.patient.data, Vein %in% right.leg.veins)
    if(nrow(stenting.patient.right.leg.data) > 0){
      # Identify first right leg stenting procedure
      stenting.patient.right.leg.data = arrange(stenting.patient.right.leg.data, Stent.Date)
      first.stent.date = as.character(stenting.patient.right.leg.data$Stent.Date[1])
      first.post.start.date.stenting.Right.Leg[i] = first.stent.date
      stenting.patient.right.leg.data = stenting.patient.left.leg.data %>%
        mutate(First.Stenting.Procedure.Span = round(as.numeric(difftime(Stent.Date, as.Date(first.stent.date))), digits = 0)) %>%
        filter(First.Stenting.Procedure.Span >= 0) %>%
        arrange(desc(Stent.Date))
      if(nrow(stenting.patient.right.leg.data) > 0){
        last.post.start.date.stenting.Right.Leg[i] = as.character(stenting.patient.right.leg.data$Stent.Date[1])
      }
    }
  }
}

# Combine Left Leg and Right Leg Stenting data
stenting.patients.dataframe = cbind.data.frame(stenting.patients, first.post.start.date.stenting.Left.Leg,
                                               first.post.start.date.stenting.Right.Leg, last.post.start.date.stenting.Left.Leg,
                                               last.post.start.date.stenting.Right.Leg)

names(stenting.patients.dataframe)[1] = "record_id"

patency.rate.dataframe = left_join(patency.rate.dataframe, stenting.patients.dataframe, by = "record_id")