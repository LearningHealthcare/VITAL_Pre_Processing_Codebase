# identify_recanalization_procedures.R

# This script identifies recanalization procedures that occur after the followup-start date.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# recanalization reintervention data
recanalization.reintervention.data = chronic.occlusion.location.data %>%
  select(record_id, Procedure.Number, Suprarenal.IVC, Infrarenal.IVC, 
         RCIV, REIV, RCFV, RPFV, RFEMV, RPOP, LCIV, LEIV, LCFV, LPFV, LFEMV, LPOP) %>%
  gather(Vein, Status, -record_id, -Procedure.Number) %>%
  filter(Status == "Yes") %>%
  select(-Status) %>%
  mutate(Record.ID.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+")) %>%
  left_join(procedure.date.data, 
            by = c("record_id", "Procedure.Number"))

recanalization.reintervention.data$Recanalization.Date = recanalization.reintervention.data$proc_date

recanalization.reintervention.data = select(recanalization.reintervention.data, -proc_date)

recanalization.reintervention.data = patency.rate.dataframe %>%
  select(record_id, Followup.Start.Date, Left.Limb.Status, Right.Limb.Status) %>%
  left_join(recanalization.reintervention.data, by = "record_id") %>%
  # Remove procedures that do not count toward patency calculations
  filter(!(Record.ID.Procedure.Identifier %in% non.patency.procedure.list)) %>%
  # Span between Recanalization Procedure Date and Followup Start Date
  mutate(Recanalization.Followup.Span = round(as.numeric(difftime(Recanalization.Date, 
        Followup.Start.Date, units = "days")), digits = 0)) %>%
  filter(Recanalization.Followup.Span > 0) %>%
  select(-Recanalization.Followup.Span, -Followup.Start.Date)

# patients with standalone recanalization procedures
recanalization.patients = recanalization.reintervention.data %>%
  select(record_id) %>%
  unique()

recanalization.patients = recanalization.patients[, 1]

first.post.start.date.recanalization.Left.Leg = rep(NA, times = length(recanalization.patients))

first.post.start.date.recanalization.Right.Leg = rep(NA, times = length(recanalization.patients))

last.post.start.date.recanalization.Left.Leg = rep(NA, times = length(recanalization.patients))

last.post.start.date.recanalization.Right.Leg = rep(NA, times = length(recanalization.patients))

for(i in 1:length(recanalization.patients)){
  recanalization.patient = recanalization.patients[i]
  recanalization.patient.data = recanalization.reintervention.data %>%
    filter(record_id == recanalization.patient) %>%
    arrange(Recanalization.Date)
  # Check if Left Leg is being considered in analysis
  if(!is.na(recanalization.patient.data$Left.Limb.Status[1])){
    recanalization.patient.left.leg.data = filter(recanalization.patient.data, Vein %in% left.leg.veins)
    if(nrow(recanalization.patient.left.leg.data) > 0){
      # Identify first left leg recanalization procedure
      recanalization.patient.left.leg.data = arrange(recanalization.patient.left.leg.data, Recanalization.Date)
      first.recanalization.date = as.character(recanalization.patient.left.leg.data$Recanalization.Date[1])
      first.post.start.date.recanalization.Left.Leg[i] = first.recanalization.date
      recanalization.patient.left.leg.data = recanalization.patient.left.leg.data %>%
        mutate(First.Recanalization.Procedure.Span = round(as.numeric(difftime(Recanalization.Date, as.Date(first.recanalization.date))), digits = 0)) %>%
        filter(First.Recanalization.Procedure.Span >= 0) %>%
        arrange(desc(Recanalization.Date))
      if(nrow(recanalization.patient.left.leg.data) > 0){
        last.post.start.date.recanalization.Left.Leg[i] = as.character(recanalization.patient.left.leg.data$Recanalization.Date[1])
      }
    }
  }
  # Check if Right Leg is being considered in analysis
  if(!is.na(recanalization.patient.data$Right.Limb.Status[1])){
    recanalization.patient.right.leg.data = filter(recanalization.patient.data, Vein %in% right.leg.veins)
    if(nrow(recanalization.patient.right.leg.data) > 0){
      # Identify first right leg balloon angioplasty procedure
      recanalization.patient.right.leg.data = arrange(recanalization.patient.right.leg.data, Recanalization.Date)
      first.recanalization.date = as.character(recanalization.patient.right.leg.data$Recanalization.Date[1])
      first.post.start.date.recanalization.Right.Leg[i] = first.recanalization.date
      recanalization.patient.right.leg.data = recanalization.patient.left.leg.data %>%
        mutate(First.Recanalization.Procedure.Span = round(as.numeric(difftime(Recanalization.Date, as.Date(first.recanalization.date))), digits = 0)) %>%
        filter(First.Recanalization.Procedure.Span >= 0) %>%
        arrange(desc(Recanalization.Date))
      if(nrow(recanalization.patient.right.leg.data) > 0){
        last.post.start.date.recanalization.Right.Leg[i] = as.character(recanalization.patient.right.leg.data$Recanalization.Date[1])
      }
    }
  }
}

# Combine Left Leg and Right Leg recanalization data
recanalization.patients.dataframe = cbind.data.frame(recanalization.patients, first.post.start.date.recanalization.Left.Leg,
  first.post.start.date.recanalization.Right.Leg, last.post.start.date.recanalization.Left.Leg, last.post.start.date.recanalization.Right.Leg)

names(recanalization.patients.dataframe)[1] = "record_id"

patency.rate.dataframe = left_join(patency.rate.dataframe, recanalization.patients.dataframe, by = "record_id")
