# calculate_patency_status.R

# This overarching script is responsible for calculating the updated 
# left and right leg patency statuses (identify which patients lost their
# patency status after the followup start date)

source(paste(patency.calculation.code.directory, 'calculate_left_leg_patency_status.R', sep = '/'))

source(paste(patency.calculation.code.directory, 'calculate_right_leg_patency_status.R', sep = '/'))
