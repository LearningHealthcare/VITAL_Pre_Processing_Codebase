# identify_last_patency_procedure_left_leg.R

# This script identifies the latest left-leg procedure that counts toward patency calculations
# for a particular cohort of patients.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

left.leg.last.patency.procedure.date = rep(NA, times = nrow(patency.rate.dataframe))

left.leg.last.patency.procedure.span = rep(NA, times = nrow(patency.rate.dataframe))

for(i in 1:nrow(patency.rate.dataframe)){
  patency.rate.patient.data = patency.rate.dataframe[i, ]
  if(!is.na(patency.rate.dataframe$Left.Limb.Status[i])){
    balloon.angioplasty.left.leg.date = patency.rate.patient.data$last.post.start.date.balloon.angioplasty.Left.Leg[1]
    # Examine balloon angioplasty re-intervention
    if(!is.na(balloon.angioplasty.left.leg.date)){
      left.leg.last.patency.procedure.date[i] = as.character(balloon.angioplasty.left.leg.date)
      left.leg.last.patency.procedure.span[i] = round(as.numeric(difftime(balloon.angioplasty.left.leg.date, 
          patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
    }
    stent.left.leg.date = patency.rate.patient.data$last.post.start.date.stenting.Left.Leg[1]
    # Examine stent re-intervention
    if(!is.na(stent.left.leg.date)){
      stent.left.leg.date = as.Date(stent.left.leg.date)
      stent.span = round(as.numeric(difftime(stent.left.leg.date, 
                                             patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(left.leg.last.patency.procedure.span[i]) | (left.leg.last.patency.procedure.span[i] < stent.span)){
        left.leg.last.patency.procedure.span[i] = stent.span
        left.leg.last.patency.procedure.date[i] = as.character(stent.left.leg.date)
      }
    }
    recanalization.left.leg.date = patency.rate.patient.data$last.post.start.date.recanalization.Left.Leg[1]
    # Examine Recanalization re-intervention
    if(!is.na(recanalization.left.leg.date)){
      recanalization.left.leg.date = as.Date(recanalization.left.leg.date)
      recanalization.span = round(as.numeric(difftime(recanalization.left.leg.date, 
                                                      patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(left.leg.last.patency.procedure.span[i]) | (left.leg.last.patency.procedure.span[i] < recanalization.span)){
        left.leg.last.patency.procedure.span[i] = recanalization.span
        left.leg.last.patency.procedure.date[i] = as.character(recanalization.left.leg.date)
      }
    }
    thrombectomy.left.leg.date = patency.rate.patient.data$last.post.start.date.thrombectomy.Left.Leg[1]
    # Examine thrombectomy re-intervention
    if(!is.na(thrombectomy.left.leg.date)){
      thrombectomy.left.leg.date = as.Date(thrombectomy.left.leg.date)
      thrombectomy.span = round(as.numeric(difftime(thrombectomy.left.leg.date, 
                                                    patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(left.leg.last.patency.procedure.span[i]) | (left.leg.last.patency.procedure.span[i] < thrombectomy.span)){
        left.leg.last.patency.procedure.span[i] = thrombectomy.span
        left.leg.last.patency.procedure.date[i] = as.character(thrombectomy.left.leg.date)
      }
    }
    # Examine thrombolysis re-intervention
    thrombolysis.left.leg.date = patency.rate.patient.data$last.post.start.date.thrombolysis.Left.Leg[1]
    if(!is.na(thrombolysis.left.leg.date)){
      thrombolysis.left.leg.date = as.Date(thrombolysis.left.leg.date)
      thromobolysis.span = round(as.numeric(difftime(thrombolysis.left.leg.date, 
                                                     patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(left.leg.last.patency.procedure.span[i]) | (left.leg.last.patency.procedure.span[i] < thromobolysis.span)){
        left.leg.last.patency.procedure.span[i] = thromobolysis.span
        left.leg.last.patency.procedure.date[i] = as.character(thrombolysis.left.leg.date)
      }
    }
  }
}

patency.rate.dataframe = cbind.data.frame(patency.rate.dataframe, left.leg.last.patency.procedure.date, left.leg.last.patency.procedure.span)