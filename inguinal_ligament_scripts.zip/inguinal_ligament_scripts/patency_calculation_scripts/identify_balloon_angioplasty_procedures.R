# identify_balloon_angioplasty_procedures.R

# This script identifies balloon angioplasty procedures that occur after the followup-start date.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

standalone.angioplasty.location.procedure.data = standalone.angioplasty.location.procedure.data %>%
  gather(Stent.Location, Stent.Value, -record_id, -Procedure.Number) %>%
  filter(!is.na(Stent.Value)) %>%
  # See citation in standalone angioplasty procedure pre-processing script regarding removing non-numeric characters from strings in R
  mutate(Plasty.Number = gsub("[^0-9]", "", Stent.Location)) %>%
  mutate(Record.ID.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+")) %>%
  # Remove procedures that do not count toward patency calculations
  filter(!(Record.ID.Procedure.Identifier %in% non.patency.procedure.list))

Vein = rep("", times = nrow(standalone.angioplasty.location.procedure.data))

for(i in 1:nrow(standalone.angioplasty.location.procedure.data)){
  # Extract Vein Name from Stent Location
  stent.location = standalone.angioplasty.location.procedure.data$Stent.Location[i]
  stent.location = unlist(strsplit(stent.location, "_"))
  Vein[i] = stent.location[2]
}

standalone.angioplasty.location.procedure.data = cbind.data.frame(standalone.angioplasty.location.procedure.data, Vein)

standalone.angioplasty.location.procedure.data = select(standalone.angioplasty.location.procedure.data, -Stent.Location)

standalone.angioplasty.location.procedure.data = left_join(standalone.angioplasty.location.procedure.data, procedure.date.data, 
                                               by = c("record_id", "Procedure.Number"))

standalone.angioplasty.location.procedure.data$Balloon.Date = standalone.angioplasty.location.procedure.data$proc_date

standalone.angioplasty.location.procedure.data = select(standalone.angioplasty.location.procedure.data, -proc_date)

# balloon angioplasty reintervention data
balloon.angioplasty.reintervention.data = patency.rate.dataframe %>%
  select(record_id, Followup.Start.Date, Left.Limb.Status, Right.Limb.Status) %>%
  left_join(standalone.angioplasty.location.procedure.data, by = "record_id") %>%
  # Span between balloon angioplasty date and followup start date
  mutate(Balloon.Angioplasty.Followup.Span = round(as.numeric(difftime(Balloon.Date, 
        Followup.Start.Date, units = "days")), digits = 0)) %>%
  filter(Balloon.Angioplasty.Followup.Span > 0) %>%
  select(-Balloon.Angioplasty.Followup.Span, -Followup.Start.Date)

# patients with standalone balloon angioplasty procedures
balloon.angioplasty.patients = balloon.angioplasty.reintervention.data %>%
  select(record_id) %>%
  unique()

balloon.angioplasty.patients = balloon.angioplasty.patients[, 1]

first.post.start.date.balloon.angioplasty.Left.Leg = rep(NA, times = length(balloon.angioplasty.patients))

first.post.start.date.balloon.angioplasty.Right.Leg = rep(NA, times = length(balloon.angioplasty.patients))

# Veins examined for purposes of identifying a left leg re-intervention
left.leg.veins = c("Suprarenal.IVC", "Infrarenal.IVC", "LCIV", "LEIV", "LCFV", "LFEMV", "LPFV", "LPOP")

# Veins examined for purposes of identifying a right leg re-intervention
right.leg.veins = c("Suprarenal.IVC", "Infrarenal.IVC", "RCIV", "REIV", "RCFV", "RFEMV", "RPFV", "RPOP")

last.post.start.date.balloon.angioplasty.Left.Leg = rep(NA, times = length(balloon.angioplasty.patients))

last.post.start.date.balloon.angioplasty.Right.Leg = rep(NA, times = length(balloon.angioplasty.patients))

for(i in 1:length(balloon.angioplasty.patients)){
  balloon.angioplasty.patient = balloon.angioplasty.patients[i]
  balloon.angioplasty.patient.data = balloon.angioplasty.reintervention.data %>%
    filter(record_id == balloon.angioplasty.patient) %>%
    arrange(Balloon.Date)
  # Check if Left Leg is being considered in analysis
  if(!is.na(balloon.angioplasty.patient.data$Left.Limb.Status[1])){
    balloon.angioplasty.patient.left.leg.data = filter(balloon.angioplasty.patient.data, Vein %in% left.leg.veins)
    if(nrow(balloon.angioplasty.patient.left.leg.data) > 0){
      # Identify first left leg balloon angioplasty procedure
      balloon.angioplasty.patient.left.leg.data = arrange(balloon.angioplasty.patient.left.leg.data, Balloon.Date)
      first.balloon.date = as.character(balloon.angioplasty.patient.left.leg.data$Balloon.Date[1])
      first.post.start.date.balloon.angioplasty.Left.Leg[i] = first.balloon.date
      balloon.angioplasty.patient.left.leg.data = balloon.angioplasty.patient.left.leg.data %>%
        mutate(First.Angioplasty.Procedure.Span = round(as.numeric(difftime(Balloon.Date, as.Date(first.balloon.date))), digits = 0)) %>%
        filter(First.Angioplasty.Procedure.Span >= 0) %>%
        arrange(desc(Balloon.Date))
      if(nrow(balloon.angioplasty.patient.left.leg.data) > 0){
        last.post.start.date.balloon.angioplasty.Left.Leg[i] = as.character(balloon.angioplasty.patient.left.leg.data$Balloon.Date[1])
      }
    }
  }
  # Check if Right Leg is being considered in analysis
  if(!is.na(balloon.angioplasty.patient.data$Right.Limb.Status[1])){
    balloon.angioplasty.patient.right.leg.data = filter(balloon.angioplasty.patient.data, Vein %in% right.leg.veins)
    if(nrow(balloon.angioplasty.patient.right.leg.data) > 0){
      # Identify first right leg balloon angioplasty procedure
      balloon.angioplasty.patient.right.leg.data = arrange(balloon.angioplasty.patient.right.leg.data, Balloon.Date)
      first.balloon.date = as.character(balloon.angioplasty.patient.right.leg.data$Balloon.Date[1])
      first.post.start.date.balloon.angioplasty.Right.Leg[i] = first.balloon.date
      balloon.angioplasty.patient.right.leg.data = balloon.angioplasty.patient.right.leg.data %>%
        mutate(First.Angioplasty.Procedure.Span = round(as.numeric(difftime(Balloon.Date, as.Date(first.balloon.date))), digits = 0)) %>%
        filter(First.Angioplasty.Procedure.Span >= 0) %>%
        arrange(desc(Balloon.Date))
      if(nrow(balloon.angioplasty.patient.right.leg.data) > 0){
        last.post.start.date.balloon.angioplasty.Right.Leg[i] = as.character(balloon.angioplasty.patient.right.leg.data$Balloon.Date[1])
      }
    }
  }
}

# Combine Left Leg and Right Leg Balloon angioplasty data
balloon.angioplasty.patients.dataframe = cbind.data.frame(balloon.angioplasty.patients, first.post.start.date.balloon.angioplasty.Left.Leg,
    first.post.start.date.balloon.angioplasty.Right.Leg, last.post.start.date.balloon.angioplasty.Left.Leg, 
    last.post.start.date.balloon.angioplasty.Right.Leg)

names(balloon.angioplasty.patients.dataframe)[1] = "record_id"

patency.rate.dataframe = left_join(patency.rate.dataframe, balloon.angioplasty.patients.dataframe, by = "record_id")
