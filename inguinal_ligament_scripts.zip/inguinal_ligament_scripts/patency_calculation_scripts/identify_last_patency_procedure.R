# identify_last_patency_procedure.R

# This overarching script identifies the latest procedure that count toward patency calculations
# for a cohort of patients.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

source(paste(patency.calculation.code.directory, 'identify_last_patency_procedure_left_leg.R', sep = '/'))

source(paste(patency.calculation.code.directory, 'identify_last_patency_procedure_right_leg.R', sep = '/'))