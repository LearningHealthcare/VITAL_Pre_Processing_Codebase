# identify_thrombolysis_procedures.R

# This script identifies thrombolysis procedures that occur after followup start date.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# thrombolysis reintervention data
thrombolysis.reintervention.data = thrombolysis.procedure.data %>%
  select(record_id, Procedure.Number, Right.Catheter.Tip.Lower.Extremity.IVC.Status,
         Right.Catheter.Tip.Lower.Extremity.CIV.Status, Right.Catheter.Tip.Lower.Extremity.EIV.Status,
         Left.Catheter.Tip.Lower.Extremity.IVC.Status, Left.Catheter.Tip.Lower.Extremity.CIV.Status,
         Left.Catheter.Tip.Lower.Extremity.EIV.Status, RCFV.Sheath.Location.Status, RCIV.Sheath.Location.Status,
         REIV.Sheath.Location.Status, RFEMV.Sheath.Location.Status, Right.IVC.Sheath.Location.Status,
         RPOP.Sheath.Location.Status, LCIV.Sheath.Location.Status, LCFV.Sheath.Location.Status, 
         LEIV.Sheath.Location.Status, LFEMV.Sheath.Location.Status, Left.IVC.Sheath.Location.Status,
         LPOP.Sheath.Location.Status) %>%
  mutate(Record.ID.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+")) %>%
  left_join(procedure.date.data, by = c("record_id", "Procedure.Number"))

thrombolysis.reintervention.data$Thrombolysis.Date = thrombolysis.reintervention.data$proc_date

thrombolysis.reintervention.data = select(thrombolysis.reintervention.data, -proc_date)

thrombolysis.reintervention.data = patency.rate.dataframe %>%
  select(record_id, Followup.Start.Date, Left.Limb.Status, Right.Limb.Status) %>%
  left_join(thrombolysis.reintervention.data, by = "record_id") %>%
  # Remove procedures that do not count toward patency calculations
  filter(!(Record.ID.Procedure.Identifier %in% non.patency.procedure.list)) %>%
  # Calculate span between Thrombolysis Procedure and followup start date
  mutate(Thrombolysis.Reintervention.Date.Span = round(as.numeric(difftime(Thrombolysis.Date, 
        Followup.Start.Date, units = "days")), digits = 0)) %>%
  filter(Thrombolysis.Reintervention.Date.Span > 0)

# patients with thrombolysis procedures
thrombolysis.patients = thrombolysis.reintervention.data %>%
  select(record_id) %>%
  unique()

thrombolysis.patients = thrombolysis.patients[, 1]

first.post.start.date.thrombolysis.Left.Leg = rep(NA, times = length(thrombolysis.patients))

first.post.start.date.thrombolysis.Right.Leg = rep(NA, times = length(thrombolysis.patients))

last.post.start.date.thrombolysis.Left.Leg = rep(NA, times = length(thrombolysis.patients))

last.post.start.date.thrombolysis.Right.Leg = rep(NA, times = length(thrombolysis.patients))

for(i in 1:length(thrombolysis.patients)){
  thrombolysis.patient = thrombolysis.patients[i]
  thrombolysis.patient.data = thrombolysis.reintervention.data %>%
    filter(record_id == thrombolysis.patient) %>%
    arrange(Thrombolysis.Date)
  # Check if Left Leg is being considered in analysis
  if(!is.na(thrombolysis.patient.data$Left.Limb.Status[1])){
    thrombolysis.left.leg.data = filter(thrombolysis.patient.data, 
      Left.Catheter.Tip.Lower.Extremity.IVC.Status == "Yes" | Left.Catheter.Tip.Lower.Extremity.CIV.Status == "Yes" |
        Left.Catheter.Tip.Lower.Extremity.EIV.Status == "Yes" | LCIV.Sheath.Location.Status == "Yes" | 
        LCFV.Sheath.Location.Status == "Yes" | LEIV.Sheath.Location.Status == "Yes" | LFEMV.Sheath.Location.Status == "Yes" |
        Left.IVC.Sheath.Location.Status == "Yes" | LPOP.Sheath.Location.Status == "Yes")
    if(nrow(thrombolysis.left.leg.data) > 0){
      # Identify first Left leg thrombolysis procedure
      thrombolysis.left.leg.data = arrange(thrombolysis.left.leg.data, Thrombolysis.Date)
      first.thrombolysis.date = as.character(thrombolysis.left.leg.data$Thrombolysis.Date[1])
      first.post.start.date.thrombolysis.Left.Leg[i] = first.thrombolysis.date
      thrombolysis.left.leg.data = thrombolysis.left.leg.data %>%
        mutate(First.Thrombolysis.Procedure.Span = round(as.numeric(difftime(Thrombolysis.Date, as.Date(first.thrombolysis.date))), digits = 0)) %>%
        filter(First.Thrombolysis.Procedure.Span >= 0) %>%
        arrange(desc(Thrombolysis.Date))
      if(nrow(stenting.patient.left.leg.data) > 0){
        last.post.start.date.thrombolysis.Left.Leg[i] = as.character(thrombolysis.left.leg.data$Thrombolysis.Date[1])
      }
    }
  }
  # Check if Right Leg is being considered in analysis
  if(!is.na(thrombolysis.patient.data$Right.Limb.Status[1])){
    thrombolysis.right.leg.data = filter(thrombolysis.patient.data, 
    Right.Catheter.Tip.Lower.Extremity.IVC.Status == "Yes" | Right.Catheter.Tip.Lower.Extremity.CIV.Status == "Yes" |
    Right.Catheter.Tip.Lower.Extremity.EIV.Status == "Yes" | RCIV.Sheath.Location.Status == "Yes" | 
    RCFV.Sheath.Location.Status == "Yes" | REIV.Sheath.Location.Status == "Yes" | RFEMV.Sheath.Location.Status == "Yes" |
    Right.IVC.Sheath.Location.Status == "Yes" | RPOP.Sheath.Location.Status == "Yes")
    if(nrow(thrombolysis.right.leg.data) > 0){
        # Identify first right leg thrombolysis procedure
        thrombolysis.right.leg.data = arrange(thrombolysis.right.leg.data, Thrombolysis.Date)
        first.thrombolysis.date = as.character(thrombolysis.right.leg.data$Thrombolysis.Date[1])
        first.post.start.date.thrombolysis.Right.Leg[i] = first.thrombolysis.date
        thrombolysis.right.leg.data = thrombolysis.right.leg.data %>%
          mutate(First.Thrombolysis.Procedure.Span = round(as.numeric(difftime(Thrombolysis.Date, as.Date(first.thrombolysis.date))), digits = 0)) %>%
          filter(First.Thrombolysis.Procedure.Span >= 0) %>%
          arrange(desc(Thrombolysis.Date))
        if(nrow(stenting.patient.right.leg.data) > 0){
          last.post.start.date.thrombolysis.Right.Leg[i] = as.character(thrombolysis.right.leg.data$Thrombolysis.Date[1])
        }
    }
  }
}

# Combine left and right leg thrombolysis data
thrombolysis.patients.dataframe = cbind.data.frame(thrombolysis.patients, first.post.start.date.thrombolysis.Left.Leg,
  first.post.start.date.thrombolysis.Right.Leg, last.post.start.date.thrombolysis.Left.Leg, last.post.start.date.thrombolysis.Right.Leg)

names(thrombolysis.patients.dataframe)[1] = "record_id"

patency.rate.dataframe = left_join(patency.rate.dataframe, thrombolysis.patients.dataframe, by = "record_id")