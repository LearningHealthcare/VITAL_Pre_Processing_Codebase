# calculate_left_leg_patency_status.R

# This script calculates the updated left leg patency status for a series of patients.
# In addition, the script calculates when the patency status from the followup start date is 
# first lost, if applicable.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

patency.rate.dataframe$first.post.start.date.balloon.angioplasty.Left.Leg = as.character(patency.rate.dataframe$first.post.start.date.balloon.angioplasty.Left.Leg)
patency.rate.dataframe$first.post.start.date.stenting.Left.Leg = as.character(patency.rate.dataframe$first.post.start.date.stenting.Left.Leg)
patency.rate.dataframe$first.post.start.date.recanalization.Left.Leg = as.character(patency.rate.dataframe$first.post.start.date.recanalization.Left.Leg)
patency.rate.dataframe$first.post.start.date.thrombectomy.Left.Leg = as.character(patency.rate.dataframe$first.post.start.date.thrombectomy.Left.Leg)
patency.rate.dataframe$first.post.start.date.thrombolysis.Left.Leg = as.character(patency.rate.dataframe$first.post.start.date.thrombolysis.Left.Leg)

primary.patency.left.leg.span = rep(NA, times = nrow(patency.rate.dataframe))
left.leg.primary.patency.loss.date = rep(NA, times = nrow(patency.rate.dataframe))

assisted.primary.patency.left.leg.span = rep(NA, times = nrow(patency.rate.dataframe))
assisted.primary.patency.left.leg.loss.date = rep(NA, times = nrow(patency.rate.dataframe))

for(i in 1:nrow(patency.rate.dataframe)){
  patency.rate.patient.data = patency.rate.dataframe[i, ]
  # Calculate first left leg re-intervention/thrombotic complication after followup start date (if applicable)
  if(!is.na(patency.rate.dataframe$Left.Limb.Status[i])){
    ir.thrombotic.complication.date = patency.rate.patient.data$ir.clinic.visit.first.thrombotic.complication.date[1]
    # Examine first IR Clinic Visit thrombotic complication
    if(!is.na(ir.thrombotic.complication.date)){
      ir.thrombotic.complication.date = as.Date(ir.thrombotic.complication.date)
      ir.thrombotic.complication.span = round(as.numeric(difftime(ir.thrombotic.complication.date, 
                  patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(primary.patency.left.leg.span[i]) | (primary.patency.left.leg.span[i] > ir.thrombotic.complication.span)){
        primary.patency.left.leg.span[i] = ir.thrombotic.complication.span
        left.leg.primary.patency.loss.date[i] = as.character(ir.thrombotic.complication.date)
        assisted.primary.patency.left.leg.span[i] = ir.thrombotic.complication.span
        assisted.primary.patency.left.leg.loss.date[i] = as.character(ir.thrombotic.complication.date)
      }
    }
    non.ir.thrombotic.complication.date = patency.rate.patient.data$non.ir.clinic.encounter.first.thrombotic.complication.date[1]
    # Examine first non IR encounter thrombotic complication
    if(!is.na(non.ir.thrombotic.complication.date)){
      non.ir.thrombotic.complication.date = as.Date(non.ir.thrombotic.complication.date)
      non.ir.thrombotic.complication.span = round(as.numeric(difftime(non.ir.thrombotic.complication.date, 
                                                    patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(primary.patency.left.leg.span[i]) | (primary.patency.left.leg.span[i] > non.ir.thrombotic.complication.span)){
        primary.patency.left.leg.span[i] = non.ir.thrombotic.complication.span
        left.leg.primary.patency.loss.date[i] = as.character(non.ir.thrombotic.complication.date)
        assisted.primary.patency.left.leg.span[i] = non.ir.thrombotic.complication.span
        assisted.primary.patency.left.leg.loss.date[i] = as.character(non.ir.thrombotic.complication.date)
      }
    }
    balloon.angioplasty.left.leg.date = patency.rate.patient.data$first.post.start.date.balloon.angioplasty.Left.Leg[1]
    # Examine balloon angioplasty re-intervention
    if(!is.na(balloon.angioplasty.left.leg.date)){
      balloon.angioplasty.left.leg.date = as.Date(balloon.angioplasty.left.leg.date)
      balloon.angioplasty.span = round(as.numeric(difftime(balloon.angioplasty.left.leg.date, 
                                       patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(primary.patency.left.leg.span[i]) | (primary.patency.left.leg.span[i] > balloon.angioplasty.span)){
        primary.patency.left.leg.span[i] = balloon.angioplasty.span
        left.leg.primary.patency.loss.date[i] = as.character(balloon.angioplasty.left.leg.date)
      }
    }
    stent.left.leg.date = patency.rate.patient.data$first.post.start.date.stenting.Left.Leg[1]
    # Examine stent re-intervention
    if(!is.na(stent.left.leg.date)){
      stent.left.leg.date = as.Date(stent.left.leg.date)
      stent.span = round(as.numeric(difftime(stent.left.leg.date, 
                        patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(primary.patency.left.leg.span[i]) | (primary.patency.left.leg.span[i] > stent.span)){
        primary.patency.left.leg.span[i] = stent.span
        left.leg.primary.patency.loss.date[i] = as.character(stent.left.leg.date)
      }
    }
    recanalization.left.leg.date = patency.rate.patient.data$first.post.start.date.recanalization.Left.Leg[1]
    # Examine Recanalization re-intervention
    if(!is.na(recanalization.left.leg.date)){
      recanalization.left.leg.date = as.Date(recanalization.left.leg.date)
      recanalization.span = round(as.numeric(difftime(recanalization.left.leg.date, 
                                patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(primary.patency.left.leg.span[i]) | (primary.patency.left.leg.span[i] > recanalization.span)){
        primary.patency.left.leg.span[i] = recanalization.span
        left.leg.primary.patency.loss.date[i] = as.character(recanalization.left.leg.date)
      }
    }
    thrombectomy.left.leg.date = patency.rate.patient.data$first.post.start.date.thrombectomy.Left.Leg[1]
    # Examine thrombectomy re-intervention
    if(!is.na(thrombectomy.left.leg.date)){
      thrombectomy.left.leg.date = as.Date(thrombectomy.left.leg.date)
      thrombectomy.span = round(as.numeric(difftime(thrombectomy.left.leg.date, 
                    patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(primary.patency.left.leg.span[i]) | (primary.patency.left.leg.span[i] > thrombectomy.span)){
        primary.patency.left.leg.span[i] = thrombectomy.span
        left.leg.primary.patency.loss.date[i] = as.character(thrombectomy.left.leg.date)
      }
    }
    # Examine thrombolysis re-intervention
    thrombolysis.left.leg.date = patency.rate.patient.data$first.post.start.date.thrombolysis.Left.Leg[1]
    if(!is.na(thrombolysis.left.leg.date)){
      thrombolysis.left.leg.date = as.Date(thrombolysis.left.leg.date)
      thromobolysis.span = round(as.numeric(difftime(thrombolysis.left.leg.date, 
              patency.rate.patient.data$Followup.Start.Date[1], units = "days")), digits = 0)
      if(is.na(primary.patency.left.leg.span[i]) | (primary.patency.left.leg.span[i] > thromobolysis.span)){
        primary.patency.left.leg.span[i] = thromobolysis.span
        left.leg.primary.patency.loss.date[i] = as.character(thrombolysis.left.leg.date)
      }
    }
  }
}

patency.rate.dataframe = cbind.data.frame(patency.rate.dataframe, primary.patency.left.leg.span, left.leg.primary.patency.loss.date,
  assisted.primary.patency.left.leg.span, assisted.primary.patency.left.leg.loss.date)

patency.rate.dataframe = patency.rate.dataframe %>%
  mutate(Left.Leg.Final.Primary.Patency.Status = ifelse(is.na(primary.patency.left.leg.span), 
    Follow.Start.Left.Leg.Patency.Status, "Primary.Patency.Lost")) %>%
  mutate(Left.Leg.Final.Assisted.Primary.Patency.Status = ifelse(is.na(assisted.primary.patency.left.leg.span),
    "Assisted.Primary.Patency.Not.Lost", "Assisted.Primary.Patency.Lost")) %>%
  mutate(Left.Leg.Final.Secondary.Patency.Status = ifelse(is.na(left.leg.secondary.patency.span), 
    "Secondary.Patency.Not.Lost", "Secondary.Patency.Lost"))