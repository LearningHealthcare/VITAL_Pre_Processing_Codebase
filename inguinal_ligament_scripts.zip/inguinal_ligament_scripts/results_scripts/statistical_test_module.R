# statistical_test_module.R

# This script performs statistical testing, relating to the study
# of inguinal ligament stenting.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

iliac.femoral.restenosis.contingency.table = iliac.femoral.restenosis.summary.statistics %>%
  select(Iliac.Femoral.Vein.Status, Restenosis.Status, Restenosis.Status.Count) %>%
  spread(Restenosis.Status, Restenosis.Status.Count)

# Iliac vs Femoral Vein Restenosis Chi-square Test Calculation
iliac.femoral.restenosis.chi.square.test = chisq.test(iliac.femoral.restenosis.contingency.table[, -1])

# Vein Max Diameter Pre versus Post Stenting Paired T-Test
for(i in 1:length(vein.list)){
  vein.name = vein.list[i]
  vein.max.diameter.data = filter(vein.max.diameter.stenting.dataframe, Vein == vein.name)
  if(nrow(vein.max.diameter.data) > 15){
    vein.paired.t.test.results = t.test(vein.max.diameter.data$Max.Diameter.Before.Stenting, 
                                        vein.max.diameter.data$Max.Diameter.After.Stenting, paired = TRUE)
  }
}

# Vein Min Diameter Pre versus Post Stenting Paired T-Test
for(i in 1:length(vein.list)){
  vein.name = vein.list[i]
  vein.min.diameter.data = filter(vein.min.diameter.stenting.dataframe, Vein == vein.name)
  vein.paired.t.test.results = t.test(vein.min.diameter.stenting.dataframe$Min.Diameter.Before.Stenting, 
      vein.min.diameter.stenting.dataframe$Min.Diameter.After.Stenting, paired = TRUE)
}

# Inguinal Ligament Status vs. Gender of Patient Chi-square Test
limb.gender.chi.square.test = chisq.test(limb.gender.inguinal.summary.statistics[, -1])

# Inguinal Ligament Status vs. Ethnicity Fisher's Exact Test 
limb.ethnicity.fisher.exact.test = fisher.test(limb.ethnicity.inguinal.summary.statistics[, -1])

# Inguinal Ligament Status vs. Age at Intevention t-test
inguinal.age.at.intervention.t.test = t.test(above.inguinal.ligament.age.at.intervention[, 1], 
                                             below.inguinal.ligament.age.at.intervention[, 1])

# Left Leg Villata Score pre-stenting versus Post-stenting Paired T-Test
left.villalta.paired.t.test = t.test(left.villalta.paired.dataframe$Left.Villalta.Score.Prior.Stenting, 
                                     left.villalta.paired.dataframe$Left.Villalta.Score.Post.Stenting, paired = TRUE)

# Right Leg Villata Score pre-stenting versus Post-stenting Paired T-Test
right.villalta.paired.t.test = t.test(right.villalta.paired.dataframe$Right.Villalta.Score.Prior.Stenting, 
                                      right.villalta.paired.dataframe$Right.Villalta.Score.Post.Stenting, paired = TRUE)

# Limb-Level Patency vs. Inguinal Ligament Status Chi-square Test
limb.level.patency.chi.square.test = chisq.test(limb.level.patency.summary.statistics[, c((ncol(limb.level.patency.summary.statistics) - 1),
  ncol(limb.level.patency.summary.statistics))])

# Limb-Level Restenosis vs. Inguinal Ligament Status Chi-square Test
limb.level.restenosis.chi.square.test = chisq.test(limb.level.restenosis.summary.statistics[, c((ncol(limb.level.restenosis.summary.statistics) - 1),
  ncol(limb.level.restenosis.summary.statistics))])
