# summary_statistics_module.R

# This overarching script calculates summary statistics results, relating
# to the study of inguinal ligament stenting.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

source(paste(results.code.directory, 'vein_level_summary_statistics.R', sep = '/'))

source(paste(results.code.directory, 'vein_diameter_summary_statistics.R', sep = '/'))

source(paste(results.code.directory, 'limb_patient_level_summary_statistics.R', sep = '/'))

source(paste(results.code.directory, 'limb_villalta_summary_statistics.R', sep = '/'))

source(paste(results.code.directory, 'risk_factors_summary_statistics.R', sep = '/'))

source(paste(results.code.directory, 'complications_summary_statistics.R', sep = '/'))

source(paste(results.code.directory, 'limb_level_outcomes_summary_statistics.R', sep = '/'))