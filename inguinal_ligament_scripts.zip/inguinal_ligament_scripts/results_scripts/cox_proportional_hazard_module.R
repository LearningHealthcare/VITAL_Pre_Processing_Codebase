# cox_proportional_hazard_module.R

# This script performs vein and limb-level Cox Proportional Hazard modeling,
# relating to the study of inguinal ligament stenting.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Vein-Level Restenosis Cox proportional Hazard Model
vein.restenosis.model = coxph(Surv(Time.Restenosis.Censor.Modified, Restenosis.Label) ~ factor(Iliac.Femoral.Vein.Status) + 
  factor(Stent.Brand) + factor(Stent.Length) + factor(Stent.Diameter) + factor(Angioplasty.Status) + factor(DVT.on.Imaging.Status), 
  data = vein.KM.dataframe)

summary(vein.restenosis.model)

# Limb-Level Patency Cox proportional Hazard Model
limb.patency.model = coxph(Surv(Time.Patency.Censor.Months.Modified, Patency.Label) ~ factor(Limb.Status) + 
                             factor(Gender) + factor(Ethnicity) + Age.at.Intervention + factor(IVC.Status) + factor(Thrombophilia.Risk.Factor.Status) + 
                             factor(Limb.Laterality) + factor(Leg.DVT.Lymphedema.Status), data = limb.KM.dataframe)

summary(limb.patency.model)

# Limb-Level Restenosis Cox proportional Hazard Model
limb.restenosis.model = coxph(Surv(Time.Restenosis.Censor.Months.Modified, Restenosis.Label) ~ factor(Limb.Status) + 
                                factor(Gender) + factor(Ethnicity) + Age.at.Intervention + factor(IVC.Status) + factor(Thrombophilia.Risk.Factor.Status) + 
                                factor(Limb.Laterality) + Leg.DVT.Lymphedema.Status, data = limb.KM.dataframe)

summary(limb.restenosis.model)
