# limb_villalta_summary_statistics_plots.R

# This script calculates summary statistics relating to Villalta scores
# pre versus post stenting.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

left.villalta.pre.stenting = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Left.Villalta.Score.Prior.Stenting) %>%
  filter(!is.na(Left.Limb.Status) & !is.na(Left.Villalta.Score.Prior.Stenting))

# Number of left limb villalta measurements prior to stenting
left.villalta.pre.stenting.measurement.count = left.villalta.pre.stenting %>%
  group_by(Left.Limb.Status) %>%
  summarise(Count = n())

# Left Limb Mean Villalta pre stenting score by Inguinal Ligament Status
left.villalta.pre.stenting.mean = left.villalta.pre.stenting %>%
  group_by(Left.Limb.Status) %>%
  summarise(Mean.Villalta.Score.Pre.Stenting = mean(Left.Villalta.Score.Prior.Stenting))

# Left Limb Standard Deviation Villalta pre stenting score by Inguinal Ligament Status
left.villalta.pre.stenting.sd = left.villalta.pre.stenting %>%
  group_by(Left.Limb.Status) %>%
  summarise(Standard.Deviation.Villalta.Score = sd(Left.Villalta.Score.Prior.Stenting))

# Average Time that Villalta Measurement occurs prior to stenting
left.villalta.pre.stenting.span.mean = round(mean(inguinal.ligament.data.frame$Left.Villalta.Score.Prior.Stenting.Span, na.rm = TRUE), digits = 0)

left.villalta.post.stenting = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Left.Villalta.Score.Post.Stenting) %>%
  filter(!is.na(Left.Limb.Status) & !is.na(Left.Villalta.Score.Post.Stenting))

# Number of left limb villalta measurements after stenting
left.villalta.post.stenting.measurement.count = left.villalta.post.stenting %>%
  group_by(Left.Limb.Status) %>%
  summarise(Count = n())

# Left Limb Mean Villalta post stenting score by Inguinal Ligament Status
left.villalta.post.stenting.mean = left.villalta.post.stenting %>%
  group_by(Left.Limb.Status) %>%
  summarise(Mean.Villalta.Score.Post.Stenting = mean(Left.Villalta.Score.Post.Stenting))

# Left Limb Standard Deviation Villalta post stenting score by Inguinal Ligament Status
left.villalta.post.stenting.sd = left.villalta.post.stenting %>%
  group_by(Left.Limb.Status) %>%
  summarise(Standard.Deviation.Villalta.Score = sd(Left.Villalta.Score.Post.Stenting))

# Average Time that Villalta Measurement occurs post stenting
left.villalta.post.stenting.span.mean = round(mean(inguinal.ligament.data.frame$Left.Villalta.Score.Post.Stenting.Span, na.rm = TRUE), digits = 0)

# Left Villalta pre vs. post stenting scores by Inguinal Ligament Status
left.villalta.dataframe = inner_join(left.villalta.pre.stenting.mean,
  left.villalta.post.stenting.mean, by = "Left.Limb.Status")

left.villalta.dataframe$Mean.Villalta.Score.Pre.Stenting = round(left.villalta.dataframe$Mean.Villalta.Score.Pre.Stenting, digits = 1)
left.villalta.dataframe$Mean.Villalta.Score.Post.Stenting = round(left.villalta.dataframe$Mean.Villalta.Score.Post.Stenting, digits = 1)

left.villalta.dataframe$Left.Limb.Status = factor(left.villalta.dataframe$Left.Limb.Status, levels = c("Below.Inguinal.Ligament",
  "Above.Inguinal.Ligament"))

left.villalta.paired.dataframe = left.villalta.pre.stenting %>%
  inner_join(left.villalta.post.stenting, by = c("record_id", "Left.Limb.Status")) %>%
  filter(!is.na(Left.Villalta.Score.Prior.Stenting) & !is.na(Left.Villalta.Score.Post.Stenting))

right.villalta.pre.stenting = inguinal.ligament.data.frame %>%
  select(record_id, Right.Limb.Status, Right.Villalta.Score.Prior.Stenting) %>%
  filter(!is.na(Right.Limb.Status) & !is.na(Right.Villalta.Score.Prior.Stenting))

# Number of right limb villalta measurements prior to stenting
right.villalta.pre.stenting.measurement.count = right.villalta.pre.stenting %>%
  group_by(Right.Limb.Status) %>%
  summarise(Count = n())

# Right Limb Mean Villalta pre stenting score by Inguinal Ligament Status
right.villalta.pre.stenting.mean = right.villalta.pre.stenting %>%
  group_by(Right.Limb.Status) %>%
  summarise(Mean.Villalta.Score.Pre.Stenting = mean(Right.Villalta.Score.Prior.Stenting))

# Right Limb Standard Deviation Villalta pre stenting score by Inguinal Ligament Status
right.villalta.pre.stenting.sd = right.villalta.pre.stenting %>%
  group_by(Right.Limb.Status) %>%
  summarise(Standard.Deviation.Villalta.Score = sd(Right.Villalta.Score.Prior.Stenting))

# Average Time that Villalta Measurement occurs prior to stenting
right.villalta.pre.stenting.span.mean = round(mean(inguinal.ligament.data.frame$Right.Villalta.Score.Prior.Stenting.Span, na.rm = TRUE), digits = 0)

right.villalta.post.stenting = inguinal.ligament.data.frame %>%
  select(record_id, Right.Limb.Status, Right.Villalta.Score.Post.Stenting) %>%
  filter(!is.na(Right.Limb.Status) & !is.na(Right.Villalta.Score.Post.Stenting))

# Number of right limb villalta measurements after stenting
right.villalta.post.stenting.measurement.count = right.villalta.post.stenting %>%
  group_by(Right.Limb.Status) %>%
  summarise(Count = n())

# Right Limb Mean Villalta post stenting score by Inguinal Ligament Status
right.villalta.post.stenting.mean = right.villalta.post.stenting %>%
  group_by(Right.Limb.Status) %>%
  summarise(Mean.Villalta.Score.Post.Stenting = mean(Right.Villalta.Score.Post.Stenting))

# Right Limb Standard Deviation Villalta post stenting score by Inguinal Ligament Status
right.villalta.post.stenting.sd = right.villalta.post.stenting %>%
  group_by(Right.Limb.Status) %>%
  summarise(Standard.Deviation.Villalta.Score = sd(Right.Villalta.Score.Post.Stenting))

# Average Time that Villalta Measurement occurs post stenting
right.villalta.post.stenting.span.mean = round(mean(inguinal.ligament.data.frame$Right.Villalta.Score.Post.Stenting.Span, na.rm = TRUE), digits = 0)

# Right Villalta pre vs. post stenting scores by Inguinal Ligament Status
right.villalta.dataframe = inner_join(right.villalta.pre.stenting.mean,
  right.villalta.post.stenting.mean, by = "Right.Limb.Status")

right.villalta.dataframe$Mean.Villalta.Score.Pre.Stenting = round(right.villalta.dataframe$Mean.Villalta.Score.Pre.Stenting, digits = 1)
right.villalta.dataframe$Mean.Villalta.Score.Post.Stenting = round(right.villalta.dataframe$Mean.Villalta.Score.Post.Stenting, digits = 1)

right.villalta.dataframe$Right.Limb.Status = factor(right.villalta.dataframe$Right.Limb.Status, levels = c("Below.Inguinal.Ligament",
      "Above.Inguinal.Ligament"))

right.villalta.paired.dataframe = right.villalta.pre.stenting %>%
  inner_join(right.villalta.post.stenting, by = c("record_id", "Right.Limb.Status")) %>%
  filter(!is.na(Right.Villalta.Score.Prior.Stenting) & !is.na(Right.Villalta.Score.Post.Stenting))