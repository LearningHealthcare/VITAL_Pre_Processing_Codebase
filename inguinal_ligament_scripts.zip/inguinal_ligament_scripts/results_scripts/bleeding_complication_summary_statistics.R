# bleeding_complication_summary_statistics.R

# This script calculates bleeding complication summary statistics for the 
# analysis cohort.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Combine Bleeding Complication Name, Major vs. Minor and Time data from Non-IR Encounters
non.ir.bleeding.complication = non.ir.complication.status.data %>%
  select(record_id, Non.IR.Encounter.Number, encounter_bleed_comp_major_minor) %>%
  filter(!is.na(encounter_bleed_comp_major_minor)) %>%
  left_join(non.ir.complication.time.data, by = c("record_id", "Non.IR.Encounter.Number")) %>%
  left_join(non.ir.complication.name.data, by = c("record_id", "Non.IR.Encounter.Number")) %>%
  select(-encounter_backpain_complication_time, -encounter_other_complication_time, 
         -encounter_thromb_complication_time, -encounter_thromb_complication_name, 
         -encounter_other_complication_name) %>%
  filter(!is.na(encounter_bleed_complication_name)) %>%
  inner_join(non.ir.clinic.dates.data, by = c("record_id", "Non.IR.Encounter.Number"))

non.ir.bleeding.complication = inguinal.ligament.data.frame %>%
  select(record_id, Followup.Start.Date, primary.patency.left.leg.span, 
         primary.patency.right.leg.span) %>%
  right_join(non.ir.bleeding.complication, by = "record_id") %>%
  # Span between Bleeding Complication Date and follow-up start date (Stent Placement Date)
  mutate(Complication.Followup.Start.Date.Span = round(as.numeric(difftime(nonir_date, Followup.Start.Date, 
                                                                  units = "days")), digits = 0)) %>%
  # Bleeding Complications within year of Stent Placement Date
  filter(Complication.Followup.Start.Date.Span < 365.25 & Complication.Followup.Start.Date.Span >= 0) %>%
  filter(is.na(primary.patency.left.leg.span) | 
           primary.patency.left.leg.span >= Complication.Followup.Start.Date.Span) %>%
  filter(is.na(primary.patency.right.leg.span) | 
           primary.patency.right.leg.span >= Complication.Followup.Start.Date.Span)

# Combine Bleeding Complication Name, Major vs. Minor and Time data from IR Clinic Visits
ir.bleeding.complication = ir.complication.status.data %>%
  select(record_id, IR.Clinic.Visit.Number, bleed_comp_major_minor) %>%
  filter(!is.na(bleed_comp_major_minor)) %>%
  left_join(ir.complication.time.data, by = c("record_id", "IR.Clinic.Visit.Number")) %>%
  left_join(ir.complication.name.data, by = c("record_id", "IR.Clinic.Visit.Number")) %>%
  select(-backpain_complication_time, -other_complication_time, 
         -thromb_complication_time, -thromb_complication_name, 
         -other_complication_name) %>%
  filter(!is.na(bleed_complication_name)) %>%
  inner_join(ir.clinic.visit.practitioner.visit.date.data, by = c("record_id", "IR.Clinic.Visit.Number"))

ir.bleeding.complication = inguinal.ligament.data.frame %>%
  select(record_id, Followup.Start.Date, primary.patency.left.leg.span, 
         primary.patency.right.leg.span) %>%
  right_join(ir.bleeding.complication, by = "record_id") %>%
  # Span between Bleeding Complication Date and follow-up start date (Stent Placement Date)
  mutate(Complication.Followup.Start.Date.Span = round(as.numeric(difftime(visitdate, Followup.Start.Date, 
                                                                     units = "days")), digits = 0)) %>%
  # Bleeding Complications within year of Stent Placement Date
  filter(Complication.Followup.Start.Date.Span < 365.25 & Complication.Followup.Start.Date.Span >= 0) %>%
  filter(is.na(primary.patency.left.leg.span) | 
           primary.patency.left.leg.span >= Complication.Followup.Start.Date.Span) %>%
  filter(is.na(primary.patency.right.leg.span) | 
           primary.patency.right.leg.span >= Complication.Followup.Start.Date.Span)

total.bleeding.complication.patients = select(ir.bleeding.complication, record_id)

total.bleeding.complication.patients = total.bleeding.complication.patients$record_id

total.bleeding.complication.count = c(total.bleeding.complication.patients, non.ir.bleeding.complication$record_id)

# Number of Patients with Bleeding Complications within a year of Followup Start Date (Stent Placement Date)
total.bleeding.complication.count = length(unique(total.bleeding.complication.patients))

total.bleeding.complication.patients = data.frame(total.bleeding.complication.patients)

names(total.bleeding.complication.patients) = "record_id"

total.bleeding.complication.patients = ir.bleeding.complication %>%
  select(record_id, visitdate, Complication.Followup.Start.Date.Span, 
         bleed_comp_major_minor, bleed_complication_time, bleed_complication_name) %>%
  right_join(total.bleeding.complication.patients, by = "record_id") %>%
  mutate(IR.Visit.Complication.Followup.Start.Date.Span = Complication.Followup.Start.Date.Span) %>%
  select(-Complication.Followup.Start.Date.Span)

total.bleeding.complication.patients = non.ir.bleeding.complication %>%
  select(record_id, encounter_bleed_comp_major_minor, encounter_bleed_complication_time,
         encounter_bleed_complication_name, Complication.Followup.Start.Date.Span) %>%
  right_join(total.bleeding.complication.patients, by = "record_id") %>%
  mutate(Non.IR.Complication.Followup.Start.Date.Span = Complication.Followup.Start.Date.Span) %>%
  select(-Complication.Followup.Start.Date.Span)

# Number of Bleeding Complications by Major vs. Minor Status
total.bleeding.complication.major.minor.summary.statistics = total.bleeding.complication.patients %>%
  select(record_id, encounter_bleed_comp_major_minor, bleed_comp_major_minor) %>%
  gather(Encounter.Type, Complication.Status, -record_id) %>%
  filter(!is.na(Complication.Status)) %>%
  group_by(Complication.Status) %>%
  summarise(Complication.Count = n())

# Number of Bleeding Complications by Complication Time
total.bleeding.complication.time.summary.statistics = total.bleeding.complication.patients %>%
  select(record_id, bleed_complication_time, encounter_bleed_complication_time) %>%
  gather(Encounter.Type, Complication.Time, -record_id) %>%
  filter(!is.na(Complication.Time)) %>%
  group_by(Complication.Time) %>%
  summarise(Complication.Count = n()) %>%
  arrange(desc(Complication.Count))