# kaplan_meier_module.R

# This script performs vein and limb-level Kaplan Meier analyses,
# relating to the study of inguinal ligament stenting.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Time Threshold for Capping Kaplan Meier Analysis (5 years)
KM.time.threshold = 60

# Vein-Level Kaplan-Meier Dataframe
vein.KM.dataframe = select(iliac.femoral.veins, record_id, Vein, Stent.Placement.Date,
                      First.Restenosis.Date, Iliac.Femoral.Vein.Status,
                      Restenosis.Status, Vein, Stent.Brand, Stent.Length, Stent.Diameter,
                      DVT.on.Imaging.Status, Angioplasty.Status)

vein.KM.dataframe$Stent.Brand = as.character(vein.KM.dataframe$Stent.Brand)
vein.KM.dataframe$Stent.Length = as.character(vein.KM.dataframe$Stent.Length)
vein.KM.dataframe$Stent.Diameter = as.character(vein.KM.dataframe$Stent.Diameter)
vein.KM.dataframe$DVT.on.Imaging.Status = as.character(vein.KM.dataframe$DVT.on.Imaging.Status)
vein.KM.dataframe$Angioplasty.Status = as.character(vein.KM.dataframe$Angioplasty.Status)

vein.KM.dataframe$Stent.Brand[is.na(vein.KM.dataframe$Stent.Brand)] = "N/A"
vein.KM.dataframe$Stent.Length[is.na(vein.KM.dataframe$Stent.Length)] = "N/A"
vein.KM.dataframe$Stent.Diameter[is.na(vein.KM.dataframe$Stent.Diameter)] = "N/A"
vein.KM.dataframe$DVT.on.Imaging.Status[is.na(vein.KM.dataframe$DVT.on.Imaging.Status)] = "N/A"
vein.KM.dataframe$Angioplasty.Status[is.na(vein.KM.dataframe$Angioplasty.Status)] = "N/A"

vein.KM.dataframe$DVT.on.Imaging.Status = factor(vein.KM.dataframe$DVT.on.Imaging.Status, levels = c("Patent", "N/A", "Acute", "Chronic", "Acute on Chronic"))

vein.KM.dataframe$Angioplasty.Status = factor(vein.KM.dataframe$Angioplasty.Status, levels = c("N/A", "Stent.Angioplasty", "Standalone.Angioplasty", "Both"))

vein.KM.dataframe = inguinal.ligament.data.frame %>%
  select(record_id, Follow.Up.Duration) %>%
  right_join(vein.KM.dataframe, by = "record_id") %>%
  # Time until Restenosis or Patient Censor (Patient Lost to Follow-up)
  mutate(Time.Restenosis.Censor = ifelse(!is.na(First.Restenosis.Date), 
                                         round(as.numeric(difftime(as.Date(First.Restenosis.Date), Stent.Placement.Date, units = "days")), digits = 0),
                                         Follow.Up.Duration)) %>%
  mutate(Time.Retenosis.Censor.Months = Time.Restenosis.Censor / 365.25 * 12) %>%
  # Modify Restenosis Labels based on Kaplan-Meier Time Threshold
  mutate(Time.Restenosis.Censor.Modified = ifelse(Time.Retenosis.Censor.Months > KM.time.threshold, KM.time.threshold, Time.Retenosis.Censor.Months)) %>%
  mutate(Restenosis.Label = ifelse(Restenosis.Status == "Restenosis" & Time.Retenosis.Censor.Months <= KM.time.threshold, 1, 0))

vein.restenosis.fit = survfit(Surv(Time.Restenosis.Censor.Modified, 
                                   Restenosis.Label) ~ Iliac.Femoral.Vein.Status, data = vein.KM.dataframe)

KM.plot.title = "Iliac vs. Femoral Vein In-Stent Restenosis Kaplan Meier Analysis"

# Vein-Level Restenosis Kaplan Meier Plot
KM.plot = ggsurvplot(vein.restenosis.fit, conf.int = TRUE, 
                     title = KM.plot.title, xlab = "Months", ylab = "Retenosis-Free Probability",
                     risk.table = TRUE, break.x.by = 6, pval = TRUE, pval.method = TRUE,
                     tables.height = 0.3, pval.size = 5, pval.method.size = 5, fontsize = 5, 
                     risk.table.title = "Number of Stented Veins at Risk")

KM.plot$plot = KM.plot$plot + 
  theme(plot.title = element_text(hjust = 0.5), legend.text = element_text(size = 14),
        legend.title = element_text(size = 14))

# Left Limb Kaplan Meier Dataframe
left.limb.KM.dataframe = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Follow.Up.Duration, 
         primary.patency.left.leg.span, Left.Leg.Final.Primary.Patency.Status, Gender, Ethnicity, Age.at.Intervention,
         IVC.Status, Thrombophilia.Risk.Factor.Status, Left.Leg.DVT.Lymphedema.Status, First.Left.Leg.Restenosis.Date, Followup.Start.Date) %>%
  filter(!is.na(Left.Limb.Status)) %>%
  # Time until Patency or Patient Censor (Patient Lost to Follow-up)
  mutate(Time.Patency.Censor = ifelse(!is.na(primary.patency.left.leg.span), 
                                      primary.patency.left.leg.span, Follow.Up.Duration)) %>%
  # Time until Restenosis or Patient Censor (Patient Lost to Follow-up)
  mutate(Time.Restenosis.Censor = ifelse(!is.na(First.Left.Leg.Restenosis.Date), 
                                         round(as.numeric(difftime(as.Date(First.Left.Leg.Restenosis.Date), Followup.Start.Date, units = "days")), digits = 0),
                                         Follow.Up.Duration)) %>%
  mutate(Time.Patency.Censor.Months = Time.Patency.Censor / 365.25 * 12) %>%
  mutate(Time.Restenosis.Censor.Months = Time.Restenosis.Censor / 365.25 * 12) %>%
  # Modify Patency Label based on Kaplan Meier Analysis Threshold
  mutate(Time.Patency.Censor.Months.Modified = ifelse(Time.Patency.Censor.Months > KM.time.threshold, KM.time.threshold, Time.Patency.Censor.Months)) %>%
  # Modify Restenosis Label based on Kaplan Meier Analysis Threshold
  mutate(Time.Restenosis.Censor.Months.Modified = ifelse(Time.Restenosis.Censor.Months > KM.time.threshold, KM.time.threshold, Time.Restenosis.Censor.Months)) %>%
  mutate(Patency.Label = ifelse(Left.Leg.Final.Primary.Patency.Status == "Primary.Patency.Lost" & Time.Patency.Censor.Months <= KM.time.threshold, 1, 0)) %>%
  mutate(Restenosis.Label = ifelse(!is.na(First.Left.Leg.Restenosis.Date) & Time.Restenosis.Censor.Months <= KM.time.threshold, 1, 0)) %>%
  mutate(Limb.Status = Left.Limb.Status) %>%
  mutate(Limb.Laterality = "Left") %>%
  mutate(Leg.DVT.Lymphedema.Status = Left.Leg.DVT.Lymphedema.Status) %>%
  select(Limb.Status, Limb.Laterality, Patency.Label, Time.Patency.Censor.Months.Modified,
         Gender, Ethnicity, Age.at.Intervention, IVC.Status, Thrombophilia.Risk.Factor.Status, 
         Leg.DVT.Lymphedema.Status, Restenosis.Label, Time.Restenosis.Censor.Months.Modified)

# Right Limb Kaplan Meier Dataframe
right.limb.KM.dataframe = inguinal.ligament.data.frame %>%
  select(record_id, Right.Limb.Status, Follow.Up.Duration, 
         primary.patency.right.leg.span, Right.Leg.Final.Primary.Patency.Status, Gender, Ethnicity, Age.at.Intervention,
         IVC.Status, Thrombophilia.Risk.Factor.Status, Right.Leg.DVT.Lymphedema.Status, First.Right.Leg.Restenosis.Date, Followup.Start.Date) %>%
  filter(!is.na(Right.Limb.Status)) %>%
  # Time until Patency or Patient Censor (Patient Lost to Follow-up)
  mutate(Time.Patency.Censor = ifelse(!is.na(primary.patency.right.leg.span), 
                                      primary.patency.right.leg.span, Follow.Up.Duration)) %>%
  # Time until Restenosis or Patient Censor (Patient Lost to Follow-up)
  mutate(Time.Restenosis.Censor = ifelse(!is.na(First.Right.Leg.Restenosis.Date), 
                                         round(as.numeric(difftime(as.Date(First.Right.Leg.Restenosis.Date), Followup.Start.Date, units = "days")), digits = 0),
                                         Follow.Up.Duration)) %>%
  mutate(Time.Patency.Censor.Months = Time.Patency.Censor / 365.25 * 12) %>%
  mutate(Time.Restenosis.Censor.Months = Time.Restenosis.Censor / 365.25 * 12) %>%
  # Modify Patency Label based on Kaplan Meier Analysis Threshold
  mutate(Time.Patency.Censor.Months.Modified = ifelse(Time.Patency.Censor.Months > KM.time.threshold, KM.time.threshold, Time.Patency.Censor.Months)) %>%
  # Modify Restenosis Label based on Kaplan Meier Analysis Threshold
  mutate(Time.Restenosis.Censor.Months.Modified = ifelse(Time.Restenosis.Censor.Months > KM.time.threshold, KM.time.threshold, Time.Restenosis.Censor.Months)) %>%
  mutate(Patency.Label = ifelse(Right.Leg.Final.Primary.Patency.Status == "Primary.Patency.Lost" & Time.Patency.Censor.Months <= KM.time.threshold, 1, 0)) %>%
  mutate(Restenosis.Label = ifelse(!is.na(First.Right.Leg.Restenosis.Date) & Time.Restenosis.Censor.Months <= KM.time.threshold, 1, 0)) %>%
  mutate(Limb.Status = Right.Limb.Status) %>%
  mutate(Limb.Laterality = "Right") %>%
  mutate(Leg.DVT.Lymphedema.Status = Right.Leg.DVT.Lymphedema.Status) %>%
  select(Limb.Status, Limb.Laterality, Patency.Label, Time.Patency.Censor.Months.Modified, Gender, 
         Ethnicity, Age.at.Intervention, IVC.Status, Thrombophilia.Risk.Factor.Status, Leg.DVT.Lymphedema.Status,
         Restenosis.Label, Time.Restenosis.Censor.Months.Modified)

# Left and Right limb Kaplan Meier Analysis Dataframe
limb.KM.dataframe = rbind.data.frame(left.limb.KM.dataframe, right.limb.KM.dataframe)

limb.KM.dataframe$Leg.DVT.Lymphedema.Status = as.character(limb.KM.dataframe$Leg.DVT.Lymphedema.Status)

limb.KM.dataframe$Leg.DVT.Lymphedema.Status[is.na(limb.KM.dataframe$Leg.DVT.Lymphedema.Status)] = "N/A"

limb.KM.dataframe$Leg.DVT.Lymphedema.Status = factor(limb.KM.dataframe$Leg.DVT.Lymphedema.Status, levels = c("N/A", "Lymphedema", "Unprovoked.DVT",
      "Provoked.DVT", "Both, Unprovoked.DVT", "Both, Provoked.DVT"))

limb.patency.fit = survfit(Surv(Time.Patency.Censor.Months.Modified, 
                                Patency.Label) ~ Limb.Status, data = limb.KM.dataframe)

KM.plot.title = "Above vs. Below Inguinal Ligament Limb Patency Rate Kaplan Meier Analysis"

# Limb-Level Patency Kaplan Meier Analysis Plot

setwd(visualizations.directory)

#tiff(paste("Limb_Patency_KM_Plot.tiff", sep = " "), res = 300, 
     #width = 350, height = (350 * 0.75), units = 'mm')
KM.plot = ggsurvplot(limb.patency.fit, conf.int = TRUE, 
                     title = KM.plot.title, xlab = "Months", ylab = "Primary Patency Probability",
                     risk.table = TRUE, break.x.by = 6, pval = TRUE, pval.method = TRUE,
                     pval.size = 6, pval.method.size = 6, fontsize = 6,
                     risk.table.title = "Number of Stented Limbs at Risk",
                     font.x = c(16), font.y = c(16), font.tickslab = c(16))

KM.plot$plot = KM.plot$plot + 
  theme(plot.title = element_text(hjust = 0.5, size = 18), legend.text = element_text(size = 16),
        legend.title = element_text(size = 16))

KM.plot$table = ggpubr::ggpar(KM.plot$table, font.xtickslab = list(size = 16), 
                              font.ytickslab = list(size = 16), font.x = list(size = 16),
                              font.y = list(size = 16))

print(KM.plot)
#dev.off()

limb.restenosis.fit = survfit(Surv(Time.Restenosis.Censor.Months.Modified, 
    Restenosis.Label) ~ Limb.Status, data = limb.KM.dataframe)

KM.plot.title = "Above vs. Below Inguinal Ligament Limb Restenosis Rate Kaplan Meier Analysis"

#tiff(paste("Limb_Restenosis_KM_Plot.tiff", sep = " "), res = 300, 
     #width = 350, height = (350 * 0.75), units = 'mm')
# Limb-Level Restenosis Kaplan Meier Analysis Plot
KM.plot = ggsurvplot(limb.restenosis.fit, conf.int = TRUE, 
                     title = KM.plot.title, xlab = "Months", ylab = "Restenosis-Free Probability",
                     risk.table = TRUE, break.x.by = 6, pval = TRUE, pval.method = TRUE,
                     pval.size = 6, pval.method.size = 6, fontsize = 6,
                     risk.table.title = "Number of Stented Limbs at Risk",
                     font.x = c(16), font.y = c(16), font.tickslab = c(16))

KM.plot$plot = KM.plot$plot + 
  theme(plot.title = element_text(hjust = 0.5, size = 18), legend.text = element_text(size = 16),
        legend.title = element_text(size = 16))

KM.plot$table = ggpubr::ggpar(KM.plot$table, font.xtickslab = list(size = 16), 
                              font.ytickslab = list(size = 16), font.x = list(size = 16),
                              font.y = list(size = 16))

print(KM.plot)
#dev.off()
