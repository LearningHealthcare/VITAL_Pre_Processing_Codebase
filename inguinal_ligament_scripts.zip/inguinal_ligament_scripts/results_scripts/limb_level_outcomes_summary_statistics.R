# limb_level_outcomes_summary_statistics.R

# This script calculates limb-level outcome summary statistics relating to
# patency and in-stent restenosis outcomes.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Left Limb Patency Summary Statistics
left.limb.level.patency.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Left.Leg.Final.Primary.Patency.Status) %>%
  filter(!is.na(Left.Limb.Status)) %>%
  group_by(Left.Limb.Status, Left.Leg.Final.Primary.Patency.Status) %>%
  summarise(Left.Leg.Cohort.Count = n()) %>%
  spread(Left.Leg.Final.Primary.Patency.Status, Left.Leg.Cohort.Count)

names(left.limb.level.patency.summary.statistics) = c("Limb.Status", "Left.Leg.Primary.Patency", 
    "Left.Leg.Primary.Patency.Lost")

left.limb.level.patency.summary.statistics$Limb.Status = as.character(left.limb.level.patency.summary.statistics$Limb.Status)

# Left Limb Restenosis Summary Statistics
left.limb.level.restenosis.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, First.Left.Leg.Restenosis.Date) %>%
  filter(!is.na(Left.Limb.Status)) %>%
  mutate(Left.Leg.Restenosis.Status = ifelse(!is.na(First.Left.Leg.Restenosis.Date), "Restenosis", "No.Restenosis")) %>%
  group_by(Left.Limb.Status, Left.Leg.Restenosis.Status) %>%
  summarise(Left.Leg.Cohort.Count = n()) %>%
  spread(Left.Leg.Restenosis.Status, Left.Leg.Cohort.Count)

names(left.limb.level.restenosis.summary.statistics) = c("Limb.Status", "Left.Leg.No.Restenosis", "Left.Leg.Restenosis")

# Right Limb Patency Summary Statistics
right.limb.level.patency.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Right.Limb.Status, Right.Leg.Final.Primary.Patency.Status) %>%
  filter(!is.na(Right.Limb.Status)) %>%
  group_by(Right.Limb.Status, Right.Leg.Final.Primary.Patency.Status) %>%
  summarise(Right.Leg.Cohort.Count = n()) %>%
  spread(Right.Leg.Final.Primary.Patency.Status, Right.Leg.Cohort.Count)

names(right.limb.level.patency.summary.statistics) = c("Limb.Status", "Right.Leg.Primary.Patency", 
              "Right.Leg.Primary.Patency.Lost")

right.limb.level.patency.summary.statistics$Limb.Status = as.character(right.limb.level.patency.summary.statistics$Limb.Status)

# Right Limb Restenosis Summary Statistics
right.limb.level.restenosis.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Right.Limb.Status, First.Right.Leg.Restenosis.Date) %>%
  filter(!is.na(Right.Limb.Status)) %>%
  mutate(Right.Leg.Restenosis.Status = ifelse(!is.na(First.Right.Leg.Restenosis.Date), "Restenosis", "No.Restenosis")) %>%
  group_by(Right.Limb.Status, Right.Leg.Restenosis.Status) %>%
  summarise(Right.Leg.Cohort.Count = n()) %>%
  spread(Right.Leg.Restenosis.Status, Right.Leg.Cohort.Count)

names(right.limb.level.restenosis.summary.statistics) = c("Limb.Status", "Right.Leg.No.Restenosis", "Right.Leg.Restenosis")

limb.level.patency.summary.statistics = cbind.data.frame(left.limb.level.patency.summary.statistics, 
      right.limb.level.patency.summary.statistics[, -1])

limb.level.restenosis.summary.statistics = cbind.data.frame(left.limb.level.restenosis.summary.statistics, 
     right.limb.level.restenosis.summary.statistics[, -1])

# Right and Left Limb Patency Summary Statistics
limb.level.patency.summary.statistics = limb.level.patency.summary.statistics %>%
  mutate(Limb.Primary.Patency.Count = Left.Leg.Primary.Patency + Right.Leg.Primary.Patency) %>%
  mutate(Limb.Primary.Patency.Lost.Count = Left.Leg.Primary.Patency.Lost + Right.Leg.Primary.Patency.Lost)

# Right and Left Limb Restenosis Summary Statistics
limb.level.restenosis.summary.statistics = limb.level.restenosis.summary.statistics %>%
  mutate(Limb.Restenosis.Count = Left.Leg.Restenosis + Right.Leg.Restenosis) %>%
  mutate(Limb.No.Restenosis.Count = Left.Leg.No.Restenosis + Right.Leg.No.Restenosis)