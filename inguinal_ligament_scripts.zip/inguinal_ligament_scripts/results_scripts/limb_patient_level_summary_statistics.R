# limb_level_summary_statistics.R

# This script calculates most of the summary statistics
# for the limb-level and patient-level analyses.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Number of Limbs in Limb-Level Analysis
limb.level.limb.count = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Right.Limb.Status) %>%
  gather(Limb, Limb.Status, -record_id) %>%
  filter(!is.na(Limb.Status)) %>%
  unique()

limb.level.limb.count = nrow(limb.level.limb.count)

# Number patients considered in Limb-Level Analysis
limb.level.patient.count = inguinal.ligament.data.frame %>%
  select(record_id) %>%
  unique()

limb.level.patient.count = nrow(limb.level.patient.count)

# Number of Limbs by Laterality
limb.level.limb.laterality = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Right.Limb.Status) %>%
  gather(Limb, Limb.Status, -record_id) %>%
  filter(!is.na(Limb.Status)) %>%
  unique() %>%
  group_by(Limb) %>%
  summarise(Limb.Count = n())

# Number of Limbs by Laterality and Inguinal Ligament Status
limb.level.inguinal.count = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Right.Limb.Status) %>%
  gather(Limb, Limb.Status, -record_id) %>%
  filter(!is.na(Limb.Status)) %>%
  unique() %>%
  group_by(Limb, Limb.Status) %>%
  summarise(Limb.Count = n())

# Number of Limbs by Iliac/Femoral/Iliofemoral Status
limb.level.ilio.femoral.count = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Iliofemoral.Status, Right.Limb.Iliofemoral.Status) %>%
  gather(Limb, Limb.Status, -record_id) %>%
  filter(!is.na(Limb.Status)) %>%
  unique() %>%
  group_by(Limb.Status) %>%
  summarise(Limb.Count = n())

# Number of patients by Gender
patient.gender.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Gender) %>%
  group_by(Gender) %>%
  summarise(Cohort.Count = n())

# Number of Limbs by Gender of Patient and Inguinal Ligament Status
limb.gender.inguinal.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Right.Limb.Status, Gender) %>%
  gather(Limb, Limb.Status, -record_id, -Gender) %>%
  filter(!is.na(Limb.Status)) %>%
  unique() %>%
  group_by(Limb.Status, Gender) %>%
  summarise(Cohort.count = n()) %>%
  spread(Gender, Cohort.count)

# Number of patients by Ethnicity
patient.ethnicity.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Ethnicity) %>%
  group_by(Ethnicity) %>%
  summarise(Cohort.Count = n()) %>%
  arrange(desc(Cohort.Count))

# Number of Limbs by Ethnicity and Inguinal Ligament Status
limb.ethnicity.inguinal.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Right.Limb.Status, Ethnicity) %>%
  gather(Limb, Limb.Status, -record_id, -Ethnicity) %>%
  filter(!is.na(Limb.Status)) %>%
  unique() %>%
  group_by(Limb.Status, Ethnicity) %>%
  summarise(Cohort.count = n()) %>%
  spread(Ethnicity, Cohort.count)

# Median Patient Age
median.patient.age = median(inguinal.ligament.data.frame$Age.at.Intervention)

# Median Patient Age by Gender
patient.gender.age.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Gender, Age.at.Intervention) %>%
  group_by(Gender) %>%
  summarise(Median.Age = median(Age.at.Intervention))

# Median Age of Patient by Limb Inguinal Ligament Status
limb.age.inguinal.summary.statistics = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Right.Limb.Status, Age.at.Intervention) %>%
  gather(Limb, Limb.Status, -record_id, -Age.at.Intervention) %>%
  filter(!is.na(Limb.Status)) %>%
  unique() %>%
  group_by(Limb.Status) %>%
  summarise(Median.Age = median(Age.at.Intervention))

# Above Inguinal Ligament Stented Limbs associated patient ages at Intervention
above.inguinal.ligament.age.at.intervention = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Right.Limb.Status, Age.at.Intervention) %>%
  gather(Limb, Limb.Status, -record_id, -Age.at.Intervention) %>%
  filter(!is.na(Limb.Status)) %>%
  unique() %>%
  filter(Limb.Status == "Above.Inguinal.Ligament") %>%
  select(Age.at.Intervention)

# Below Inguinal Ligament Stented Limbs associated patient ages at Intervention
below.inguinal.ligament.age.at.intervention = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Right.Limb.Status, Age.at.Intervention) %>%
  gather(Limb, Limb.Status, -record_id, -Age.at.Intervention) %>%
  filter(!is.na(Limb.Status)) %>%
  unique() %>%
  filter(Limb.Status == "Below.Inguinal.Ligament") %>%
  select(Age.at.Intervention)

# median patient follow-up duration
median.follow.up = median(inguinal.ligament.data.frame$Follow.Up.Duration)

# followup duration range
follow.up.range = range(inguinal.ligament.data.frame$Follow.Up.Duration)

# Number of Patients by Left and Right Limb Inguinal Ligament Status
patient.level.inguinal.ligament.label = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Right.Limb.Status) %>%
  mutate(Overall.Inguinal.Ligament.Status = ifelse(!is.na(Left.Limb.Status) & !is.na(Right.Limb.Status),
        paste(Left.Limb.Status, Right.Limb.Status, sep = "; "), 
        ifelse(!is.na(Left.Limb.Status) & is.na(Right.Limb.Status), paste(Left.Limb.Status, "None", sep = "; "),
        ifelse(is.na(Left.Limb.Status) & !is.na(Right.Limb.Status), paste("None", Right.Limb.Status, sep = "; "),
              "None; None")))) %>%
  group_by(Overall.Inguinal.Ligament.Status) %>%
  summarise(Cohort.Count = n()) %>%
  arrange(desc(Cohort.Count))