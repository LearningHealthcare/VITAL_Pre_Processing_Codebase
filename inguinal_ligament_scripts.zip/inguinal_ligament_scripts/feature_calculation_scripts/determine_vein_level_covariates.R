# determine_vein_level_covariates.R

# This script calculates vein level covariates for use in subsequent analyses.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

source(paste(feature.calculation.code.directory, 'determine_stent_brand_diameter_length_status.R', sep = '/'))

source(paste(feature.calculation.code.directory, 'determine_dvt_on_imaging.R', sep = '/'))

source(paste(feature.calculation.code.directory, 'determine_angioplasty_status.R', sep = '/'))
