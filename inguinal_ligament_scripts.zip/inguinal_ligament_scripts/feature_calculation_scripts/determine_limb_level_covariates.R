# determine_limb_level_covariates.R

# This script calculates patient/limb level covariates, such as Age at Time of Stent Placement,
# Gender, Ethnicity etc.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

inguinal.ligament.data.frame = demographics.data %>%
  select(record_id, DOB, Gender, Ethnicity) %>%
  right_join(inguinal.ligament.data.frame, by = "record_id") %>%
  # Age at Time of Stent Placement
  mutate(Age.at.Intervention.Days = round(as.numeric(difftime(Followup.Start.Date, DOB, units = "days")), digits = 0)) %>%
  mutate(Age.at.Intervention = Age.at.Intervention.Days / 365.25) %>%
  select(-Age.at.Intervention.Days)

inguinal.ligament.data.frame = thrombophilia.vte.data %>%
  select(record_id, Thrombophilia.Risk.Factor.Status) %>%
  unique() %>%
  right_join(inguinal.ligament.data.frame, by = "record_id")

inguinal.ligament.data.frame$Thrombophilia.Risk.Factor.Status[is.na(inguinal.ligament.data.frame$Thrombophilia.Risk.Factor.Status)] = "No"

# Limb Level DVT/Lymphedema Calculations
dvt.risk.factor.data = filter(dvt.risk.factor.data, !is.na(vtedate) & !is.na(VTE.Provoked.Status) & !is.na(DVT.Laterality.Status))

# Convert Limb DVT Date to date-time object
dvt.risk.factor.data$vtedate = as.POSIXct(dvt.risk.factor.data$vtedate)

lymphedema.risk.factor.data = filter(lymphedema.risk.factor.data, !is.na(vtedate) & !is.na(Lymphedema.Laterality.Status))

# Convert Limb Lymphedema Date to date-time object
lymphedema.risk.factor.data$vtedate = as.POSIXct(lymphedema.risk.factor.data$vtedate)

Left.Leg.DVT.Lymphedema.Status = rep(NA, times = nrow(inguinal.ligament.data.frame))

Right.Leg.DVT.Lymphedema.Status = rep(NA, times = nrow(inguinal.ligament.data.frame))

# Calculate Limb DVT/Lymphedema VTE History at time of Stent Placement Date
for(i in 1:nrow(inguinal.ligament.data.frame)){
  stent.patient = inguinal.ligament.data.frame$record_id[i]
  stent.placement.date = inguinal.ligament.data.frame$Followup.Start.Date[i]
  # Calculate Left Limb DVT/Lymphedema Medical History Status
  if(!is.na(inguinal.ligament.data.frame$Left.Limb.Status[i])){
    # DVT VTE History data
    dvt.patient.data = dvt.risk.factor.data %>%
      filter(record_id == stent.patient) %>%
      # Span between DVT VTE Date and Stent placement Date
      mutate(DVT.Follow.Up.Span = round(as.numeric(difftime(vtedate, stent.placement.date, units = "days")), digits = 0)) %>%
      filter(DVT.Follow.Up.Span <= 0) %>%
      # Left Limb DVT data
      filter(DVT.Laterality.Status == "Left" | DVT.Laterality.Status == "Bilateral") %>%
      arrange(desc(vtedate))
    if(nrow(dvt.patient.data) > 0){
      dvt.provoked.status = dvt.patient.data$VTE.Provoked.Status[1]
      if(dvt.provoked.status == "Yes"){
        Left.Leg.DVT.Lymphedema.Status[i] = "Provoked.DVT"
      }else{
        Left.Leg.DVT.Lymphedema.Status[i] = "Unprovoked.DVT"
      }
    }
    # Lymphedema VTE History Data
    lymphedema.patient.data = lymphedema.risk.factor.data %>%
      filter(record_id == stent.patient) %>%
      # Span between Lymphedema VTE Date and Stent placement Date
      mutate(Lymphedema.Follow.Up.Span = round(as.numeric(difftime(vtedate, stent.placement.date, units = "days")), digits = 0)) %>%
      filter(Lymphedema.Follow.Up.Span <= 0) %>%
      # Left Limb Lymphedema Data
      filter(Lymphedema.Laterality.Status == "Left" | Lymphedema.Laterality.Status == "Bilateral") %>%
      arrange(desc(vtedate))
    if(nrow(lymphedema.patient.data) > 0){
      if(!is.na(Left.Leg.DVT.Lymphedema.Status[i])){
        if(Left.Leg.DVT.Lymphedema.Status[i] == "Provoked.DVT"){
          Left.Leg.DVT.Lymphedema.Status[i] = "Both, Provoked.DVT"
        }else{
          Left.Leg.DVT.Lymphedema.Status[i] = "Both, Unprovoked.DVT"
        }
      }else{
        Left.Leg.DVT.Lymphedema.Status[i] = "Lymphedema"
      }
    }
  }
  # Calculate Right Limb DVT/Lymphedema Medical History Status
  if(!is.na(inguinal.ligament.data.frame$Right.Limb.Status[i])){
    # DVT VTE History data
    dvt.patient.data = dvt.risk.factor.data %>%
      filter(record_id == stent.patient) %>%
      # Span between DVT VTE Date and Stent placement Date
      mutate(DVT.Follow.Up.Span = round(as.numeric(difftime(vtedate, stent.placement.date, units = "days")), digits = 0)) %>%
      filter(DVT.Follow.Up.Span <= 0) %>%
      # Right Limb DVT data
      filter(DVT.Laterality.Status == "Right" | DVT.Laterality.Status == "Bilateral") %>%
      arrange(desc(vtedate))
    if(nrow(dvt.patient.data) > 0){
      dvt.provoked.status = dvt.patient.data$VTE.Provoked.Status[1]
      if(dvt.provoked.status == "Yes"){
        Right.Leg.DVT.Lymphedema.Status[i] = "Provoked.DVT"
      }else{
        Right.Leg.DVT.Lymphedema.Status[i] = "Unprovoked.DVT"
      }
    }
    # Lymphedema VTE History Data
    lymphedema.patient.data = lymphedema.risk.factor.data %>%
      filter(record_id == stent.patient) %>%
      # Span between Lymphedema VTE Date and Stent placement Date
      mutate(Lymphedema.Follow.Up.Span = round(as.numeric(difftime(vtedate, stent.placement.date, units = "days")), digits = 0)) %>%
      filter(Lymphedema.Follow.Up.Span <= 0) %>%
      # Right Limb Lymphedema Data
      filter(Lymphedema.Laterality.Status == "Right" | Lymphedema.Laterality.Status == "Bilateral") %>%
      arrange(desc(vtedate))
    if(nrow(lymphedema.patient.data) > 0){
      if(!is.na(Right.Leg.DVT.Lymphedema.Status[i])){
        if(Right.Leg.DVT.Lymphedema.Status[i] == "Provoked.DVT"){
          Right.Leg.DVT.Lymphedema.Status[i] = "Both, Provoked.DVT"
        }else{
          Right.Leg.DVT.Lymphedema.Status[i] = "Both, Unprovoked.DVT"
        }
      }else{
        Right.Leg.DVT.Lymphedema.Status[i] = "Lymphedema"
      }
    }
  }
}

inguinal.ligament.data.frame = cbind.data.frame(inguinal.ligament.data.frame, Left.Leg.DVT.Lymphedema.Status, 
    Right.Leg.DVT.Lymphedema.Status)