# determine_in_stent_restenosis_status.R

# This script determines the in-stent restenosis status for both vein and limb-level
# data, and if applicable, determines the first appearance of restenosis in the vein/limb in question
# after the stent placement date/first Stanford procedure.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

First.Restenosis.Date = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))

# Vein-Level Restenosis Calculations
for(i in 1:nrow(inguinal.ligament.stented.vein.cohort)){
  stent.patient = inguinal.ligament.stented.vein.cohort$record_id[i]
  stented.vein = inguinal.ligament.stented.vein.cohort$Vein[i]
  stent.placement.date = as.Date(inguinal.ligament.stented.vein.cohort$Stent.Placement.Date[i])
  patient.vein.imaging.data = stent.restenosis.imaging.data %>%
    filter(record_id == stent.patient) %>%
    filter(Vein == stented.vein) %>%
    filter(Status == "In-stent Restenosis") %>%
    # Span between in-stent restenosis imaging and stent placement date
    mutate(Stent.Placement.Restenosis.Span = round(as.numeric(difftime(Imaging.Date, 
          stent.placement.date, units = "days")), digits = 0)) %>%
    filter(Stent.Placement.Restenosis.Span >= 0) %>%
    select(-Stent.Placement.Restenosis.Span)
  if(nrow(patient.vein.imaging.data) > 0){
    # First appearance of in-stent re-stenosis in Stented Vein
    patient.vein.imaging.data = arrange(patient.vein.imaging.data, Imaging.Date)
    First.Restenosis.Date[i] = as.character(patient.vein.imaging.data$Imaging.Date[1])
  }
}

inguinal.ligament.stented.vein.cohort = cbind.data.frame(inguinal.ligament.stented.vein.cohort,
    First.Restenosis.Date)

First.Left.Leg.Restenosis.Date = rep(NA, times = nrow(inguinal.ligament.data.frame))

First.Right.Leg.Restenosis.Date = rep(NA, times = nrow(inguinal.ligament.data.frame))

# Limb-Level Restenosis Calculations
for(i in 1:nrow(inguinal.ligament.data.frame)){
  stent.patient = inguinal.ligament.data.frame$record_id[i]
  stent.placement.date = as.Date(inguinal.ligament.data.frame$Followup.Start.Date[i])
  patient.left.leg.vein.restenosis.data = inguinal.ligament.stented.vein.cohort %>%
    filter(record_id == stent.patient) %>%
    filter(!is.na(First.Restenosis.Date)) %>%
    filter(Vein %in% left.leg.veins) 
  if(nrow(patient.left.leg.vein.restenosis.data) > 0){
    # Calculate first appearance of re-stenosis in left leg after first Stanford intervention
    patient.left.leg.vein.restenosis.data$First.Restenosis.Date = as.POSIXct(patient.left.leg.vein.restenosis.data$First.Restenosis.Date)
    patient.left.leg.vein.restenosis.data = arrange(patient.left.leg.vein.restenosis.data, First.Restenosis.Date)
    First.Left.Leg.Restenosis.Date[i] = as.character(patient.left.leg.vein.restenosis.data$First.Restenosis.Date[1])
  }
  
  patient.right.leg.vein.restenosis.data = inguinal.ligament.stented.vein.cohort %>%
    filter(record_id == stent.patient) %>%
    filter(!is.na(First.Restenosis.Date)) %>%
    filter(Vein %in% right.leg.veins) 
  if(nrow(patient.right.leg.vein.restenosis.data) > 0){
    # Calculate first appearance of re-stenosis in right leg after first Stanford intervention
    patient.right.leg.vein.restenosis.data$First.Restenosis.Date = as.POSIXct(patient.right.leg.vein.restenosis.data$First.Restenosis.Date)
    patient.right.leg.vein.restenosis.data = arrange(patient.right.leg.vein.restenosis.data, First.Restenosis.Date)
    First.Right.Leg.Restenosis.Date[i] = as.character(patient.right.leg.vein.restenosis.data$First.Restenosis.Date[1])
  }
}

inguinal.ligament.data.frame = cbind.data.frame(inguinal.ligament.data.frame, First.Left.Leg.Restenosis.Date, First.Right.Leg.Restenosis.Date)
