# determine_pre_post_stenting_diameters.R

# This script determines the vein diameters for stented veins both before and after
# the stenting procedure. In particular, the script identifies the vein diameter measurement, before
# the stent placement date, that is closest to the intervention. In turn, the script
# also identifies the vein diameter, after the stent placement date, that is closest to
# the intervention.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

for(i in 1:nrow(inguinal.ligament.stented.vein.cohort)){
  stented.patient = inguinal.ligament.stented.vein.cohort$record_id[i]
  stented.vein = inguinal.ligament.stented.vein.cohort$Vein[i]
  stent.placement.date = inguinal.ligament.stented.vein.cohort$Stent.Placement.Date[i]
  patient.vein.data = vein.diameter.imaging.data %>%
    filter(record_id == stented.patient) %>%
    filter(Vein == stented.vein) %>%
    # Consider Vein Diameters on CT Venography or MR Venography only
    filter(Imaging.Study.Modality == "CT Venography" | Imaging.Study.Modality == "MR Venography") %>%
    mutate(Stent.Placement.Date = stent.placement.date) %>%
    # Span between vein diameter measurement date and stent placement date
    mutate(Imaging.Stent.Placement.Span = round(as.numeric(difftime(date, as.Date(Stent.Placement.Date), 
                                                units = "days")), digits = 0))
  # Non-IVC vein diameter calculations
  if(stented.vein != "Infrarenal.IVC" | stented.vein != "Suprarenal.IVC"){
    patient.max.vein.before.stenting.data = patient.vein.data %>%
      filter(Imaging.Stent.Placement.Span < 0 & Imaging.Stent.Placement.Span > -imaging.window) %>%
      filter(Measurement.Type == "Max") %>%
      arrange(desc(date))
    if(nrow(patient.max.vein.before.stenting.data) > 0){
      Max.Diameter.Before.Stenting.Span[i] = patient.max.vein.before.stenting.data$Imaging.Stent.Placement.Span[1]
      Max.Diameter.Before.Stenting[i] = patient.max.vein.before.stenting.data$Diameter[1]
    }
    patient.min.vein.before.stenting.data = patient.vein.data %>%
      filter(Imaging.Stent.Placement.Span < 0 & Imaging.Stent.Placement.Span > -imaging.window) %>%
      filter(Measurement.Type == "Min") %>%
      arrange(desc(date))
    if(nrow(patient.min.vein.before.stenting.data) > 0){
      Min.Diameter.Before.Stenting.Span[i] = patient.min.vein.before.stenting.data$Imaging.Stent.Placement.Span[1]
      Min.Diameter.Before.Stenting[i] = patient.min.vein.before.stenting.data$Diameter[1]
    }
    patient.max.vein.after.stenting.data = patient.vein.data %>%
      filter(Imaging.Stent.Placement.Span > 0 & Imaging.Stent.Placement.Span < imaging.window) %>%
      filter(Measurement.Type == "Max") %>%
      arrange(date)
    if(nrow(patient.max.vein.after.stenting.data) > 0){
      Max.Diameter.After.Stenting.Span[i] = patient.max.vein.after.stenting.data$Imaging.Stent.Placement.Span[1]
      Max.Diameter.After.Stenting[i] = patient.max.vein.after.stenting.data$Diameter[1]
    }
    patient.min.vein.after.stenting.data = patient.vein.data %>%
      filter(Imaging.Stent.Placement.Span > 0 & Imaging.Stent.Placement.Span < imaging.window) %>%
      filter(Measurement.Type == "Min") %>%
      arrange(date)
    if(nrow(patient.min.vein.after.stenting.data) > 0){
      Min.Diameter.After.Stenting.Span[i] = patient.min.vein.after.stenting.data$Imaging.Stent.Placement.Span[1]
      Min.Diameter.After.Stenting[i] = patient.min.vein.after.stenting.data$Diameter[1]
    }
  # IVC vein diameter calculations
  }else{
    patient.max.vein.before.stenting.data = patient.vein.data %>%
      filter(Imaging.Stent.Placement.Span < 0 & Imaging.Stent.Placement.Span > -imaging.window) %>%
      # Limit IVC diameter measurements to Major Axis
      filter(Axis == "Major") %>%
      filter(Measurement.Type == "Max") %>%
      arrange(desc(date))
    if(nrow(patient.max.vein.before.stenting.data) > 0){
      Max.Diameter.Before.Stenting.Span[i] = patient.max.vein.before.stenting.data$Imaging.Stent.Placement.Span[1]
      Max.Diameter.Before.Stenting[i] = patient.max.vein.before.stenting.data$Diameter[1]
    }
    patient.min.vein.before.stenting.data = patient.vein.data %>%
      filter(Imaging.Stent.Placement.Span < 0 & Imaging.Stent.Placement.Span > -imaging.window) %>%
      # Limit IVC diameter measurements to Major Axis
      filter(Axis == "Major") %>%
      filter(Measurement.Type == "Min") %>%
      arrange(desc(date))
    if(nrow(patient.min.vein.before.stenting.data) > 0){
      Min.Diameter.Before.Stenting.Span[i] = patient.min.vein.before.stenting.data$Imaging.Stent.Placement.Span[1]
      Min.Diameter.Before.Stenting[i] = patient.min.vein.before.stenting.data$Diameter[1]
    }
    patient.max.vein.after.stenting.data = patient.vein.data %>%
      filter(Imaging.Stent.Placement.Span > 0 & Imaging.Stent.Placement.Span < imaging.window) %>%
      # Limit IVC diameter measurements to Major Axis
      filter(Axis == "Major") %>%
      filter(Measurement.Type == "Max") %>%
      arrange(date)
    if(nrow(patient.max.vein.after.stenting.data) > 0){
      Max.Diameter.After.Stenting.Span[i] = patient.max.vein.after.stenting.data$Imaging.Stent.Placement.Span[1]
      Max.Diameter.Ater.Stenting[i] = patient.max.vein.after.stenting.data$Diameter[1]
    }
    patient.min.vein.after.stenting.data = patient.vein.data %>%
      filter(Imaging.Stent.Placement.Span > 0 & Imaging.Stent.Placement.Span < imaging.window) %>%
      # Limit IVC diameter measurements to Major Axis
      filter(Axis == "Major") %>%
      filter(Measurement.Type == "Min") %>%
      arrange(date)
    if(nrow(patient.min.vein.after.stenting.data) > 0){
      Min.Diameter.After.Stenting.Span[i] = patient.min.vein.after.stenting.data$Imaging.Stent.Placement.Span[1]
      Min.Diameter.After.Stenting[i] = patient.min.vein.after.stenting.data$Diameter[1]
    }
  }
}