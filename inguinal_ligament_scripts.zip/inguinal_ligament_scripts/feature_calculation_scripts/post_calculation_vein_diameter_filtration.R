# post_calculation_vein_diameter_filtration.R

# This script performs filtration on the vein diameter values identified in the previous
# script. More specifically, if a post-stenting diameter measurement has occured after
# primary patency status was lost (i.e the patient likely underwent a re-intervention),
# the vein diameter data post-stenting is removed from further consideration.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

inguinal.ligament.stented.vein.cohort = cbind.data.frame(inguinal.ligament.stented.vein.cohort, Max.Diameter.Before.Stenting, Max.Diameter.Before.Stenting.Span,
    Min.Diameter.Before.Stenting, Min.Diameter.Before.Stenting.Span, Max.Diameter.After.Stenting, Max.Diameter.After.Stenting.Span, Min.Diameter.After.Stenting,
    Min.Diameter.After.Stenting.Span)

for(i in 1:nrow(inguinal.ligament.stented.vein.cohort)){
  stented.vein = inguinal.ligament.stented.vein.cohort$Vein[i]
  # Check Left Leg Reintervention Status
  if(stented.vein %in% left.leg.veins & !is.na(inguinal.ligament.stented.vein.cohort$primary.patency.left.leg.span[i])){
    if(!is.na(inguinal.ligament.stented.vein.cohort$Max.Diameter.After.Stenting[i])){
      # Determine if vein measurement occured after Left Leg Reintervention
      if(inguinal.ligament.stented.vein.cohort$Max.Diameter.After.Stenting.Span[i] >= inguinal.ligament.stented.vein.cohort$primary.patency.left.leg.span[i]){
        inguinal.ligament.stented.vein.cohort$Max.Diameter.After.Stenting[i] = NA
        inguinal.ligament.stented.vein.cohort$Max.Diameter.After.Stenting.Span[i] = NA
      }
    }
    if(!is.na(inguinal.ligament.stented.vein.cohort$Min.Diameter.After.Stenting[i])){
      # Determine if vein measurement occured after Left Leg Reintervention
      if(inguinal.ligament.stented.vein.cohort$Min.Diameter.After.Stenting.Span[i] >= inguinal.ligament.stented.vein.cohort$primary.patency.left.leg.span[i]){
        inguinal.ligament.stented.vein.cohort$Min.Diameter.After.Stenting[i] = NA
        inguinal.ligament.stented.vein.cohort$Min.Diameter.After.Stenting.Span[i] = NA
      }
    }
  # Check Right Leg Reintervention Status
  }else if(stented.vein %in% right.leg.veins & !is.na(inguinal.ligament.stented.vein.cohort$primary.patency.right.leg.span[i])){
    if(!is.na(inguinal.ligament.stented.vein.cohort$Max.Diameter.After.Stenting[i])){
      # Determine if vein measurement occured after Right Leg Reintervention
      if(inguinal.ligament.stented.vein.cohort$Max.Diameter.After.Stenting.Span[i] >= inguinal.ligament.stented.vein.cohort$primary.patency.right.leg.span[i]){
        inguinal.ligament.stented.vein.cohort$Max.Diameter.After.Stenting[i] = NA
        inguinal.ligament.stented.vein.cohort$Max.Diameter.After.Stenting.Span[i] = NA
      }
    }
    if(!is.na(inguinal.ligament.stented.vein.cohort$Min.Diameter.After.Stenting[i])){
      # Determine if vein measurement occured after Right Leg Reintervention
      if(inguinal.ligament.stented.vein.cohort$Min.Diameter.After.Stenting.Span[i] >= inguinal.ligament.stented.vein.cohort$primary.patency.right.leg.span[i]){
        inguinal.ligament.stented.vein.cohort$Min.Diameter.After.Stenting[i] = NA
        inguinal.ligament.stented.vein.cohort$Min.Diameter.After.Stenting.Span[i] = NA
      }
    }
  }
}