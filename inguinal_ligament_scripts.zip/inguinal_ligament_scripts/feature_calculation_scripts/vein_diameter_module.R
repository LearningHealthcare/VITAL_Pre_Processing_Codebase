# determine_vein_diameter_change.R

# This overarching script is responsible for calculating changes in vein diameters both 
# before and after stent placement.

# By David Cohn

inguinal.ligament.stented.vein.cohort = inguinal.ligament.data.frame %>%
  select(record_id, Left.Limb.Status, Right.Limb.Status, primary.patency.left.leg.span, 
         primary.patency.right.leg.span) %>%
  right_join(inguinal.ligament.stented.vein.cohort, by = "record_id") %>%
  filter(!is.na(Left.Limb.Status) | !is.na(Right.Limb.Status))

Max.Diameter.Before.Stenting = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))
Max.Diameter.Before.Stenting.Span = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))
Min.Diameter.Before.Stenting = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))
Min.Diameter.Before.Stenting.Span = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))

Max.Diameter.After.Stenting = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))
Max.Diameter.After.Stenting.Span = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))
Min.Diameter.After.Stenting = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))
Min.Diameter.After.Stenting.Span = rep(NA, times = nrow(inguinal.ligament.stented.vein.cohort))

# Window, on either side of stent placement date, used in selecting vein diameter values
imaging.window = 365.25

source(paste(feature.calculation.code.directory, 'determine_pre_post_stenting_diameters.R', sep = '/'))

source(paste(feature.calculation.code.directory, 'post_calculation_vein_diameter_filtration.R', sep = '/'))
