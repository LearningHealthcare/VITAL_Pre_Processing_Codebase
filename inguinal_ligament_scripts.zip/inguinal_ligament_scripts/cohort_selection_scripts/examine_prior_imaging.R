# examine_prior_imaging.R

# This script examines imaging data, to confirm that there is no evidence of stenting
# on conventional venography imaging for the remaining patients of the analysis prior 
# to the first Stanford Procedure Date.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Stented Veins at time of first Stanford Procedure Date
first.Stanford.procedure.stent.locations = first.Stanford.procedure.dataframe %>%
  left_join(stent.location.procedure.data, by = c("record_id", "Procedure.Number")) %>%
  select(-Stent.Number, -Stent.Value, -Record.ID.Procedure.Identifier) %>%
  unique()

first.Stanford.procedure.stent.locations$Vein = as.character(first.Stanford.procedure.stent.locations$Vein)

# Combine Stent Restenosis/Present data with imaging study dates data
stent.restenosis.imaging.data = imaging.accession.date.mapping %>%
  select(record_id, Study.Number, date, Imaging.Study.Modality) %>%
  inner_join(stent.restenosis.imaging.data, by = c("record_id", "Study.Number")) %>%
  gather(Vein, Status, -record_id, -Study.Number, -date, -Imaging.Study.Modality) %>%
  filter(!is.na(Status))

stent.restenosis.imaging.data$Imaging.Date = stent.restenosis.imaging.data$date

stent.restenosis.imaging.data = select(stent.restenosis.imaging.data, -date)

first.conventional.venography.stent.present = rep(NA, 
  times = nrow(first.Stanford.procedure.stent.locations))

for(i in 1:length(first.conventional.venography.stent.present)){
  stent.patient = first.Stanford.procedure.stent.locations$record_id[i]
  stented.vein = first.Stanford.procedure.stent.locations$Vein[i]
  # Stented Vein Data on Conventional Venogram
  patient.vein.imaging.data = stent.restenosis.imaging.data %>%
    filter(record_id == stent.patient) %>%
    filter(Vein == stented.vein) %>%
    filter(Imaging.Study.Modality == "Conventional Venography") %>%
    filter(Status == "Present" | Status == "In-stent Restenosis")
  if(nrow(patient.vein.imaging.data) > 0){
    patient.vein.imaging.data = arrange(patient.vein.imaging.data, Imaging.Date)
    first.conventional.venography.stent.present[i] = as.character(patient.vein.imaging.data$Imaging.Date[1])
  }
}

first.Stanford.procedure.stent.locations = cbind.data.frame(first.Stanford.procedure.stent.locations,
                                                            first.conventional.venography.stent.present)

first.Stanford.procedure.stent.locations = first.Stanford.procedure.stent.locations %>%
  # Span between Stent Vein on Conventional Venogram and first Stanford Procedure Date
  mutate(First.Procedure.Imaging.Span = ifelse(is.na(first.conventional.venography.stent.present),
    NA, round(as.numeric(difftime(first.conventional.venography.stent.present, 
    as.Date(first.conventional.venography.stent.present), units = "days")), digits = 0)))

# List of Patients with Stenting on Conventional Venogram prior to first Stanford procedure date
stent.on.imaging.prior.procedure.patients = first.Stanford.procedure.stent.locations %>%
  filter(First.Procedure.Imaging.Span < 0) %>%
  select(record_id) %>%
  unique()

# Remove patients with Stenting on Conventional Venogram prior to first Stanford procedure date
if(nrow(stent.on.imaging.prior.procedure.patients) > 0){
  stent.on.imaging.prior.procedure.patients = stent.on.imaging.prior.procedure.patients[, 1]
  first.Stanford.procedure.stent.locations = filter(first.Stanford.procedure.stent.locations,
  !(record_id %in% stent.on.imaging.prior.procedure.patients))
  first.Stanford.procedure.dataframe = filter(first.Stanford.procedure.dataframe,
  !(record_id %in% stent.on.imaging.prior.procedure.patients))
}
