# record_id_mrn_accession_io.R

# This script performs pre-processing on the Record ID-MRN-Accession and
# Record ID-MRN mapping data files.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# record_id to mrn mapping file
record.id.mrn = read.csv(record.id.mrn.file.name, 
                         stringsAsFactors = FALSE, header = TRUE)

record.id.mrn = select(record.id.mrn, record_id, mrn)

# Remove any dashes from mrn numbers
record.id.mrn$mrn = gsub("[-]", "", record.id.mrn$mrn)

# Remove all leading zeroes from mrn numbers
# Code Citation
# Title: Stackoverflow, Removing leading zeros from alphanumeric characters in R
# Date: May 8, 2014
# Type: Code from Stackoverflow Question
# Availability: https://stackoverflow.com/questions/23538576/removing-leading-zeros-from-alphanumeric-characters-in-r
record.id.mrn$mrn = stri_replace_all_regex(record.id.mrn$mrn, "\\b0*(\\d+)\\b", "$1")

# Remove any whitespace on either side of mrn number string
record.id.mrn$mrn = trimws(record.id.mrn$mrn)

# Add any necessary trailing zeroes, to ensure each mrn number has 
# the same length (8 characters)
for(i in 1:length(record.id.mrn$mrn)){
  mrn.number = record.id.mrn$mrn[i]
  mrn.number.length = nchar(mrn.number)
  if(mrn.number.length < mrn.standard.length){
    digit.difference = mrn.standard.length - mrn.number.length
    trailing.zeros = rep("0", times = digit.difference)
    trailing.zeros = paste(trailing.zeros, collapse = '', sep = '')
    mrn.number = paste(mrn.number, trailing.zeros, sep = "")
    record.id.mrn$mrn[i] = mrn.number
  }
}

# list of unique mrn numbers (Number of Patients in VITAL Retrospective Dataset)
unique.mrn.numbers = record.id.mrn %>%
  select(mrn) %>%
  unique()

unique.mrn.numbers = unique.mrn.numbers$mrn

# record_id to mrn to accession mapping
record.id.mrn.accession = read.csv(record.id.mrn.acession.file.name, 
                                   stringsAsFactors = FALSE, header = TRUE)

record.id.mrn.accession = record.id.mrn.accession %>% 
  select(record_id, accession, redcap_repeat_instrument) %>%
  filter(redcap_repeat_instrument == "imaging") %>%
  select(-redcap_repeat_instrument)

# Free up memory by removing variables/dataframes that will not be used
# in subsequent pre-processing or analysis
remove(trailing.zeros)
remove(mrn.number)
remove(digit.difference)
remove(mrn.number.length)
remove(mrn.standard.length)
remove(record.id.mrn.acession.file.name)
remove(record.id.mrn.file.name)
remove(i)