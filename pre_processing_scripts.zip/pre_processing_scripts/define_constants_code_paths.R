# define_constants_code_paths.R

# This script defines the constants, data file names, and paths to the code directories,
# as part of the pre-processing pipeline.

# By David Cohn
# Rubin and Hofmann Labs, July 2018

# Standard Length of MRN Number
mrn.standard.length = 8

# Maximum Number of Attending Physicians per Procedure
num.attending.physicians = 3
# Maxmimum Number of Fellows per Procedure
num.fellows = 3

# Initial Year of VITAL Imaging Data / Follow-up
initial.imaging.followup.year = 1995
# Initial Medical History Year
initial.medical.history.year = 1960

# Maximum Number of Angioplasties Per Procedure
maximum.angioplasty.count = 10
# Maximum Number of Stents per Procedure
maximum.stent.count = 10
# Number of Angioplasty Locations
angioplasty.locations = 17
# Number of Stenting Locations
stent.locations = 17
# Number of Thrombectomy Locations
thrombectomy.locations = 17
# Number of Thrombectomy Methods
thrombectomy.methods = 5
# Number of Chronic Occlusion Locations
chronic.occlusion.locations = 17
# Number Chronic Occlusion Devices
chronic.occlusion.devices = 13

# Average Number of Days in Month
days.in.month = 30
# Average Number of Weeks in Month
weeks.in.month = 4
# Number of Months in Year
months.in.year = 12

# Number of Outside Procedure Types
num.outside.procedure.types = 13
# Maximum Number of Outside Procedures
max.outside.procedures = 10

# Paths to Code Directories
record.id.mrn.acession.code.directory = ''
demographics.code.directory = ''
procedure.code.directory = ''
imaging.data.code.directory = ''
medical.history.code.directory = ''
vte.code.directory = ''
ir.clinic.visit.directory = ''
non.ir.clinic.visit.directory = ''
vital.retrospective.data.directory = ''
medications.directory = ''
labs.directory = ''
cancer.registry.directory = ''

# Data File Names
record.id.mrn.file.name = ''
record.id.mrn.acession.file.name = ''
demographics.file.name = ''
imaging.file.name = ''
procedure.file.name = ''
vte.file.name = ''
medical.history.file.name = ''
ir.clinic.visit.file.name = ''
non.ir.clinic.visit.file.name = ''
medications.file.name = ''
labs.file.name = ''
cancer.registry.file.name = ''
