# non_ir_clinic_visit_datetime_processing.R

# This script performs data pre-processing on non-IR encounter
# date-time entries.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing non-IR encounter date-time data
non.ir.clinic.dates.data = select(non.ir.clinic.data, record_id, Non.IR.Encounter.Number, nonir_date)

non.ir.clinic.data = select(non.ir.clinic.data, -nonir_date)

for(i in 1:nrow(non.ir.clinic.dates.data)){
  non.ir.encounter.date = non.ir.clinic.dates.data$nonir_date[i]
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  if(gsub("[^0-9]", "", non.ir.encounter.date) == ""){
    non.ir.clinic.dates.data$nonir_date[i] = ""
  }else{
    # Separate multiple non-IR encounter date(s) on semicolon
    non.ir.encounter.date = unlist(strsplit(non.ir.encounter.date, ";"))
    # Remove non-IR Clinic encounters with multiple listed dates
    if(length(non.ir.encounter.date) > 1){
      non.ir.clinic.dates.data$nonir_date[i] = ""
    }
  }
}

# Remove missing/improper date-time entries/encounters with multiple date-time entries
non.ir.clinic.dates.data = filter(non.ir.clinic.dates.data, nonir_date != "")

source(paste(non.ir.clinic.visit.directory, 'determine_non_ir_clinic_visit_datetime_format.R', sep = '/'))

source(paste(non.ir.clinic.visit.directory, 'create_complete_non_ir_clinic_visit_date_time_string.R', sep = '/'))

source(paste(non.ir.clinic.visit.directory, 'standardize_non_ir_clinic_visit_date_time_strings.R', sep = '/'))