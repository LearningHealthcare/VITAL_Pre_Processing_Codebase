# determine_non_ir_clinic_visit_datetime_format.R

# This script identifies the format of a non-IR Encounter date-time entry.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

num.dashes = rep(0, times = nrow(non.ir.clinic.dates.data))

num.backslashes = rep(0, times = nrow(non.ir.clinic.dates.data))

# Identify number of dashes or backlashes in date-time entry (i.e. 01-01-2000, or 01/01/2000)
for(i in 1:nrow(non.ir.clinic.dates.data)){
  num.dashes[i] = length(unlist(strsplit(non.ir.clinic.dates.data$nonir_date[i], split = "-")))
  num.backslashes[i] = length(unlist(strsplit(non.ir.clinic.dates.data$nonir_date[i], split = "/")))
}

month.status = rep("", times = nrow(non.ir.clinic.dates.data))
month.value = rep("", nrow(non.ir.clinic.dates.data))
year.value = rep("", nrow(non.ir.clinic.dates.data))

# Check whether month name is present in date-time entry
month.status[grepl("January", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("Jan", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("February", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("Feb", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("March", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("Mar", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("April", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("Apr", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("May", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("June", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("Jun", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("July", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("Jul", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("August", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("Aug", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("September", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("Sep", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("October", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("Oct", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("November", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("Nov", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("December", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"
month.status[grepl("Dec", non.ir.clinic.dates.data$nonir_date) == TRUE] = "Yes"

for(i in 1:nrow(non.ir.clinic.dates.data)){
  if(num.dashes[i] != 3 & num.backslashes[i] != 3){
    # Checks if date is given as month space year (i.e. January 2000)
    if(month.status[i] == "Yes"){
      month.year.potential.value = non.ir.clinic.dates.data$nonir_date[i]
      # Split month and year
      month.year.values = unlist(strsplit(month.year.potential.value, split = "\\s+"))
      month.value[i] = month.year.values[1]
      if(length(month.year.values) == 2){
        year.potential.value = month.year.values[2]
        year.potential.value = trimws(year.potential.value)
        # Verify year is in proper format (4 numeric characters within time period covered by the VITAL Retrospective Database)
        if(nchar(year.potential.value) == 4 & year.potential.value == gsub("[^0-9]", "", year.potential.value)){
          if(as.integer(year.potential.value) >= initial.medical.history.year & as.integer(year.potential.value) <= year(Sys.Date())){
            year.value[i] = year.potential.value
          }
        }
      }
    # Checks if date given as year (i.e. 2000)
    }else{
      year.potential.value = non.ir.clinic.dates.data$nonir_date[i]
      # Verify year is in proper format (4 numeric characters within time period covered by the VITAL Retrospective Database)
      if(nchar(year.potential.value) == 4 & year.potential.value == gsub("[^0-9]", "", year.potential.value)){
        if(as.integer(year.potential.value) >= initial.medical.history.year & as.integer(year.potential.value) <= year(Sys.Date())){
          year.value[i] = year.potential.value
        }
      }
    }
  }
}