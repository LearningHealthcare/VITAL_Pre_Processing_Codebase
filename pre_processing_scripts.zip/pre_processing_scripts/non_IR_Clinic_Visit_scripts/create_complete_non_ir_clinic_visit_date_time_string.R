# create_complete_non_ir_clinic_visit_date_time_string.R

# This script creates a complete non-IR Encounter Date-Time string,
# if the full month, day and year was not provided in the database.
# In the event that a date does not contain a full month, day and year,
# the code assumes the event occured on the latest date within the defined 
# period (i.e. January 2000 becomes January 31, 2000, while 2005 becomes 
# December 31, 2005 etc.)

# By David Cohn

# Rubin and Hofmann Labs, July 2018

month.vector = rep("", times = length(month.value))

# Convert string representation of Month to corresponding numeric representation
month.vector[month.value == "January"] = "01"
month.vector[month.value == "Jan"] = "01"
month.vector[month.value == "February"] = "02"
month.vector[month.value == "Feb"] = "02"
month.vector[month.value == "March"] = "03"
month.vector[month.value == "Mar"] = "03"
month.vector[month.value == "April"] = "04"
month.vector[month.value == "Apr"] = "04"
month.vector[month.value == "May"] = "05"
month.vector[month.value == "June"] = "06"
month.vector[month.value == "Jun"] = "06"
month.vector[month.value == "July"] = "07"
month.vector[month.value == "Jul"] = "07"
month.vector[month.value == "August"] = "08"
month.vector[month.value == "Aug"] = "08"
month.vector[month.value == "September"] = "09"
month.vector[month.value == "Sept"] = "09"
month.vector[month.value == "October"] = "10"
month.vector[month.value == "Oct"] = "10"
month.vector[month.value == "November"] = "11"
month.vector[month.value == "Nov"] = "11"
month.vector[month.value == "December"] = "12"
month.vector[month.value == "Dec"] = "12"

non.ir.clinic.dates.data = cbind.data.frame(non.ir.clinic.dates.data, num.dashes, num.backslashes,
                                                                   month.vector, year.value)

non.ir.clinic.dates.data$month.vector = as.character(non.ir.clinic.dates.data$month.vector)
non.ir.clinic.dates.data$year.value = as.character(non.ir.clinic.dates.data$year.value)

non.ir.clinic.dates.data = non.ir.clinic.dates.data %>% 
  # Check if date given with month, day and year
  mutate(Complete.Date.Status = ifelse(num.dashes == 3 | num.backslashes == 3, "Yes", "No")) %>%
  # Calculate month for non-complete date-time entry
  mutate(Month = ifelse(Complete.Date.Status == "Yes", "",
         ifelse(month.vector != "", month.vector,
         ifelse(year.value != "", "12", "")))) %>%
  # Calculate day for non-complete date-time entry
  mutate(Day = ifelse(Complete.Date.Status == "Yes" | year.value == "" | Month == "", "",
         ifelse(Month == "02", "28",
         ifelse(Month == "04" | Month == "06" | Month == "09" | Month == "11", "30", "31")))) %>%
  # Calculate/Identify complete date-time entry, with a month, day and year
  mutate(Date.Value = ifelse(Complete.Date.Status == "Yes", nonir_date, 
         ifelse(Month != "" & Day != "" & year.value != "", paste(Month, Day, year.value, sep = "-"), ""))) %>%
  select(record_id, Non.IR.Encounter.Number, Date.Value)