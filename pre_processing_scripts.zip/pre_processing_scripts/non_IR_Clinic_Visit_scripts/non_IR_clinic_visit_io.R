# non_IR_clinic_visit_io.R

# This overarching script performs the data I/O and pre-processing
# on the non-IR encounter data derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# non-IR Encounter I/O
non.ir.clinic.data = read.csv(non.ir.clinic.visit.file.name, 
                              header = TRUE, stringsAsFactors = FALSE)

non.ir.clinic.data = non.ir.clinic.data %>%
  filter(redcap_repeat_instrument == "nonir_encounter_clinic_or_hospital") %>%
  # Remove encounters with missing/improper date-time formats
  filter(nonir_date != "") %>%
  mutate(Non.Date.Format.Status = ifelse(gsub("[^0-9]", "", nonir_date) == "", "Yes", "No")) %>%
  filter(Non.Date.Format.Status == "No") %>%
  mutate(Encounter.Type = ifelse(encountertype == 1, "Hospitalization.with.Surgery", 
         ifelse(encountertype == 2, "Outpatient.Procedure",
         ifelse(encountertype == 3, "Clinic.Visit",
         ifelse(encountertype == 4, "Emergency.Room", 
         ifelse(encountertype == 5, "Hospitalization.without.Surgery",
         ifelse(encountertype == 6, "Emergency.Room.Visit", NA))))))) %>%
  mutate(Pregnancy.Follow.Up.Status = ifelse(encounter_follow_up___1 == 1, "Yes", 
         ifelse(encounter_follow_up___1 == 0, "No", NA))) %>%
  mutate(Bleeding.Complications.Follow.Up.Status = ifelse(encounter_follow_up___2 == 1, "Yes", 
         ifelse(encounter_follow_up___2 == 0, "No", NA))) %>%
  mutate(Thrombotic.Complications.Follow.Up.Status = ifelse(encounter_follow_up___3 == 1, "Yes", 
         ifelse(encounter_follow_up___3 == 0, "No", NA))) %>%
  mutate(Back.Pain.Follow.Up.Status = ifelse(encounter_follow_up___4 == 1, "Yes",
         ifelse(encounter_follow_up___4 == 0, "No", NA))) %>%
  mutate(Other.Complication.Status = ifelse(encounter_follow_up___99 == 1, "Yes",
         ifelse(encounter_follow_up___99 == 0, "No", NA))) %>%
  select(-redcap_repeat_instrument, -nonir_encounter_clinic_or_hospital_complete, -encounter_follow_up___1,
         -encounter_follow_up___2, -encounter_follow_up___3, -encountertype, -encounter_follow_up___4,
         -encounter_follow_up___99, -Non.Date.Format.Status)

names(non.ir.clinic.data)[2] = "Non.IR.Encounter.Number"

# Dataframe containing non-IR Encounter Clinical Note Data
non.ir.note.data = select(non.ir.clinic.data, record_id, Non.IR.Encounter.Number, nonir_note)

# Dataframe containing non-IR Encounter Encounter Type Details Data
non.ir.encounter.type.details.data = select(non.ir.clinic.data, record_id, Non.IR.Encounter.Number, 
        encounter_fu_details, Encounter.Type)

# Dataframe containing non-IR Encounter Follow Up Status Data
non.ir.overall.follow.up.status.data = select(non.ir.clinic.data, record_id, Non.IR.Encounter.Number,
                                 Pregnancy.Follow.Up.Status, Bleeding.Complications.Follow.Up.Status, 
                                 Thrombotic.Complications.Follow.Up.Status, Back.Pain.Follow.Up.Status,
                                 Other.Complication.Status)

source(paste(non.ir.clinic.visit.directory, 'non_ir_clinic_visit_datetime_processing.R', sep = '/'))

source(paste(non.ir.clinic.visit.directory, 'non_ir_followup_processing.R', sep = '/'))

source(paste(non.ir.clinic.visit.directory, 'non_ir_complication_processing.R', sep = '/'))

source(paste(non.ir.clinic.visit.directory, 'free_up_memory_non_ir_clinic_visit_data.R', sep = '/'))