# free_up_memory_non_ir_clinic_visit_data.R

# This script frees up memory by removing variables/dataframes
# that will not be used in subsequent analyses or pre-processing.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

remove(non.ir.clinic.data)
remove(i)
remove(month.status)
remove(month.value)
remove(month.vector)
remove(month.year.potential.value)
remove(month.year.values)
remove(non.ir.clinic.date)
remove(non.ir.clinic.date.first.format)
remove(non.ir.clinic.date.second.format)
remove(non.ir.clinic.date.third.format)
remove(non.ir.clinic.date.fourth.format)
remove(non.ir.clinic.date.fifth.format)
remove(non.ir.clinic.visit.file.name)
remove(non.ir.encounter.date)
remove(num.backslashes)
remove(num.dashes)
remove(potential.date)
remove(year.potential.value)
remove(year.value)