# non_ir_followup_processing.R

# This script performs pre-processing on non-IR Encounter Followup variables,
# as derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

non.ir.clinic.data = non.ir.clinic.data %>%
  mutate(Left.Follow.Up.Pain.Status = ifelse(encounter_left_cc_past___0 == 1, "Yes", 
        ifelse(encounter_left_cc_past___0 == 0, "No", NA))) %>%
  mutate(Left.Follow.Up.Swelling.Edema.Status = ifelse(encounter_left_cc_past___1 == 1, "Yes",
        ifelse(encounter_left_cc_past___1 == 0, "No", NA))) %>%
  mutate(Left.Follow.Up.Active.Ulcer.Status = ifelse(encounter_left_cc_past___2 == 1, "Yes",
        ifelse(encounter_left_cc_past___2 == 0, "No", NA))) %>%
  mutate(Left.Follow.Up.Healed.Ulcer.Status = ifelse(encounter_left_cc_past___3 == 1, "Yes",
        ifelse(encounter_left_cc_past___3 == 0, "No", NA))) %>%
  mutate(Left.Follow.Up.Venous.Claudication.Status = ifelse(encounter_left_cc_past___4 == 1, "Yes",
        ifelse(encounter_left_cc_past___4 == 0, "No", NA))) %>%
  mutate(Left.Follow.Up.Exercise.Intolerance.Status = ifelse(encounter_left_cc_past___5 == 1, "Yes",
        ifelse(encounter_left_cc_past___5 == 0, "No", NA))) %>%
  mutate(Left.Follow.Up.Erythema.Status = ifelse(encounter_left_cc_past___6 == 1, "Yes", 
        ifelse(encounter_left_cc_past___6 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Pain.Status = ifelse(encounter_right_cc_past___0 == 1, "Yes", 
        ifelse(encounter_right_cc_past___0 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Swelling.Edema.Status = ifelse(encounter_right_cc_past___1 == 1, "Yes",
        ifelse(encounter_right_cc_past___1 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Active.Ulcer.Status = ifelse(encounter_right_cc_past___2 == 1, "Yes",
        ifelse(encounter_right_cc_past___2 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Healed.Ulcer.Status = ifelse(encounter_right_cc_past___3 == 1, "Yes",
        ifelse(encounter_right_cc_past___3 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Venous.Claudication.Status = ifelse(encounter_right_cc_past___4 == 1, "Yes",
        ifelse(encounter_right_cc_past___4 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Exercise.Intolerance.Status = ifelse(encounter_right_cc_past___5 == 1, "Yes",
        ifelse(encounter_right_cc_past___5 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Erythema.Status = ifelse(encounter_right_cc_past___6 == 1, "Yes", 
        ifelse(encounter_right_cc_past___6 == 0, "No", NA))) %>%
  select(-encounter_left_cc_past___0, -encounter_left_cc_past___1, -encounter_left_cc_past___2, -encounter_left_cc_past___3,
         -encounter_left_cc_past___4, -encounter_left_cc_past___5, -encounter_left_cc_past___6, -encounter_right_cc_past___0,
         -encounter_right_cc_past___1, -encounter_right_cc_past___2, -encounter_right_cc_past___3, -encounter_right_cc_past___4,
         -encounter_right_cc_past___5, -encounter_right_cc_past___6)

# Dataframe containing non-IR Encounter Followup Status Data
non.ir.follow.up.status.data = select(non.ir.clinic.data, record_id, Non.IR.Encounter.Number, Left.Follow.Up.Pain.Status, 
        Left.Follow.Up.Swelling.Edema.Status, Left.Follow.Up.Active.Ulcer.Status, Left.Follow.Up.Healed.Ulcer.Status, 
        Left.Follow.Up.Venous.Claudication.Status, Left.Follow.Up.Exercise.Intolerance.Status, Left.Follow.Up.Erythema.Status,
        Right.Follow.Up.Pain.Status, Right.Follow.Up.Swelling.Edema.Status, Right.Follow.Up.Active.Ulcer.Status, Right.Follow.Up.Healed.Ulcer.Status, 
        Right.Follow.Up.Venous.Claudication.Status, Right.Follow.Up.Exercise.Intolerance.Status, Right.Follow.Up.Erythema.Status)

# Dataframe containing non-IR Encounter Followup Provider Data
non.ir.follow.up.provider.data = non.ir.clinic.data %>%
  select(record_id, Non.IR.Encounter.Number, encounter_l_pain_pp, encounter_l_edema_pp, encounter_l_ulcer_pp, encounter_l_claud_pp,
         encounter_l_erythema_pp, encounter_exer_int_pp, encounter_r_pain_pp, encounter_r_edema_pp, encounter_r_ulcer_pp, encounter_r_claud_pp,
         encounter_r_erythema_pp) %>%
  gather(Follow.Up.Data.Type, Data.Value, -record_id, -Non.IR.Encounter.Number) %>%
  filter(!is.na(Data.Value)) %>%
  mutate(Provider.Status = ifelse(Data.Value == 2, "Provider", 
         ifelse(Data.Value == 1, "Patient", NA))) %>%
  select(-Data.Value) %>%
  spread(Follow.Up.Data.Type, Provider.Status)

# Dataframe containing non-IR Encounter Condition Change Data
non.ir.condition.change.data = non.ir.clinic.data %>%
  select(record_id, Non.IR.Encounter.Number, encounter_l_pain_change, encounter_l_edema_change, encounter_l_ulcer_change,
         encounter_l_claud_change, encounter_l_erythema_change, encounter_r_pain_change, encounter_r_edema_change, 
         encounter_r_ulcer_change, encounter_r_claud_change, encounter_r_erythema_change, encounter_exer_int_change) %>%
  gather(Follow.Up.Data.Type, Data.Value, -record_id, -Non.IR.Encounter.Number) %>%
  filter(!is.na(Data.Value)) %>%
  mutate(Change.Status = ifelse(Data.Value == 1, "Completely.Improved",
                         ifelse(Data.Value == 2, "Somewhat.Improved",
                         ifelse(Data.Value == 4, "No.Improvement",
                         ifelse(Data.Value == 5, "Worse", NA))))) %>%
  select(-Data.Value) %>%
  spread(Follow.Up.Data.Type, Change.Status)