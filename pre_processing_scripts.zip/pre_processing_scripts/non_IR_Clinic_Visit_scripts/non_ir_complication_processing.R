# non_ir_complication_processing.R

# This script performs pre-processing on non-IR Encounter Complication variables,
# as derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs

# Dataframe storing non-IR Encounter Complication Time Data
non.ir.complication.time.data = non.ir.clinic.data %>% 
  select(record_id, Non.IR.Encounter.Number,
  encounter_bleed_complication_time, encounter_backpain_complication_time, encounter_thromb_complication_time,
  encounter_other_complication_time) %>%
  gather(Complication.Type, Complication.Value, -record_id, -Non.IR.Encounter.Number) %>%
  filter(!is.na(Complication.Value)) %>%
  mutate(Time.Period = ifelse(Complication.Value == 1, "< 1 day", 
        ifelse(Complication.Value == 2, "1-30 days",
        ifelse(Complication.Value == 3, "> 30 days", NA)))) %>%
  select(-Complication.Value) %>%
  spread(Complication.Type, Time.Period)

# Dataframe storing non-IR Encounter Complication Status Data
non.ir.complication.status.data = non.ir.clinic.data %>%
  select(record_id, Non.IR.Encounter.Number, encounter_bleed_comp_major_minor, encounter_thromb_comp_major_minor, 
         encounter_backpain_comp_major_minor, encounter_backpain_comp_major_minor, encounter_other_comp_major_minor) %>%
  gather(Complication.Type, Complication.Value, -record_id, -Non.IR.Encounter.Number) %>%
  filter(!is.na(Complication.Value)) %>%
  mutate(Complication.Degree = ifelse(Complication.Value == 1, "Minor",
        ifelse(Complication.Value == 2, "Major", NA))) %>%
  select(-Complication.Value) %>%
  spread(Complication.Type, Complication.Degree)

# Dataframe storing non-IR Encounter Complication Name Data
non.ir.complication.name.data = non.ir.clinic.data %>%
  select(record_id, Non.IR.Encounter.Number, encounter_bleed_complication_name, encounter_thromb_complication_name, 
         encounter_other_complication_name) %>%
  filter(encounter_bleed_complication_name != "" | encounter_thromb_complication_name != "" | encounter_other_complication_name != "")