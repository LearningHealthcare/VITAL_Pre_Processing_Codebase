# other_procedure_details_data_processing.R

# This overarching script contains the pre-processing code for non-angioplasty
# and non-stenting procedures, such as thrombectomy, thrombolysis and recanalization procedures
# etc.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing data on non-angioplasty and non-stenting procedures
other.procedure.details.data = procedure.data %>%
  select(record_id, Procedure.Number, tools_used___1, tools_used___2, 
         other_procedures_performed___1, other_procedures_performed___2,
         other_procedures_performed___3, other_procedures_performed___4,
         other_procedures_performed___5, other_procedures_performed___6,
         other_procedures_performed___7, other_procedures_performed___8,
         other_procedures_performed___9, other_procedures_performed___10,
         other_procedures_performed___11, other_venous_procedure) %>%
  mutate(DYNA.CT.Status = ifelse(tools_used___1 == 1, "Yes", NA)) %>%
  mutate(IVUS.Status = ifelse(tools_used___2 == 1, "Yes", NA)) %>%
  mutate(Thrombolysis.Status = ifelse(other_procedures_performed___1 == 1, "Yes", NA)) %>%
  mutate(Thrombectomy.Status = ifelse(other_procedures_performed___2 == 1, "Yes", NA)) %>%
  mutate(IVC.Filter.Place.Status = ifelse(other_procedures_performed___3 == 1, "Yes", NA)) %>%
  mutate(Successful.IVC.Filter.Remove = ifelse(other_procedures_performed___4 == 1, "Yes", NA)) %>%
  mutate(Recanalization.Status = ifelse(other_procedures_performed___5 == 1, "Yes", NA)) %>%
  mutate(Unsuccessful.IVC.Filter.Remove = ifelse(other_procedures_performed___6 == 1, "Yes", NA)) %>%
  mutate(Ovarian.Vein.Embolization.Ablation.Status = ifelse(other_procedures_performed___7 == 1, "Yes", NA)) %>%
  mutate(GSV.Ablation.Status = ifelse(other_procedures_performed___8 == 1, "Yes", NA)) %>%
  mutate(Vein.Sclerosis.Status = ifelse(other_procedures_performed___9 == 1, "Yes", NA)) %>%
  mutate(Ligation.Stripping.Veins.Status = ifelse(other_procedures_performed___10 == 1, "Yes", NA)) %>%
  mutate(Other.Venous.Procedure.Status = ifelse(other_procedures_performed___11 == 1, "Yes", NA)) %>%
  select(-tools_used___1, -tools_used___2, -other_procedures_performed___1, 
         -other_procedures_performed___2, -other_procedures_performed___3, 
         -other_procedures_performed___4, -other_procedures_performed___5, -other_procedures_performed___6,
         -other_procedures_performed___7, -other_procedures_performed___8, -other_procedures_performed___9,
         -other_procedures_performed___10, -other_procedures_performed___11)

source(paste(procedure.code.directory, 'thrombolysis_procedure_data_processing.R', sep = '/'))

source(paste(procedure.code.directory, 'thrombectomy_procedure_data_processing.R', sep = '/'))

# Dataframe containing IVC filter data
ivc.filter.procedure.data = procedure.data %>%
  filter(other_procedures_performed___3 == 1 | other_procedures_performed___4 == 1) %>%
  select(record_id, Procedure.Number, ivc_filter_notes) %>%
  # Remove rows with missing IVC filter clinical note data
  filter(ivc_filter_notes != "")

source(paste(procedure.code.directory, 'chronic_occlusion_procedure_data_processing.R', sep = '/'))