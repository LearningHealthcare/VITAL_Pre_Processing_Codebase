# thrombolysis_catheter_tip_location_processing.R

# This script performs the pre-processing on the thrombolysis catheter tip location data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Select columns containing thrombolysis procedure data
thrombolysis.procedure.data = procedure.data %>%
  filter(other_procedures_performed___1 == 1) %>%
  select(record_id, Procedure.Number, thrombolysis_right_tip_loc___1,
         thrombolysis_right_tip_loc___2, thrombolysis_right_tip_loc___3, thrombolysis_right_tip_loc___4,
         thrombolysis_right_tip_loc___5, thrombolysis_right_tip_loc___98, thrombolysis_right_tip_loc___99,
         thrombolysis_left_tip_loc___1, thrombolysis_left_tip_loc___2, thrombolysis_left_tip_loc___3,
         thrombolysis_left_tip_loc___4, thrombolysis_left_tip_loc___5, thrombolysis_left_tip_loc___98,
         thrombolysis_left_tip_loc___99, thrombolysis_infusion_meds___1, thrombolysis_infusion_meds___2, 
         thrombolysis_infusion_meds___3, thrombolysis_infusion_meds___4, thrombolysis_infusion_meds___5,
         thrombolysis_infusion_meds___98, thrombolysis_rt_infus_rate, thrombolysis_lt_infus_rate,
         thrombolysis_rt_shth_loc___1, thrombolysis_rt_shth_loc___2, thrombolysis_rt_shth_loc___3, 
         thrombolysis_rt_shth_loc___4, thrombolysis_rt_shth_loc___5, thrombolysis_rt_shth_loc___6,
         thrombolysis_rt_shth_loc___7, thrombolysis_rt_shth_loc___8, thrombolysis_rt_shth_loc___9, 
         thrombolysis_rt_shth_loc___10, thrombolysis_rt_shth_loc___11, thrombolysis_rt_shth_loc___12, 
         thrombolysis_rt_shth_loc___13, thrombolysis_rt_shth_loc___14, thrombolysis_rt_shth_loc___15,
         thrombolysis_rt_shth_loc___98, thrombolysis_rt_shth_loc___99, thrombolysis_lt_shth_loc___1,
         thrombolysis_lt_shth_loc___2, thrombolysis_lt_shth_loc___3, thrombolysis_lt_shth_loc___4,
         thrombolysis_lt_shth_loc___5, thrombolysis_lt_shth_loc___6, thrombolysis_lt_shth_loc___7,
         thrombolysis_lt_shth_loc___8, thrombolysis_lt_shth_loc___9, thrombolysis_lt_shth_loc___10,
         thrombolysis_lt_shth_loc___11, thrombolysis_lt_shth_loc___12, thrombolysis_lt_shth_loc___13,
         thrombolysis_lt_shth_loc___14, thrombolysis_lt_shth_loc___15, thrombolysis_lt_shth_loc___98, 
         thrombolysis_lt_shth_loc___99, thrombolysis_sheath_meds___1, thrombolysis_sheath_meds___2, 
         thrombolysis_sheath_meds___3, thrombolysis_sheath_meds___4, thrombolysis_sheath_meds___5,
         thrombolysis_sheath_meds___98, thrombolysis_rt_shth_rate, thrombolysis_lt_shth_rate, thrombolysis_addtl_comms,
         thrombolysis_findings, thrombolysis_notes)

# Convert Right Catheter Tip Location Data from numeric encodings to string-based encodings, as defined in
# the VITAL Retrospective Codebook.
thrombolysis.procedure.data = thrombolysis.procedure.data %>%
  mutate(Right.Catheter.Tip.Upper.Extremity.SVC.Status = ifelse(thrombolysis_right_tip_loc___1 == 1, "Yes", 
        ifelse(thrombolysis_right_tip_loc___1 == 0, "No", NA))) %>%
  mutate(Right.Catheter.Tip.Upper.Extremity.Subclavian.Status = ifelse(thrombolysis_right_tip_loc___2 == 1, "Yes", 
        ifelse(thrombolysis_right_tip_loc___2 == 0, "No", NA))) %>%
  mutate(Right.Catheter.Tip.Lower.Extremity.IVC.Status = ifelse(thrombolysis_right_tip_loc___3 == 1, "Yes", 
        ifelse(thrombolysis_right_tip_loc___3 == 0, "No", NA))) %>%
  mutate(Right.Catheter.Tip.Lower.Extremity.CIV.Status = ifelse(thrombolysis_right_tip_loc___4 == 1, "Yes", 
        ifelse(thrombolysis_right_tip_loc___4 == 0, "No", NA))) %>%
  mutate(Right.Catheter.Tip.Lower.Extremity.EIV.Status = ifelse(thrombolysis_right_tip_loc___5 == 1, "Yes", 
        ifelse(thrombolysis_right_tip_loc___5 == 0, "No", NA))) %>%
  mutate(Right.Catheter.Tip.Not.Applicable.Status = ifelse(thrombolysis_right_tip_loc___98 == 1, "Yes", 
        ifelse(thrombolysis_right_tip_loc___98 == 0, "No", NA))) %>%
  mutate(Right.Catheter.Tip.Other.Status = ifelse(thrombolysis_right_tip_loc___99 == 1, "Yes", 
        ifelse(thrombolysis_right_tip_loc___99 == 0, "No", NA))) %>%
  select(-thrombolysis_right_tip_loc___1, -thrombolysis_right_tip_loc___2, -thrombolysis_right_tip_loc___3,
         -thrombolysis_right_tip_loc___4, -thrombolysis_right_tip_loc___5, -thrombolysis_right_tip_loc___98,
         -thrombolysis_right_tip_loc___99)

# Convert Left Catheter Tip Location Data from numeric encodings to string-based encodings, as defined in
# the VITAL Retrospective Codebook.
thrombolysis.procedure.data = thrombolysis.procedure.data %>%
  mutate(Left.Catheter.Tip.Upper.Extremity.SVC.Status = ifelse(thrombolysis_left_tip_loc___1 == 1, "Yes", 
        ifelse(thrombolysis_left_tip_loc___1 == 0, "No", NA))) %>%
  mutate(Left.Catheter.Tip.Upper.Extremity.Subclavian.Status = ifelse(thrombolysis_left_tip_loc___2 == 1, "Yes", 
        ifelse(thrombolysis_left_tip_loc___2 == 0, "No", NA))) %>%
  mutate(Left.Catheter.Tip.Lower.Extremity.IVC.Status = ifelse(thrombolysis_left_tip_loc___3 == 1, "Yes", 
        ifelse(thrombolysis_left_tip_loc___3 == 0, "No", NA))) %>%
  mutate(Left.Catheter.Tip.Lower.Extremity.CIV.Status = ifelse(thrombolysis_left_tip_loc___4 == 1, "Yes", 
        ifelse(thrombolysis_left_tip_loc___4 == 0, "No", NA))) %>%
  mutate(Left.Catheter.Tip.Lower.Extremity.EIV.Status = ifelse(thrombolysis_left_tip_loc___5 == 1, "Yes", 
        ifelse(thrombolysis_left_tip_loc___5 == 0, "No", NA))) %>%
  mutate(Left.Catheter.Tip.Not.Applicable.Status = ifelse(thrombolysis_left_tip_loc___98 == 1, "Yes", 
        ifelse(thrombolysis_left_tip_loc___98 == 0, "No", NA))) %>%
  mutate(Left.Catheter.Tip.Other.Status = ifelse(thrombolysis_left_tip_loc___99 == 1, "Yes", 
        ifelse(thrombolysis_left_tip_loc___99 == 0, "No", NA))) %>%
  select(-thrombolysis_left_tip_loc___1, -thrombolysis_left_tip_loc___2, -thrombolysis_left_tip_loc___3,
         -thrombolysis_left_tip_loc___4, -thrombolysis_left_tip_loc___5, -thrombolysis_left_tip_loc___98,
         -thrombolysis_left_tip_loc___99)