# procedure_anti_coagulation_plan_calculations.R

# This script makes calculations, based on the procedure plan anticoagulation data,
# regarding anticoagulation plan categories.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Identify patients and procedures with coumadin planned regimen
coumadin.plan.procedures = procedure.anticoagulation.plan.coumadin.data %>%
  mutate(Patient.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+")) %>%
  select(Patient.Procedure.Identifier)

coumadin.plan.procedures = coumadin.plan.procedures$Patient.Procedure.Identifier

# Identify patients and procedures with heparin planned regimen
heparin.plan.procedures = procedure.anticoagulation.plan.heparin.data %>%
  mutate(Patient.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+")) %>%
  select(Patient.Procedure.Identifier)

heparin.plan.procedures = heparin.plan.procedures$Patient.Procedure.Identifier

# Identify patients and procedures with fragmin planned regimen
fragmin.plan.procedures = procedure.anticoagulation.plan.fragmin.data %>%
  mutate(Patient.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+")) %>%
  select(Patient.Procedure.Identifier)

fragmin.plan.procedures = fragmin.plan.procedures$Patient.Procedure.Identifier

# Identify patients and procedures with arixtra planned regimen
arixtra.plan.procedures = procedure.anticoagulation.plan.arixtra.data %>%
  mutate(Patient.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+")) %>%
  select(Patient.Procedure.Identifier)

arixtra.plan.procedures = arixtra.plan.procedures$Patient.Procedure.Identifier

# Identify patients and procedures with xarelto planned regimen
xarelto.plan.procedures = procedure.anticoagulation.plan.xarelto.data %>%
  mutate(Patient.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+")) %>%
  select(Patient.Procedure.Identifier)

xarelto.plan.procedures = xarelto.plan.procedures$Patient.Procedure.Identifier

# Identify patients and procedures with plavix planned regimen
plavix.plan.procedures = procedure.anticoagulation.plan.plavix.data %>%
  mutate(Patient.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+")) %>%
  select(Patient.Procedure.Identifier)

plavix.plan.procedures = plavix.plan.procedures$Patient.Procedure.Identifier

# Identify patients and procedures with aspirin planned regimen
aspirin.plan.procedures = procedure.anticoagulation.plan.asa.data %>%
  mutate(Patient.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+")) %>%
  select(Patient.Procedure.Identifier)

aspirin.plan.procedures = aspirin.plan.procedures$Patient.Procedure.Identifier

# Identify patients and procedures with t-PA planned regimen
tpa.plan.procedures = procedure.anticoagulation.plan.tpa.data %>%
  mutate(Patient.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+")) %>%
  select(Patient.Procedure.Identifier)

tpa.plan.procedures = tpa.plan.procedures$Patient.Procedure.Identifier

# Identify patients and procedures with other anticoagulant planned regimen
other.anticoagulant.procedures = procedure.anticoagulation.plan.other.coagulant.data
other.anticoagulant.procedures = other.anticoagulant.procedures$Patient.Procedure.Identifier

# Compile patient and procedure identifiers without lovenox planned regimen
non.lovenox.coagulant.identifiers = c(coumadin.plan.procedures, heparin.plan.procedures, fragmin.plan.procedures,
  arixtra.plan.procedures, xarelto.plan.procedures, tpa.plan.procedures,
  other.anticoagulant.procedures)

# Compile patient and procedure identifiers without coumadin planned regimen
non.coumadin.coagulant.identifiers = c(heparin.plan.procedures, fragmin.plan.procedures,
  arixtra.plan.procedures, xarelto.plan.procedures, tpa.plan.procedures,
  other.anticoagulant.procedures)

# Compile patient and procedure identifiers without xarelto planned regimen
non.xarelto.coagulant.identifiers = c(coumadin.plan.procedures, heparin.plan.procedures, fragmin.plan.procedures,
  arixtra.plan.procedures, tpa.plan.procedures, other.anticoagulant.procedures)

# Compile patient and procedure identifiers without a coumadin or xarelto planned regimen
non.coumadin.xarelto.coagulant.identifiers = c(heparin.plan.procedures, fragmin.plan.procedures,
  arixtra.plan.procedures, tpa.plan.procedures, other.anticoagulant.procedures)

procedure.anticoagulation.plan.data = select(procedure.anticoagulation.plan.lovenox.data, -plan_lovenox_dose)

procedure.anticoagulation.plan.data = procedure.anticoagulation.plan.data %>%
  mutate(Patient.Procedure.Identifier = paste(record_id, Procedure.Number, sep = "+")) %>%
  # Identify units associated with planned anticoagulation duration
  mutate(Lovenox.Time.Units = ifelse(grepl("day", plan_lovenox_length), "day",
         ifelse(grepl("week", plan_lovenox_length), "week",
         ifelse(grepl("month", plan_lovenox_length), "month", 
         ifelse(grepl("year", plan_lovenox_length), "year", ""))))) %>%
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  mutate(Lovenox.Time.Duration = gsub("[^0-9.]", "", plan_lovenox_length)) %>%
  # Calculate planned lovenox duration in months
  mutate(Lovenox.Duration.Months = ifelse(Lovenox.Time.Units == "day" & Lovenox.Time.Duration != "", 
            as.numeric(Lovenox.Time.Duration) / days.in.month, 
         ifelse(Lovenox.Time.Units == "week" & Lovenox.Time.Duration != "",
            as.numeric(Lovenox.Time.Duration) / weeks.in.month,
         ifelse(Lovenox.Time.Units == "month" & Lovenox.Time.Duration != "",
            as.numeric(Lovenox.Time.Duration), 
         ifelse(Lovenox.Time.Units == "year" & Lovenox.Time.Duration != "",
            as.numeric(Lovenox.Time.Duration) * months.in.year, NA))))) %>%
  # Bin lovenox duration
  mutate(Lovenox.Duration.Bin = ifelse(is.na(Lovenox.Duration.Months), NA,
         ifelse(Lovenox.Duration.Months < 1, "< 1 month",
         ifelse(Lovenox.Duration.Months >= 1 & Lovenox.Duration.Months < 2, "1-2 months",
         ifelse(Lovenox.Duration.Months < 3, "2-3 months", "3+ months"))))) %>%
  # Calculate Anticoagulation Combination
  mutate(Anticoagulant.Combination = ifelse(!(Patient.Procedure.Identifier %in% non.lovenox.coagulant.identifiers), "Lovenox",
         ifelse(Patient.Procedure.Identifier %in% coumadin.plan.procedures & 
               !(Patient.Procedure.Identifier %in% non.coumadin.coagulant.identifiers), "Lovenox+Coumadin",
         ifelse(Patient.Procedure.Identifier %in% xarelto.plan.procedures & 
               !(Patient.Procedure.Identifier %in% non.xarelto.coagulant.identifiers), "Lovenox+Xarelto",
         ifelse(Patient.Procedure.Identifier %in% coumadin.plan.procedures & 
               Patient.Procedure.Identifier %in% xarelto.plan.procedures & 
               !(Patient.Procedure.Identifier %in% non.coumadin.xarelto.coagulant.identifiers), "Lovenox+Coumadin+Xarelto",
         ifelse(Patient.Procedure.Identifier %in% coumadin.plan.procedures & 
               Patient.Procedure.Identifier %in% xarelto.plan.procedures & 
               Patient.Procedure.Identifier %in% non.coumadin.xarelto.coagulant.identifiers, "Lovenox+Coumadin+Xarelto+Other",
         ifelse(Patient.Procedure.Identifier %in% coumadin.plan.procedures & 
               Patient.Procedure.Identifier %in% non.coumadin.coagulant.identifiers &
               !(Patient.Procedure.Identifier %in% xarelto.plan.procedures), "Lovenox+Coumadin+Other",
         ifelse(Patient.Procedure.Identifier %in% xarelto.plan.procedures & 
               Patient.Procedure.Identifier %in% non.xarelto.coagulant.identifiers &
               !(Patient.Procedure.Identifier %in% coumadin.plan.procedures), "Lovenox+Xarelto+Other", "Lovenox+Other")))))))) %>%
  # Calculate aspirin status in anticoagulation plan
  mutate(Aspirin.Status = ifelse(Patient.Procedure.Identifier %in% aspirin.plan.procedures, "Yes", "No"))

procedure.anticoagulation.plan.data$Lovenox.Duration.Bin[procedure.anticoagulation.plan.data$plan_lovenox_length == "long term" |
                                                          procedure.anticoagulation.plan.data$plan_lovenox_length == "long term+ASA"] = "3+ months"

procedure.anticoagulation.plan.data = select(procedure.anticoagulation.plan.data, -plan_lovenox_length, 
      -Patient.Procedure.Identifier, -Lovenox.Time.Units, -Lovenox.Time.Duration, -Lovenox.Duration.Months)