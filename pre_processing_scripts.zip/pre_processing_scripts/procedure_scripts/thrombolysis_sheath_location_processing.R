# thrombolysis_sheath_location_processing.R

# This script pre-processes thrombolysis sheath location data derived from the VITAL Retrospective
# database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Convert right sheath location statuses, from numerical encodings, to string-based encodings,
# based on VITAL Retrospective Codebook
thrombolysis.procedure.data = thrombolysis.procedure.data %>%
  mutate(Right.Axillary.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___1 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___1 == 0, "No", NA))) %>%
  mutate(Right.Basilic.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___2 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___2 == 0, "No", NA))) %>%
  mutate(Right.Brachial.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___3 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___3 == 0, "No", NA))) %>%
  mutate(Right.Brachiocephalic.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___4 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___4 == 0, "No", NA))) %>%
  mutate(RCFV.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___5 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___5 == 0, "No", NA))) %>%
  mutate(RCIV.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___6 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___6 == 0, "No", NA))) %>%
  mutate(REIV.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___7 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___7 == 0, "No", NA))) %>%
  mutate(Right.External.Jugular.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___8 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___8 == 0, "No", NA))) %>%
  mutate(RFEMV.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___9 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___9 == 0, "No", NA))) %>%
  mutate(Right.Gonadal.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___10 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___10 == 0, "No", NA))) %>%
  mutate(Right.IVC.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___11 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___11 == 0, "No", NA))) %>%
  mutate(Right.Internal.Jugular.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___12 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___12 == 0, "No", NA))) %>%
  mutate(RPOP.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___13 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___13 == 0, "No", NA))) %>%
  mutate(Right.Subclavian.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___14 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___14 == 0, "No", NA))) %>%
  mutate(Right.SVC.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___15 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___15 == 0, "No", NA))) %>%
  mutate(Right.Not.Applicable.Location.Status = ifelse(thrombolysis_rt_shth_loc___98 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___98 == 0, "No", NA))) %>%
  mutate(Right.Other.Sheath.Location.Status = ifelse(thrombolysis_rt_shth_loc___99 == 1, "Yes",
        ifelse(thrombolysis_rt_shth_loc___99 == 0, "No", NA))) %>%
  select(-thrombolysis_rt_shth_loc___1, -thrombolysis_rt_shth_loc___2, -thrombolysis_rt_shth_loc___3, 
         -thrombolysis_rt_shth_loc___4, -thrombolysis_rt_shth_loc___5, -thrombolysis_rt_shth_loc___6,
         -thrombolysis_rt_shth_loc___7, -thrombolysis_rt_shth_loc___8, -thrombolysis_rt_shth_loc___9,
         -thrombolysis_rt_shth_loc___10, -thrombolysis_rt_shth_loc___11, -thrombolysis_rt_shth_loc___12,
         -thrombolysis_rt_shth_loc___13, -thrombolysis_rt_shth_loc___14, -thrombolysis_rt_shth_loc___15,
         -thrombolysis_rt_shth_loc___98, -thrombolysis_rt_shth_loc___99)

# Convert left sheath location statuses, from numerical encodings, to string-based encodings,
# based on VITAL Retrospective Codebook
thrombolysis.procedure.data = thrombolysis.procedure.data %>%
  mutate(Left.Axillary.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___1 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___1 == 0, "No", NA))) %>%
  mutate(Left.Basilic.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___2 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___2 == 0, "No", NA))) %>%
  mutate(Left.Brachial.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___3 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___3 == 0, "No", NA))) %>%
  mutate(Left.Brachiocephalic.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___4 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___4 == 0, "No", NA))) %>%
  mutate(LCFV.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___5 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___5 == 0, "No", NA))) %>%
  mutate(LCIV.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___6 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___6 == 0, "No", NA))) %>%
  mutate(LEIV.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___7 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___7 == 0, "No", NA))) %>%
  mutate(Left.External.Jugular.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___8 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___8 == 0, "No", NA))) %>%
  mutate(LFEMV.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___9 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___9 == 0, "No", NA))) %>%
  mutate(Left.Gonadal.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___10 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___10 == 0, "No", NA))) %>%
  mutate(Left.IVC.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___11 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___11 == 0, "No", NA))) %>%
  mutate(Left.Internal.Jugular.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___12 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___12 == 0, "No", NA))) %>%
  mutate(LPOP.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___13 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___13 == 0, "No", NA))) %>%
  mutate(Left.Subclavian.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___14 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___14 == 0, "No", NA))) %>%
  mutate(Left.SVC.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___15 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___15 == 0, "No", NA))) %>%
  mutate(Left.Not.Applicable.Location.Status = ifelse(thrombolysis_lt_shth_loc___98 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___98 == 0, "No", NA))) %>%
  mutate(Left.Other.Sheath.Location.Status = ifelse(thrombolysis_lt_shth_loc___99 == 1, "Yes",
        ifelse(thrombolysis_lt_shth_loc___99 == 0, "No", NA))) %>%
  select(-thrombolysis_lt_shth_loc___1, -thrombolysis_lt_shth_loc___2, -thrombolysis_lt_shth_loc___3, 
         -thrombolysis_lt_shth_loc___4, -thrombolysis_lt_shth_loc___5, -thrombolysis_lt_shth_loc___6,
         -thrombolysis_lt_shth_loc___7, -thrombolysis_lt_shth_loc___8, -thrombolysis_lt_shth_loc___9,
         -thrombolysis_lt_shth_loc___10, -thrombolysis_lt_shth_loc___11, -thrombolysis_lt_shth_loc___12,
         -thrombolysis_lt_shth_loc___13, -thrombolysis_lt_shth_loc___14, -thrombolysis_lt_shth_loc___15,
         -thrombolysis_lt_shth_loc___98, -thrombolysis_lt_shth_loc___99)