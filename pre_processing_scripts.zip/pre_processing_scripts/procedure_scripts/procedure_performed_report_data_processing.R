# procedure_performed_report_data_processing.R

# This script performs pre-processing on data pertaining to procedures that were performed
# as part of an intervention, as well as creating dataframes for procedure date and procedure
# report data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Create procedure report dataframe
procedure.report.data = select(procedure.data, record_id, Procedure.Number, report)

# Create procedure date dataframe
procedure.date.data = select(procedure.data, record_id, Procedure.Number, proc_date)

# Dataframe containing details on procedure(s) performed
procedure.performed.data = procedure.data %>%
  select(record_id, Procedure.Number, upperorlower___1, upperorlower___2, upperorlower___99, 
  access___0, access___1, access___2, access___3, access___4, access___5, access___6, access___7, 
  access___8, access___9, access___10, access___11, access___12, access___13) %>%
  # Upper versus Lower Extremity Vein Status data; statuses derived based on VITAL Retrospective codebook
  mutate(SVC.Above.Status = ifelse(upperorlower___1 == 1, "Yes", NA)) %>%
  mutate(IVC.Below.Status = ifelse(upperorlower___2 == 1, "Yes", NA)) %>%
  mutate(Other.Veins.Status = ifelse(upperorlower___99 == 1, "Yes", NA)) %>%
  # Access Site Data; statuses derived based on VITAL Retrospective codebook
  mutate(RJUG.Status = ifelse(access___0 == 1, "Yes", NA)) %>%
  mutate(RCFV.Status = ifelse(access___1 == 1, "Yes", NA)) %>%
  mutate(RPOP.Status = ifelse(access___2 == 1, "Yes", NA)) %>%
  mutate(RANK.Status = ifelse(access___3 == 1, "Yes", NA)) %>%
  mutate(RGSV.Status = ifelse(access___4 == 1, "Yes", NA)) %>%
  mutate(RSSV.Status = ifelse(access___5 == 1, "Yes", NA)) %>%
  mutate(LJUG.Status = ifelse(access___6 == 1, "Yes", NA)) %>%
  mutate(LCFV.Status = ifelse(access___7 == 1, "Yes", NA)) %>%
  mutate(LPOP.Status = ifelse(access___8 == 1, "Yes", NA)) %>%
  mutate(LANK.Status = ifelse(access___9 == 1, "Yes", NA)) %>%
  mutate(LGSV.Status = ifelse(access___10 == 1, "Yes", NA)) %>%
  mutate(LSSV.Status = ifelse(access___11 == 1, "Yes", NA)) %>%
  mutate(RFEMV.Status = ifelse(access___12 == 1, "Yes", NA)) %>%
  mutate(LFEMV.Status = ifelse(access___13 == 1, "Yes", NA)) %>%
  select(-upperorlower___1, -upperorlower___2, -upperorlower___99, 
         -access___0, -access___1, -access___2, -access___3, -access___4, -access___5, -access___6, -access___7, 
         -access___8, -access___9, -access___10, -access___11, -access___12, -access___13)