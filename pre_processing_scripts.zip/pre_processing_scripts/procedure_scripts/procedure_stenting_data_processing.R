# procedure_stenting_data_processing.R

# This script pre-processes stenting data derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing data on whether stenting was performed as part of IR procedure
general.stent.procedure.data = procedure.data %>%
  select(record_id, Procedure.Number, stenting, num_stents) %>%
  mutate(Stand.Alone.Stent.Status = ifelse(stenting == 1, "Yes",
        ifelse(stenting == 0, "No", NA))) %>%
  select(-stenting)

general.stent.procedure.data$num_stents = as.numeric(general.stent.procedure.data$num_stents)  

# Dataframe containing stent brand data
stent.brand.procedure.data = procedure.data %>%
  filter(!is.na(num_stents)) %>%
  select(record_id, Procedure.Number, stent1_brand, stent2_brand, stent3_brand, stent4_brand,
         stent5_brand, stent6_brand, stent7_brand, stent8_brand, stent9_brand, stent10_brand) %>%
  gather(Stent.Number, Brand, -record_id, -Procedure.Number) %>%
  # Remove rows with missing brand data
  filter(!is.na(Brand) & Brand != "")

stent.brand.procedure.data$Brand = tolower(stent.brand.procedure.data$Brand)
# Capitalize first letter in every word as part of stent brand
stent.brand.procedure.data$Brand = toTitleCase(stent.brand.procedure.data$Brand)

stent.brand.procedure.data$Brand[stent.brand.procedure.data$Brand == "z"] = "Z"
stent.brand.procedure.data$Brand[stent.brand.procedure.data$Brand == "Cordis Smart"] = "Smart"
stent.brand.procedure.data$Brand[stent.brand.procedure.data$Brand == "Ev3"] = "EV3"
stent.brand.procedure.data$Brand[stent.brand.procedure.data$Brand == "Gore Excluder Stent Graft"] = "Gore Stent Graft"

# Dataframe containing data on stent diameters
stent.diameter.procedure.data = procedure.data %>%
  filter(!is.na(num_stents)) %>%
  select(record_id, Procedure.Number, stent1_diameter, stent2_diameter, stent3_diameter, stent4_diameter,
         stent5_diameter, stent6_diameter, stent7_diameter, stent8_diameter, stent9_diameter, stent10_diameter) %>%
  gather(Stent.Number, Diameter, -record_id, -Procedure.Number) %>%
  filter(!is.na(Diameter)) %>%
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  mutate(Diameter.Value = gsub("[^0-9\\.]", "", Diameter)) %>%
  select(-Diameter)

stent.diameter.procedure.data$Diameter.Value = trimws(stent.diameter.procedure.data$Diameter.Value)
stent.diameter.procedure.data$Diameter.Value = as.numeric(stent.diameter.procedure.data$Diameter.Value)

stent.diameter.procedure.data = filter(stent.diameter.procedure.data, Diameter.Value > 1 &
Diameter.Value < 40)

# Dataframe containing data on stent length data
stent.length.procedure.data = procedure.data %>%
  filter(!is.na(num_stents)) %>%
  select(record_id, Procedure.Number, stent1_length, stent2_length, stent3_length,
         stent4_length, stent5_length, stent6_length, stent7_length, stent8_length,
         stent9_length, stent10_length) %>%
  gather(Stent.Number, Length, -record_id, -Procedure.Number) %>%
  filter(!is.na(Length)) %>%
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  mutate(Length.Value = gsub("[^0-9\\.]", "", Length)) %>%
  select(-Length)

stent.length.procedure.data$Length.Value = trimws(stent.length.procedure.data$Length.Value)
stent.length.procedure.data$Length.Value = as.numeric(stent.length.procedure.data$Length.Value)

stent.length.procedure.data = filter(stent.length.procedure.data, Length.Value > 10 &
Length.Value < 200)

# Create list of vein locations by stenting number, in order to efficiently select columns
# containing stent location data
stent.vector = paste(rep("stent", times = 10), 
                      seq(1, maximum.stent.count), sep = "")
location.vector = paste(rep("location"), seq(1, stent.locations), sep = '___')
stent.location.vector = as.vector(outer(stent.vector, location.vector, paste, sep = "_"))
stent.location.vector = c("record_id", "Procedure.Number", stent.location.vector)
stent.location.string.vector = procedure.vein.list
stent.names.vector = as.vector(outer(stent.vector, stent.location.string.vector, paste, sep = "_"))
stent.names.vector = c("record_id", "Procedure.Number", stent.names.vector)

# Dataframe containing stent location data
stent.location.procedure.data = procedure.data %>%
  filter(!is.na(num_stents)) %>%
  select(stent.location.vector) %>%
  gather(stent.Location.Number, Encoding, -record_id, -Procedure.Number) %>%
  # Presence("Yes")/Absence(NA) of Stent in Vein Location
  mutate(Value = ifelse(Encoding == 1, "Yes", NA)) %>%
  select(-Encoding) %>%
  spread(stent.Location.Number, Value)

# Re-arrange columns in stent location dataframe, by stent number and vein
stent.location.procedure.data = stent.location.procedure.data[stent.location.vector]

# Assign string-based vein names to stent location data
names(stent.location.procedure.data) = stent.names.vector
