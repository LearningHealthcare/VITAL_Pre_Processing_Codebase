# thrombolysis_procedure_data_processing.R

# This overarching script contains the scripts that perform pre-processing
# on the thrombolysis procedure data derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

source(paste(procedure.code.directory, 'thrombolysis_catheter_tip_location_processing.R', sep = '/'))

source(paste(procedure.code.directory, 'thrombolysis_catheter_infusion_processing.R', sep = '/'))

source(paste(procedure.code.directory, 'thrombolysis_sheath_location_processing.R', sep = '/'))

source(paste(procedure.code.directory, 'thrombolysis_sheath_infusion_processing.R', sep = '/'))