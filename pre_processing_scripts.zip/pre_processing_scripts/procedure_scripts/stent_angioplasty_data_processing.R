# stent_angioplasty_data_processing.R

# This script processes stent angioplasty data derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Create list of plasty numbers, in order to efficiently select columns 
# containing stent plasty data
stent.plasty.vector = paste(stent.vector, rep("plasty", times = length(stent.vector)), 
                            sep = "_")
stent.plasty.vector = c("record_id", "Procedure.Number", stent.plasty.vector)

# Dataframe containing stent angioplasty procedure data
stent.angioplasty.procedure.data = procedure.data %>%
  filter(!is.na(num_stents)) %>%
  select(stent.plasty.vector) %>%
  gather(Plasty.Number, Value, -record_id, -Procedure.Number) %>%
  # Status indicating whether stent plasty was performed (Yes/No)
  mutate(Plasty.Status = ifelse(Value == 1, "Yes",
        ifelse(Value == 0, "No", NA))) %>%
  select(-Value) %>%
  spread(Plasty.Number, Plasty.Status)

# Create list of plasty brands, in order to efficiently select columns
# containing stent plasty brand data
stent.plasty.brand.vector = paste(stent.plasty.vector, rep("brand", times = length(stent.vector)),
                                  sep = "_")
stent.plasty.brand.vector = stent.plasty.brand.vector[-c(1, 2)]
stent.plasty.brand.vector = c("record_id", "Procedure.Number", stent.plasty.brand.vector)

# Dataframe containing stent angioplasty brand data
stent.angioplasty.brand.procedure.data = procedure.data %>%
  filter(!is.na(num_stents)) %>%
  select(stent.plasty.brand.vector) %>%
  gather(Stent.Number, Brand, -record_id, -Procedure.Number) %>%
  filter(!is.na(Brand))

stent.angioplasty.brand.procedure.data$Brand[stent.angioplasty.brand.procedure.data$Brand == "Altas"] = "Atlas"
stent.angioplasty.brand.procedure.data$Brand = tolower(stent.angioplasty.brand.procedure.data$Brand)
# Capitalize first letter in each word of stent angioplasty brand
stent.angioplasty.brand.procedure.data$Brand = toTitleCase(stent.angioplasty.brand.procedure.data$Brand)
stent.angioplasty.brand.procedure.data$Brand[stent.angioplasty.brand.procedure.data$Brand == "Ev3"] = "EV3"
stent.angioplasty.brand.procedure.data$Brand[stent.angioplasty.brand.procedure.data$Brand == "Xxl"] = "XXL"
stent.angioplasty.brand.procedure.data$Brand[stent.angioplasty.brand.procedure.data$Brand == "Axm"] = "AXM"

# Create list of stent plasty diameter identifiers, in order to efficiently select
# columns containing stent plasty diameter data
stent.plasty.diameter.vector = paste(stent.plasty.vector, rep("diameter", times = length(stent.vector)),
                                     sep = "_")
stent.plasty.diameter.vector = stent.plasty.diameter.vector[-c(1, 2)]
stent.plasty.diameter.vector = c("record_id", "Procedure.Number", stent.plasty.diameter.vector)

# Dataframe containing stent angioplasty diameter data
stent.angioplasty.diameter.procedure.data = procedure.data %>%
  filter(!is.na(num_stents)) %>%
  select(stent.plasty.diameter.vector) %>%
  gather(Stent.Number, Diameter, -record_id, -Procedure.Number) %>%
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  mutate(Diameter.Value = gsub("[^0-9\\.]", "", Diameter)) %>%
  select(-Diameter)

stent.angioplasty.diameter.procedure.data$Diameter.Value = trimws(stent.angioplasty.diameter.procedure.data$Diameter.Value)
stent.angioplasty.diameter.procedure.data$Diameter.Value = as.numeric(stent.angioplasty.diameter.procedure.data$Diameter.Value)

# Create list of stent plasty length identifiers, in order to efficiently select
# columns containing stent plasty diameter data
stent.plasty.length.vector = paste(stent.plasty.vector, rep("length", times = length(stent.vector)),
                                   sep = "_")
stent.plasty.length.vector = stent.plasty.length.vector[-c(1, 2)]
stent.plasty.length.vector = c("record_id", "Procedure.Number", stent.plasty.length.vector)

# Dataframe containing stent plasty length data
stent.angioplasty.length.procedure.data = procedure.data %>%
  filter(!is.na(num_stents)) %>%
  select(stent.plasty.length.vector) %>%
  gather(Stent.Number, Length, -record_id, -Procedure.Number) %>%
  filter(!is.na(Length)) %>%
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  mutate(Length.Value = gsub("[^0-9\\.]", "", Length)) %>%
  select(-Length)

stent.angioplasty.length.procedure.data$Length.Value = trimws(stent.angioplasty.length.procedure.data$Length.Value)
stent.angioplasty.length.procedure.data$Length.Value = as.numeric(stent.angioplasty.length.procedure.data$Length.Value)