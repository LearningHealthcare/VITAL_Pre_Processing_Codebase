# clinician_data_processing.R

# This script pre-processes procedure data pertaining to the clinician(s) and fellow(s)
# that performed interventional radiology procedures, as part of the VITAL Retrospective 
# dataset.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

procedure.clinician.data = select(procedure.data, record_id, Procedure.Number,
                                  proc_date, attending, fellow)

# Convert Procedure Date to Date/Time Format
procedure.clinician.data$proc_date = as.POSIXct(procedure.clinician.data$proc_date)

# Separate multiple attending physicians, delimited by semi-colons
attending.physicians = strsplit(procedure.clinician.data$attending, ";")

# Create dataframe storing attending physician data
attending.physicians.data.frame = data.frame(matrix(NA, nrow = length(attending.physicians), 
                                                    ncol = num.attending.physicians))

# Create attending physician dataframe column names
attending.physician.data.frame.names = rep("Attending.Physician", times = num.attending.physicians)
for(i in 1:length(attending.physician.data.frame.names)){
  attending.physician.data.frame.names[i] = paste(attending.physician.data.frame.names[i], toString(i),
                                                  sep = ".")
}

# Add attending physician data to attending physician dataframe
for(i in 1:length(attending.physicians)){
  attending.physician.list = unlist(attending.physicians[i])
  if(length(attending.physician.list) > 0){
    for(j in 1:length(attending.physician.list)){
      attending.physicians.data.frame[i, j] = trimws(attending.physician.list[j])
    }
  }
}

names(attending.physicians.data.frame) = attending.physician.data.frame.names

# Separate multiple fellows, delimited by semi-colons
fellows = strsplit(procedure.clinician.data$fellow, ";")

# Create dataframe storing fellows data
fellows.data.frame = data.frame(matrix(NA, nrow = length(fellows), 
                                       ncol = num.fellows))

# Create column names for fellows dataframe
fellows.data.frame.names = rep("Fellow", times = num.fellows)
for(i in 1:length(fellows.data.frame.names)){
  fellows.data.frame.names[i] = paste(fellows.data.frame.names[i], toString(i),
                                      sep = ".")
}

# Add fellow data to fellow dataframe
for(i in 1:length(fellows)){
  fellow.list = unlist(fellows[i])
  if(length(fellow.list) > 0){
    for(j in 1:length(fellow.list)){
      fellows.data.frame[i, j] = trimws(fellow.list[j])
    }
  }
}
names(fellows.data.frame) = fellows.data.frame.names

# Combine attending physician and fellow dataframes in a single dataframe
procedure.clinician.data = cbind.data.frame(procedure.clinician.data, 
                                            attending.physicians.data.frame, fellows.data.frame)

procedure.clinician.data = select(procedure.clinician.data, -attending, -fellow, -proc_date)

# Derive list of physicians that performed interventions detailed in this dataset
unique.physicians = procedure.clinician.data %>%
  gather(Physician.Title, Physician.Name, -record_id, -Procedure.Number) %>%
  filter(!is.na(Physician.Name)) %>%
  filter(Physician.Name != "") %>%
  select(Physician.Name) %>%
  unique() %>%
  arrange(Physician.Name)

unique.physicians = unique.physicians[, 1]