# thrombolysis_sheath_infusion_processing.R

# This script pre-processes thrombolysis sheath infusion data, derived from the VITAL Retrospective
# database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Convert thrombolysis sheath infusion status from numerical encodings, to string-based encodings,
# based on VITAL Retrospective Codebook
thrombolysis.procedure.data = thrombolysis.procedure.data %>%
  mutate(Alteplase.Sheath.Infusion.Status = ifelse(thrombolysis_sheath_meds___1 == 1, "Yes",
        ifelse(thrombolysis_sheath_meds___1 == 0, "No", NA))) %>%
  mutate(Argatroban.Sheath.Infusion.Status = ifelse(thrombolysis_sheath_meds___2 == 1, "Yes",
        ifelse(thrombolysis_sheath_meds___2 == 0, "No", NA))) %>%
  mutate(Bivalirudin.Sheath.Infusion.Status = ifelse(thrombolysis_sheath_meds___3 == 1, "Yes",
        ifelse(thrombolysis_sheath_meds___3 == 0, "No", NA))) %>%
  mutate(Heparin.Sheath.Infusion.Status = ifelse(thrombolysis_sheath_meds___4 == 1, "Yes",
        ifelse(thrombolysis_sheath_meds___4 == 0, "No", NA))) %>%
  mutate(Saline.Sheath.Infusion.Status = ifelse(thrombolysis_sheath_meds___5 == 1, "Yes",
        ifelse(thrombolysis_sheath_meds___5 == 0, "No", NA))) %>%
  mutate(Not.Applicable.Sheath.Infusion.Status = ifelse(thrombolysis_sheath_meds___98 == 1, "Yes",
        ifelse(thrombolysis_sheath_meds___98 == 0, "No", NA))) %>%
  select(-thrombolysis_sheath_meds___1, -thrombolysis_sheath_meds___2, -thrombolysis_sheath_meds___3,
         -thrombolysis_sheath_meds___4, -thrombolysis_sheath_meds___5, -thrombolysis_sheath_meds___98)

Right.Sheath.Infusion.Rate = rep(NA, times = nrow(thrombolysis.procedure.data))
Right.Sheath.Infusion.Units = rep(NA, times = nrow(thrombolysis.procedure.data))
Left.Sheath.Infusion.Rate = rep(NA, times = nrow(thrombolysis.procedure.data))
Left.Sheath.Infusion.Units = rep(NA, times = nrow(thrombolysis.procedure.data))

# Pre-processing thrombolysis sheath infusion amounts/units
for(i in 1:nrow(thrombolysis.procedure.data)){
  right.sheath.infusion.value = trimws(thrombolysis.procedure.data$thrombolysis_rt_shth_rate[i])
  left.sheath.infusion.value = trimws(thrombolysis.procedure.data$thrombolysis_lt_shth_rate[i])
  # Separate sheath infusion value from units by splitting on whitespace
  right.sheath.infusion.value = unlist(strsplit(right.sheath.infusion.value, " "))
  left.sheath.infusion.value = unlist(strsplit(left.sheath.infusion.value, " "))
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  right.sheath.infusion.value[1] = gsub("[^0-9.]", "", right.sheath.infusion.value[1])
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  left.sheath.infusion.value[1] = gsub("[^0-9.]", "", left.sheath.infusion.value[1])
  Right.Sheath.Infusion.Rate[i] = trimws(right.sheath.infusion.value[1])
  Left.Sheath.Infusion.Rate[i] = trimws(left.sheath.infusion.value[1])
  # Identification of Sheath Infusion units if present
  if(length(right.sheath.infusion.value) >= 2){
    Right.Sheath.Infusion.Units[i] = trimws(tolower(right.sheath.infusion.value[2]))
  }
  if(length(left.sheath.infusion.value) >= 2){
    Left.Sheath.Infusion.Units[i] = trimws(tolower(left.sheath.infusion.value[2]))
  }
}

thrombolysis.procedure.data = cbind.data.frame(thrombolysis.procedure.data, Right.Sheath.Infusion.Rate, 
  Right.Sheath.Infusion.Units, Left.Sheath.Infusion.Rate, Left.Sheath.Infusion.Units)

thrombolysis.procedure.data$Right.Sheath.Infusion.Rate = as.numeric(thrombolysis.procedure.data$Right.Sheath.Infusion.Rate)
thrombolysis.procedure.data$Left.Sheath.Infusion.Rate = as.numeric(thrombolysis.procedure.data$Left.Sheath.Infusion.Rate)

thrombolysis.procedure.data = select(thrombolysis.procedure.data, -thrombolysis_rt_shth_rate, -thrombolysis_lt_shth_rate)