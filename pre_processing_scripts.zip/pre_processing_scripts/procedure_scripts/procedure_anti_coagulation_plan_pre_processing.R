# procedure_anti_coagulation_plan_pre_processing.R

# This script pre-processes procedure anticoagulation plan data, as derived
# from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing lovenox anticoagulation data
procedure.anticoagulation.plan.lovenox.data = procedure.data %>%
  filter(anticoag_type_plan___0 == 1) %>%
  select(record_id, Procedure.Number, plan_lovenox_dose, plan_lovenox_length) 

# Separate lovenox dose amount from frequency data, splitting on dosage units (mg)
lovenox.dose.data = strsplit(procedure.anticoagulation.plan.lovenox.data$plan_lovenox_dose, "mg")
lovenox.dose.amount = rep("", times = length(lovenox.dose.data))
lovenox.dose.frequency = rep("", times = length(lovenox.dose.data))
for(i in 1:length(lovenox.dose.data)){
  dose.string = unlist(lovenox.dose.data[i])
  if(length(dose.string) == 2){
    lovenox.dose.amount[i] = dose.string[1]
    lovenox.dose.frequency[i] = dose.string[2]
  }
}

procedure.anticoagulation.plan.lovenox.data$Lovenox.Dose.Amount = as.numeric(lovenox.dose.amount)
procedure.anticoagulation.plan.lovenox.data$Lovenox.Dose.Frequency = toupper(trimws(lovenox.dose.frequency))

# Dataframe containing coumadin anticoagulation data
procedure.anticoagulation.plan.coumadin.data = procedure.data %>%
  filter(anticoag_type_plan___1 == 1) %>%
  select(record_id, Procedure.Number, plan_coumadin_dose, plan_coumadin_inr, 
         plan_coumadin_length)

procedure.anticoagulation.plan.coumadin.data$plan_coumadin_dose[procedure.anticoagulation.plan.coumadin.data$plan_coumadin_dose == "Alternating 15mg and 10mg"] = "12.5mg QD"
procedure.anticoagulation.plan.coumadin.data$plan_coumadin_dose[procedure.anticoagulation.plan.coumadin.data$plan_coumadin_dose == "2.5/2.5/5mg q3 days"] = "3mg QD"

# Separate coumadin dose amount from frequency data, splitting on dosage units (mg)
coumadin.dose.data = strsplit(procedure.anticoagulation.plan.coumadin.data$plan_coumadin_dose, "mg")
coumadin.dose.amount = rep("", times = length(coumadin.dose.data))
coumadin.dose.frequency = rep("", times = length(coumadin.dose.data))
for(i in 1:length(coumadin.dose.data)){
  dose.string = unlist(coumadin.dose.data[i])
  if(length(dose.string) == 2){
    coumadin.dose.amount[i] = dose.string[1]
    coumadin.dose.frequency[i] = dose.string[2]
  }
}

procedure.anticoagulation.plan.coumadin.data$Coumadin.Dose.Amount = as.numeric(coumadin.dose.amount)
procedure.anticoagulation.plan.coumadin.data$Coumadin.Dose.Frequency = toupper(trimws(coumadin.dose.frequency))

# Dataframe containing heparin anticoagulation data
procedure.anticoagulation.plan.heparin.data = procedure.data %>%
  filter(anticoag_type_plan___2 == 1) %>%
  select(record_id, Procedure.Number, plan_heparin_dose, plan_heparin_length)

# Dataframe containing fragmin anticoagulation data
procedure.anticoagulation.plan.fragmin.data = procedure.data %>%
  filter(anticoag_type_plan___3 == 1) %>%
  select(record_id, Procedure.Number, plan_fragmin_dose, plan_fragmin_length)

# Dataframe containing arixtra anticoagulation data
procedure.anticoagulation.plan.arixtra.data = procedure.data %>%
  filter(anticoag_type_plan___4 == 1) %>%
  select(record_id, Procedure.Number, plan_arixtra_dose, plan_arixtra_length) 

# Separate arixtra dose amount from frequency data, splitting on dosage units (mg)
arixtra.dose.data = strsplit(procedure.anticoagulation.plan.arixtra.data$plan_arixtra_dose, "mg")
arixtra.dose.amount = rep("", times = length(arixtra.dose.data))
arixtra.dose.frequency = rep("", times = length(arixtra.dose.data))
for(i in 1:length(arixtra.dose.data)){
  dose.string = unlist(arixtra.dose.data[i])
  if(length(dose.string) == 2){
    arixtra.dose.amount[i] = dose.string[1]
    arixtra.dose.frequency[i] = dose.string[2]
  }
}

procedure.anticoagulation.plan.arixtra.data$Arixtra.Dose.Amount = as.numeric(arixtra.dose.amount)
procedure.anticoagulation.plan.arixtra.data$Arixtra.Dose.Frequency = toupper(trimws(arixtra.dose.frequency))

# Dataframe containing xarelto data
procedure.anticoagulation.plan.xarelto.data = procedure.data %>%
  filter(anticoag_type_plan___5 == 1) %>%
  select(record_id, Procedure.Number, plan_xarelto_dose, plan_xarelto_length)

# Separate xarelto dose amount from frequency data, splitting on dosage units (mg)
xarelto.dose.data = strsplit(procedure.anticoagulation.plan.xarelto.data$plan_xarelto_dose, "mg")
xarelto.dose.amount = rep("", times = length(xarelto.dose.data))
xarelto.dose.frequency = rep("", times = length(xarelto.dose.data))
for(i in 1:length(xarelto.dose.data)){
  dose.string = unlist(xarelto.dose.data[i])
  if(length(dose.string) == 2){
    xarelto.dose.amount[i] = dose.string[1]
    xarelto.dose.frequency[i] = dose.string[2]
  }
}

procedure.anticoagulation.plan.xarelto.data$Xarelto.Dose.Amount = as.numeric(xarelto.dose.amount)
procedure.anticoagulation.plan.xarelto.data$Xarelto.Dose.Frequency = toupper(trimws(xarelto.dose.frequency))

# Dataframe containing plavix anticoagulation data
procedure.anticoagulation.plan.plavix.data = procedure.data %>%
  filter(anticoag_type_plan___6 == 1) %>%
  select(record_id, Procedure.Number, plan_plavix_dose, plan_plavix_length) 

# Separate plavix dose amount from frequency data, splitting on dosage units (mg)
plavix.dose.data = strsplit(procedure.anticoagulation.plan.plavix.data$plan_plavix_dose, "mg")
plavix.dose.amount = rep("", times = length(plavix.dose.data))
plavix.dose.frequency = rep("", times = length(plavix.dose.data))
for(i in 1:length(plavix.dose.data)){
  dose.string = unlist(plavix.dose.data[i])
  if(length(dose.string) == 2){
    plavix.dose.amount[i] = dose.string[1]
    plavix.dose.frequency[i] = dose.string[2]
  }
}

procedure.anticoagulation.plan.plavix.data$Plavix.Dose.Amount = as.numeric(plavix.dose.amount)
procedure.anticoagulation.plan.plavix.data$Plavix.Dose.Frequency = toupper(trimws(plavix.dose.frequency))

# Dataframe containing aspirin data
procedure.anticoagulation.plan.asa.data = procedure.data %>%
  filter(anticoag_type_plan___7 == 1) %>%
  select(record_id, Procedure.Number, plan_asa_dose, plan_asa_length)

# Separate aspirin dose amount from frequency data, splitting on dosage units (mg)
asa.dose.data = strsplit(procedure.anticoagulation.plan.asa.data$plan_asa_dose, "mg")
asa.dose.amount = rep("", times = length(asa.dose.data))
asa.dose.frequency = rep("", times = length(asa.dose.data))
for(i in 1:length(asa.dose.data)){
  dose.string = unlist(asa.dose.data[i])
  if(length(dose.string) == 2){
    asa.dose.amount[i] = dose.string[1]
    asa.dose.frequency[i] = dose.string[2]
  }
}

procedure.anticoagulation.plan.asa.data$Aspirin.Dose.Amount = as.numeric(asa.dose.amount)
procedure.anticoagulation.plan.asa.data$Aspirin.Dose.Frequency = toupper(trimws(asa.dose.frequency))

# Dataframe containing tPA data
procedure.anticoagulation.plan.tpa.data = procedure.data %>%
  filter(anticoag_type_plan___9 == 1) %>%
  select(record_id, Procedure.Number, plan_tpa_dose, plan_tpa_length) 

# Dataframe containing urokinase data
procedure.anticoagulation.plan.urokinase.data = procedure.data %>%
  filter(anticoag_type_plan___10 == 1) %>%
  select(record_id, Procedure.Number, plan_uro_dose, plan_uro_length)

# Dataframe containing other anticoagulant data
procedure.anticoagulation.plan.other.coagulant.data = procedure.data %>%
  filter(anticoag_type_plan___8 == 1) %>%
  select(plan_other, plan_other_dose, plan_other_length)

# Capitalize first letter of each word of Other Anticoagulant Name
procedure.anticoagulation.plan.other.coagulant.data$plan_other = toTitleCase(procedure.anticoagulation.plan.other.coagulant.data$plan_other)

# Separate other anticoagulatn dose amount from frequency data, splitting on dosage units (mg)
other.coagulant.dose.data = strsplit(procedure.anticoagulation.plan.other.coagulant.data$plan_other_dose, "mg")
other.coagulant.dose.amount = rep("", times = length(other.coagulant.dose.data))
other.coagulant.dose.frequency = rep("", times = length(other.coagulant.dose.data))
for(i in 1:length(other.coagulant.dose.data)){
  dose.string = unlist(other.coagulant.dose.data[i])
  if(length(dose.string) == 2){
    other.coagulant.dose.amount[i] = dose.string[1]
    other.coagulant.dose.frequency[i] = dose.string[2]
  }
}

procedure.anticoagulation.plan.other.coagulant.data$Other.Anticoagulant.Dose.Amount = as.numeric(other.coagulant.dose.amount)
procedure.anticoagulation.plan.other.coagulant.data$Other.Anticoagulant.Dose.Frequency = toupper(trimws(other.coagulant.dose.frequency))