# thrombolysis_catheter_infusion_processing.R

# This script pre-processes thrombolysis catheter infusion data derived from the 
# VITAL Retrospective database.

# Convert catheter infusion status predictors, from numeric based encodings, to
# string based encodings, based on VITAL Retrospective codebook
thrombolysis.procedure.data = thrombolysis.procedure.data %>%
  mutate(Alteplase.Catheter.Infusion.Status = ifelse(thrombolysis_infusion_meds___1 == 1, "Yes",
         ifelse(thrombolysis_infusion_meds___1 == 0, "No", NA))) %>%
  mutate(Argatroban.Catheter.Infusion.Status = ifelse(thrombolysis_infusion_meds___2 == 1, "Yes",
         ifelse(thrombolysis_infusion_meds___2 == 0, "No", NA))) %>%
  mutate(Bivalirudin.Catheter.Infusion.Status = ifelse(thrombolysis_infusion_meds___3 == 1, "Yes",
         ifelse(thrombolysis_infusion_meds___3 == 0, "No", NA))) %>%
  mutate(Heparin.Catheter.Infusion.Status = ifelse(thrombolysis_infusion_meds___4 == 1, "Yes",
         ifelse(thrombolysis_infusion_meds___4 == 0, "No", NA))) %>%
  mutate(Saline.Catheter.Infusion.Status = ifelse(thrombolysis_infusion_meds___5 == 1, "Yes",
         ifelse(thrombolysis_infusion_meds___5 == 0, "No", NA))) %>%
  mutate(Not.Applicable.Catheter.Infusion.Status = ifelse(thrombolysis_infusion_meds___98 == 1, "Yes",
         ifelse(thrombolysis_infusion_meds___98 == 0, "No", NA))) %>%
  select(-thrombolysis_infusion_meds___1, -thrombolysis_infusion_meds___2, -thrombolysis_infusion_meds___3,
         -thrombolysis_infusion_meds___4, -thrombolysis_infusion_meds___5, -thrombolysis_infusion_meds___98)

Right.Catheter.Infusion.Rate = rep(NA, times = nrow(thrombolysis.procedure.data))
Right.Catheter.Infusion.Units = rep(NA, times = nrow(thrombolysis.procedure.data))
Left.Catheter.Infusion.Rate = rep(NA, times = nrow(thrombolysis.procedure.data))
Left.Catheter.Infusion.Units = rep(NA, times = nrow(thrombolysis.procedure.data))

# Pre-processing thrombolysis catheter infusion amount/units
for(i in 1:nrow(thrombolysis.procedure.data)){
  right.catheter.infusion.value = trimws(thrombolysis.procedure.data$thrombolysis_rt_infus_rate[i])
  left.catheter.infusion.value = trimws(thrombolysis.procedure.data$thrombolysis_lt_infus_rate[i])
  # Separate catheter infusion value from units by splitting on whitespace
  right.catheter.infusion.value = unlist(strsplit(right.catheter.infusion.value, " "))
  left.catheter.infusion.value = unlist(strsplit(left.catheter.infusion.value, " "))
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  right.catheter.infusion.value[1] = gsub("[^0-9.]", "", right.catheter.infusion.value[1])
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  left.catheter.infusion.value[1] = gsub("[^0-9.]", "", left.catheter.infusion.value[1])
  Right.Catheter.Infusion.Rate[i] = trimws(right.catheter.infusion.value[1])
  Left.Catheter.Infusion.Rate[i] = trimws(left.catheter.infusion.value[1])
  # Identification of Catheter Infusion units if present
  if(length(right.catheter.infusion.value) >= 2){
    Right.Catheter.Infusion.Units[i] = trimws(tolower(right.catheter.infusion.value[2]))
  }
  if(length(left.catheter.infusion.value) >= 2){
    Left.Catheter.Infusion.Units[i] = trimws(tolower(left.catheter.infusion.value[2]))
  }
}

thrombolysis.procedure.data = cbind.data.frame(thrombolysis.procedure.data, Right.Catheter.Infusion.Rate, 
    Right.Catheter.Infusion.Units, Left.Catheter.Infusion.Rate, Left.Catheter.Infusion.Units)

thrombolysis.procedure.data$Right.Catheter.Infusion.Rate = as.numeric(thrombolysis.procedure.data$Right.Catheter.Infusion.Rate)
thrombolysis.procedure.data$Left.Catheter.Infusion.Rate = as.numeric(thrombolysis.procedure.data$Left.Catheter.Infusion.Rate)

thrombolysis.procedure.data = select(thrombolysis.procedure.data, -thrombolysis_rt_infus_rate, -thrombolysis_lt_infus_rate)