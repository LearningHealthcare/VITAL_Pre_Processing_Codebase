# procedure_io.R

# This script performs procedure data I/O. In addition, it serves as the overarching
# script for procedure data pre-processing.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Procedure Data I/O
procedure.data = read.csv(procedure.file.name, header = TRUE, 
                          stringsAsFactors = FALSE)

# Remove procedures without a listed procedure date
procedure.data = procedure.data %>%
  filter(redcap_repeat_instrument == "procedure") %>%
  filter(proc_date != "") %>%
  select(-redcap_repeat_instrument)

# List of veins that are included for many of the procedure types in this dataset, including
# stenting, angioplasty, thrombectomy etc.
procedure.vein.list = c("Suprarenal.IVC", "Infrarenal.IVC", "RCIV", "REIV", "RCFV", "RPFV",
                        "RFEMV", "RPOP", "LCIV", "LEIV", "LCFV", "LPFV", "LFEMV", 
                        "LPOP", "RBRACH", "LBRACH", "SVC")

names(procedure.data)[2] = "Procedure.Number"

# Convert Procedure Date to date/time format
procedure.data$proc_date = as.POSIXct(procedure.data$proc_date)

# Dataframe storing procedures that do not count toward patency calculations
non.patency.procedures = procedure.data %>%
  filter(reintervention == 1) %>%
  select(record_id, Procedure.Number) %>%
  mutate(Record.ID.Procedure.Number.Identifier = paste(record_id, Procedure.Number, sep = "+"))

source(paste(procedure.code.directory, 'clinician_data_processing.R', sep = '/'))

source(paste(procedure.code.directory, 'procedure_performed_report_data_processing.R', sep = '/'))

source(paste(procedure.code.directory, 'standalone_angioplasty_data_processing.R', sep = '/'))

source(paste(procedure.code.directory, 'procedure_stenting_data_processing.R', sep = '/'))

source(paste(procedure.code.directory, 'stent_angioplasty_data_processing.R', sep = '/'))

source(paste(procedure.code.directory, 'other_procedure_details_data_processing.R', sep = '/'))

source(paste(procedure.code.directory, 'procedure_medications_data_processing.R', sep = '/'))

source(paste(procedure.code.directory, 'procedure_anti_coagulation_plan_pre_processing.R', sep = '/'))

source(paste(procedure.code.directory, 'procedure_anti_coagulation_plan_calculations.R', sep = '/'))

# Dataframe storing Procedure Complications Data
procedure.complications.data = procedure.data %>%
  filter(complications == 1) %>%
  select(record_id, Procedure.Number, complication_major_minor, complication_notes) %>%
  mutate(Complication.Major.Minor.Status = ifelse(complication_major_minor == 2, "Major",
        ifelse(complication_major_minor == 1, "Minor", NA))) %>%
  select(-complication_major_minor)

source(paste(procedure.code.directory, 'free_up_memory_procedure_data.R', sep = '/'))