# procedures_medications_data_processing.R

# This script pre-processes medications data administered during procedures,
# as derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing general anesthesia data
general.anesthesia.procedure.data = procedure.data %>%
  select(record_id, Procedure.Number, gen_anes) %>%
  mutate(General.Anesthesia.Status = ifelse(gen_anes == 1, "Yes",
         ifelse(gen_anes == 0, "No", NA))) %>%
  select(-gen_anes)

# Dataframe containing medication dosage data
medication.dose.procedure.data = procedure.data %>%
  select(record_id, Procedure.Number, intra_hep_dose,
  intra_lov_dose, intra_tpa_dose, intra_tnk_dose, intra_uro_dose,
  intra_versed_dose, intra_fent_dose, intra_dilaudid_dose, intra_phener_dose,
  intra_zofran_dose, intra_ben_dose, intra_sodbicarb_dose, other_intra_notes) %>%
  gather(Medication, Dose, -record_id, -Procedure.Number, -other_intra_notes) %>%
  # Remove rows with missing dosage data
  filter(!is.na(Dose) & Dose != "")

# Dataframe containing contrast radiation dose/amount data
contrast.radiation.procedure.data = procedure.data %>%
  select(record_id, Procedure.Number, intra_isovue_dose, visipaque_amt, intra_magne_amt, intra_omni_amt, 
         intra_radiation_dose) %>%
  gather(Contrast, Contrast.Value, -record_id, -Procedure.Number, -intra_radiation_dose) %>%
  # Remove rows with missing dosage/amount data
  filter(!is.na(Contrast.Value) & Contrast.Value != "") 

# Dataframe containing patient height and weight at time of procedure
patient.procedure.height.weight = procedure.data %>%
  select(record_id, Procedure.Number, height, weight) %>%
  # Remove rows with both heights and weights missing
  filter(!is.na(height) | !is.na(weight))