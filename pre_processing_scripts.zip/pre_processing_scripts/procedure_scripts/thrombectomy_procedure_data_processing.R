# thrombectomy_procedure_data_processing.R

# This script pre-processes throbectomy procedure data derived from
# the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# List of thrombectomy devices
thrombectomy.device.list = c("AngioJet", "AngioVac", "Balloon.Maceration", "Balloon.Sweep",
  "Penumbra.Indigo", "Pigtail.Catheter", "Trerotola", "The.Cleaner", "Trellis", "Excimer.Laser.Catheter",
  "Helix.Clotbuster", "Other.Thrombectomy.Device")

thrombectomy.device.list = c("record_id", "Procedure.Number", thrombectomy.device.list)

# Dataframe containing thrombectomy location procedure data
thrombectomy.location.procedure.data = procedure.data %>%
  filter(other_procedures_performed___2 == 1) %>%
  select(record_id, Procedure.Number, thrombectomy_location___1, thrombectomy_location___2, 
         thrombectomy_location___3, thrombectomy_location___4, thrombectomy_location___5, 
         thrombectomy_location___6, thrombectomy_location___7, thrombectomy_location___8, 
         thrombectomy_location___9, thrombectomy_location___10, thrombectomy_location___11,
         thrombectomy_location___12, thrombectomy_location___13, thrombectomy_location___14,
         thrombectomy_location___15, thrombectomy_location___16, thrombectomy_location___17)

# Assign string-based names of veins as column names
names(thrombectomy.location.procedure.data) = c("record_id", "Procedure.Number", procedure.vein.list)

# Filter rows where thrombectomy procedures were not performed (i.e. preferentially keep rows
# referring to veins where thrombectomy procedures occurred)
thrombectomy.location.procedure.data = thrombectomy.location.procedure.data %>%
  gather(Vein, Status, -record_id, -Procedure.Number) %>%
  filter(Status == 1) %>%
  select(-Status)

# Dataframe containing clinical notes on thrombectomy procedures
thrombectomy.other.details.data = procedure.data %>%
  filter(other_procedures_performed___2 == 1) %>%
  select(record_id, Procedure.Number, thrombectomy_other_details) %>%
  filter(thrombectomy_other_details != "")

# Dataframe containing thrombectomy procedure method data
thrombectomy.method.procedure.data = procedure.data %>%
  filter(other_procedures_performed___2 == 1) %>%
  select(record_id, Procedure.Number, thrombectomy_method___1, thrombectomy_method___2,
         thrombectomy_method___3, thrombectomy_method___4, thrombectomy_method___99)

# Assign string-based names of methods used perform thrombectomy procedures
names(thrombectomy.method.procedure.data) = c("record_id", "Procedure.Number", 
    "Mechanical.Status", "Rheolytic.Status", "Suction.Status", "Laser.Status",
    "Other.Method.Status")

# Filter rows where thrombectomy procedures were not performed (i.e. preferentially keep rows
# referring to methods where thrombectomy procedures occurred)
thrombectomy.method.procedure.data = thrombectomy.method.procedure.data %>%
  gather(Method, Method.Status, -record_id, -Procedure.Number) %>%
  mutate(Status = ifelse(Method.Status == 1, "Yes", NA)) %>%
  select(-Method.Status) %>%
  spread(Method, Status)

# Dataframe containing thrombectomy device data
thrombectomy.device.data = procedure.data %>%
  filter(other_procedures_performed___2 == 1) %>%
  select(record_id, Procedure.Number, thrombectomy_device___1, thrombectomy_device___2, 
         thrombectomy_device___3, thrombectomy_device___4, thrombectomy_device___5, 
         thrombectomy_device___6, thrombectomy_device___7, thrombectomy_device___8,
         thrombectomy_device___9, thrombectomy_device___10, thrombectomy_device___11,
         thrombectomy_device___99)

# Assign string-based names of devices used in performing throbectomy procedures
names(thrombectomy.device.data) = thrombectomy.device.list

# Filter rows where thrombectomy procedures were not performed (i.e. preferentially keep rows
# referring to devices where thrombectomy procedures occurred)
thrombectomy.device.data = thrombectomy.device.data %>%
  gather(Device, Device.Status, -record_id, -Procedure.Number) %>%
  mutate(Status = ifelse(Device.Status == 1, "Yes", NA)) %>%
  select(-Device.Status) %>%
  spread(Device, Status)

# Dataframe containing data on angiojet usage as part of thrombectomy procedures
thrombectomy.angiojet.procedure.data = procedure.data %>%
  filter(thrombectomy_device___1 == 1) %>%
  select(record_id, angiojet_mode___1, angiojet_mode___2, angiojet_med___1, angiojet_med___1, 
         angiojet_med___99, angiojet_med_other, angiojet_wait, angiojet_time) %>%
  mutate(Power.Pulse.Spray.Status = ifelse(angiojet_mode___1 == 1, "Yes", NA)) %>%
  mutate(Conventional.Mode.Status = ifelse(angiojet_mode___2 == 1, "Yes", NA)) %>%
  mutate(tPA.Status = ifelse(angiojet_med___1 == 1, "Yes", NA)) %>%
  mutate(Other.Med.Status = ifelse(angiojet_med___99 == 1, "Yes", NA)) %>%
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  mutate(Angiojet.Wait.Time = gsub("[^0-9\\.]", "", angiojet_wait)) %>%
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  mutate(Angiojet.Total.Run.Time = gsub("[^0-9\\.]", "", angiojet_time)) %>%
  select(-angiojet_mode___1, -angiojet_mode___2, -angiojet_med___1, -angiojet_med___1, 
         -angiojet_med___99, -angiojet_wait, -angiojet_time)

thrombectomy.angiojet.procedure.data$Angiojet.Wait.Time = as.numeric(thrombectomy.angiojet.procedure.data$Angiojet.Wait.Time)
thrombectomy.angiojet.procedure.data$Angiojet.Total.Run.Time = as.numeric(thrombectomy.angiojet.procedure.data$Angiojet.Total.Run.Time)