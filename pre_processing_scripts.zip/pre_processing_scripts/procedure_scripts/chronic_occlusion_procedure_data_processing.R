# chronic_occlusion_procedure_data_processing.R

# This script is responsible for pre-processing the chronic occlusion data derived
# from the VITAL Retrospective database.

# By David Cohn

# Dataframe containing chronic occlusion location data
chronic.occlusion.location.data = procedure.data %>%
  filter(other_procedures_performed___5 == 1) %>%
  select(record_id, Procedure.Number, chron_occlu_location___1, chron_occlu_location___2,
         chron_occlu_location___3, chron_occlu_location___4, chron_occlu_location___5, 
         chron_occlu_location___6, chron_occlu_location___7, chron_occlu_location___8,
         chron_occlu_location___9, chron_occlu_location___10, chron_occlu_location___11,
         chron_occlu_location___12, chron_occlu_location___13, chron_occlu_location___14,
         chron_occlu_location___15, chron_occlu_location___16, chron_occlu_location___17) 

# Assign string-based names of locations where chronic occlusion procedures were performed
names(chronic.occlusion.location.data) = c("record_id", "Procedure.Number", procedure.vein.list)

# Filter rows where chronic occlusion procedures were not performed (i.e. preferentially keep rows
# referring to veins where chronic occlusion procedures occurred)
chronic.occlusion.location.data = chronic.occlusion.location.data %>%
  gather(Location, Occlusion.Status, -record_id, -Procedure.Number) %>%
  mutate(Status = ifelse(Occlusion.Status == 1, "Yes", NA)) %>%
  select(-Occlusion.Status) %>%
  spread(Location, Status)

# Create list of tried devices by device number, in order to efficiently select columns
# containing chronic occlusion tried devices data
chronic.occlusion.tried.devices.list = paste(rep("chron_occlu_tried", times = chronic.occlusion.devices), seq(1, chronic.occlusion.devices),
                                             sep = "___")
chronic.occlusion.tried.devices.list = c("record_id", "Procedure.Number", chronic.occlusion.tried.devices.list)

# List of Chronic Occlusion Device Names
chronic.occlusion.devices.names = c("Front.End.Regular.Glidewire", 
  "Front.End.Stiff.Glidewire", "Back.End.Regular.Glidewire", "Back.End.Stiff.Glidewire", "Five.Fr.Glide",
  "Five.Fr.Braided", "Outback", "Frontrunner", "Roadrunner", "Chiba.Needle", "Triforce", "Guiding.Catheter",
  "Other.Chronic.Occlusion.Device")

chronic.occlusion.tried.devices.names = paste(chronic.occlusion.devices.names, 
        rep("Tried", times = length(chronic.occlusion.devices.names)), sep = ".")
chronic.occlusion.successful.devices.names = paste(chronic.occlusion.devices.names, 
        rep("Successful", times = length(chronic.occlusion.devices.names)), sep = ".")
chronic.occlusion.successful.devices.names = c("record_id", "Procedure.Number", chronic.occlusion.successful.devices.names)
chronic.occlusion.tried.devices.names = c("record_id", "Procedure.Number", chronic.occlusion.tried.devices.names)

# Dataframe containing data on devices tried, as part of chronic occlusion procedures
chronic.occlusion.tried.data = procedure.data %>%
  filter(other_procedures_performed___5 == 1) %>%
  select(chronic.occlusion.tried.devices.list) %>%
  gather(Device, Device.Status, -record_id, -Procedure.Number) %>%
  mutate(Status = ifelse(Device.Status == 1, "Yes", NA)) %>%
  select(-Device.Status) %>%
  spread(Device, Status)

# Re-organize chronic occlusion tried devices data by device and device number
chronic.occlusion.tried.data = chronic.occlusion.tried.data[chronic.occlusion.tried.devices.list]

# Assign string-based device names as columns to chronic occlusion tried devices dataframe
names(chronic.occlusion.tried.data) = chronic.occlusion.tried.devices.names

# Create list of tried devices by device number, in order to efficiently select columns
# containing chronic occlusion successful devices data
chronic.occlusion.successful.devices.list = paste(rep("chron_occlu_success", times = chronic.occlusion.devices), 
  seq(1, chronic.occlusion.devices), sep = "___")
chronic.occlusion.successful.devices.list = c("record_id", "Procedure.Number", chronic.occlusion.successful.devices.list)

# Dataframe containing data on successful devices, as part of chronic occlusion procedures
chronic.occlusion.success.data = procedure.data %>%
  filter(other_procedures_performed___5 == 1) %>%
  select(chronic.occlusion.successful.devices.list) %>%
  gather(Device, Device.Status, -record_id, -Procedure.Number) %>%
  mutate(Status = ifelse(Device.Status == 1, "Yes", NA)) %>%
  select(-Device.Status) %>%
  spread(Device, Status)

# Re-organize chronic occlusion successful devices data by device and device number
chronic.occlusion.success.data = chronic.occlusion.success.data[chronic.occlusion.successful.devices.list]

# Assign string-based device names as columns to chronic occlusion successful devices dataframe
names(chronic.occlusion.success.data) = chronic.occlusion.successful.devices.names