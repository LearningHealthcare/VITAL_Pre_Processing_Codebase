# standalone_angioplasty_data_processing.R

# This script performs data pre-processing on the standalone angioplasty data
# contained in the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing data on whether a standalone angioplasty was performed
standalone.general.angioplasty.procedure.data = procedure.data %>%
  select(record_id, Procedure.Number, plasty_performed, plasty_number) %>%
  mutate(Stand.Alone.Angioplasty.Status = ifelse(plasty_performed == 1, "Yes",
         ifelse(plasty_performed == 0, "No", NA))) %>%
  select(-plasty_performed)

standalone.general.angioplasty.procedure.data$plasty_number = as.numeric(standalone.general.angioplasty.procedure.data$plasty_number)  

# Dataframe containing data on angioplasty brand
standalone.angioplasty.brand.procedure.data = procedure.data %>%
  filter(!is.na(plasty_number)) %>%
  select(record_id, Procedure.Number, plasty1_brand, plasty2_brand, plasty3_brand, plasty4_brand,
         plasty5_brand, plasty6_brand, plasty7_brand, plasty8_brand, plasty9_brand, plasty10_brand) %>%
  gather(Plasty.Number, Brand, -record_id, -Procedure.Number) %>%
  filter(!is.na(Brand))

standalone.angioplasty.brand.procedure.data$Brand = tolower(standalone.angioplasty.brand.procedure.data$Brand)
# Capitalize first letter of every word in angioplasty brand
standalone.angioplasty.brand.procedure.data$Brand = toTitleCase(standalone.angioplasty.brand.procedure.data$Brand)

standalone.angioplasty.brand.procedure.data$Brand[standalone.angioplasty.brand.procedure.data$Brand == "Xxl"] = "XXL"
standalone.angioplasty.brand.procedure.data$Brand[standalone.angioplasty.brand.procedure.data$Brand == "Axm"] = "AXM"

# Code Citation
# Title: Nabble, Removing non-numeric characters from a string in R
# Date: July 26, 2016
# Type: Code from Nabble Question
# Availability: http://r.789695.n4.nabble.com/removing-all-non-numeric-characters-from-a-string-but-not-quot-quot-td4723146.html
# Dataframe containing data on angioplasty diameter
standalone.angioplasty.diameter.procedure.data = procedure.data %>%
  filter(!is.na(plasty_number)) %>%
  select(record_id, Procedure.Number, plasty1_diameter, plasty2_diameter, plasty3_diameter, plasty4_diameter,
         plasty5_diameter, plasty6_diameter, plasty7_diameter, plasty8_diameter, plasty9_diameter, 
         plasty10_diameter) %>%
  gather(Plasty.Number, Diameter, -record_id, -Procedure.Number) %>%
  filter(!is.na(Diameter)) %>%
  # Remove Non-Numeric characters from Diameter Strings
  mutate(Diameter.Value = gsub("[^0-9\\.]", "", Diameter)) %>%
  select(-Diameter)

# Remove Whitespace
standalone.angioplasty.diameter.procedure.data$Diameter.Value = trimws(standalone.angioplasty.diameter.procedure.data$Diameter.Value)
standalone.angioplasty.diameter.procedure.data$Diameter.Value = as.numeric(standalone.angioplasty.diameter.procedure.data$Diameter.Value)

# Dataframe containing data on angioplasty length
standalone.angioplasty.length.procedure.data = procedure.data %>%
  filter(!is.na(plasty_number)) %>%
  select(record_id, Procedure.Number, plasty1_length, plasty2_length, plasty3_length,
    plasty4_length, plasty5_length, plasty6_length, plasty7_length, plasty8_length,
    plasty9_length, plasty10_length) %>%
  gather(Plasty.Number, Length, -record_id, -Procedure.Number) %>%
  filter(!is.na(Length)) %>%
  # See earlier citation regarding removing non-numeric characters from string
  mutate(Length.Value = gsub("[^0-9\\.]", "", Length)) %>%
  select(-Length)

# Remove Whitespace
standalone.angioplasty.length.procedure.data$Length.Value = trimws(standalone.angioplasty.length.procedure.data$Length.Value)
standalone.angioplasty.length.procedure.data$Length.Value = as.numeric(standalone.angioplasty.length.procedure.data$Length.Value)

# Create list of vein locations by plasty number, in order to efficiently select columns
# containing angioplasty location data
plasty.vector = paste(rep("plasty", times = 10), seq(1, maximum.angioplasty.count), sep = "")
location.vector = paste(rep("location"), seq(1, angioplasty.locations), sep = '___')
plasty.location.vector = as.vector(outer(plasty.vector, location.vector, paste, sep = "_"))
plasty.location.vector = c("record_id", "Procedure.Number", plasty.location.vector)
plasty.location.string.vector = procedure.vein.list
plasty.names.vector = as.vector(outer(plasty.vector,plasty.location.string.vector, paste, sep = "_"))
plasty.names.vector = c("record_id", "Procedure.Number", plasty.names.vector)

# Dataframe containing angioplasty location data
standalone.angioplasty.location.procedure.data = procedure.data %>%
  filter(!is.na(plasty_number)) %>%
  select(plasty.location.vector) %>%
  gather(Plasty.Location.Number, Encoding, -record_id, -Procedure.Number) %>%
  # Presence("Yes")/Absence(NA) of Angioplasty in Vein Location
  mutate(Value = ifelse(Encoding == 1, "Yes", NA)) %>%
  select(-Encoding) %>%
  spread(Plasty.Location.Number, Value)

# Re-arrange columns in angioplasty location dataframe, by plasty number and vein
standalone.angioplasty.location.procedure.data = standalone.angioplasty.location.procedure.data[plasty.location.vector]

# Assign string-based vein names to angioplasty location data
names(standalone.angioplasty.location.procedure.data) = plasty.names.vector