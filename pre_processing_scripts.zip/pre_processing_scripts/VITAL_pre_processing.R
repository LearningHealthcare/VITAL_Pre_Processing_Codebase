# VITAL_pre_processing.R

# This script serves as the overarching workflow for pre-processing data from the VITAL Retrospective database.
# This codebase processes data from the following data tables that are extracted from the VITAL Retrospective database:
# 1) Record ID, MRN and Accession, 2) Record ID and MRN, 3) Demographics, 4) Procedures, 5) VTE Risk Factors, 6) Medical History,
# 7) Imaging, 8) Non-IR Encounters, 9) IR Clinic Visits, 10) Medications, 11) Labs, and 12) Cancer Registry.

# Conversion of Numerical Encodings to String-based Encodings are based on VITAL Retrospective codebook. Please
# refer to the VITAL Retrospective codebook when examining these conversions.

# Comments within the various submethods of this pre-processing pipeline will describe the details of the pre-processing workflow
# in greater detail.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# R library packages used in pre-processing pipeline
library(dplyr)
library(tidyr)
library(lubridate)
library(stringi)
library(tools)

# Overarching pre-processing code directory
pre.processing.code.directory = '/Users/David/Documents/VITAL_Projects/pre_processing_scripts'

source(paste(pre.processing.code.directory, 'define_constants_code_paths.R', sep = '/'))

remove(pre.processing.code.directory)

setwd(vital.retrospective.data.directory)

source(paste(record.id.mrn.acession.code.directory, 'record_id_mrn_accession_io.R', sep = '/'))

remove(record.id.mrn.acession.code.directory)

source(paste(demographics.code.directory, 'demographics_io.R', sep = '/'))

remove(demographics.code.directory)

source(paste(procedure.code.directory, 'procedure_io.R', sep = '/'))

remove(procedure.code.directory)

source(paste(vte.code.directory, 'vte_io.R', sep = '/'))

remove(vte.code.directory)

source(paste(medical.history.code.directory, 'medical_history_data_processing.R', sep = '/'))

remove(medical.history.code.directory)

source(paste(imaging.data.code.directory, 'imaging_data_pre_processing.R', sep = '/'))

remove(imaging.data.code.directory)

source(paste(non.ir.clinic.visit.directory, 'non_IR_Clinic_Visit_io.R', sep = '/'))

remove(non.ir.clinic.visit.directory)

source(paste(ir.clinic.visit.directory, 'IR_Clinic_Visit_data_processing.R', sep = '/'))

remove(ir.clinic.visit.directory)

source(paste(medications.directory, 'medications_data_processing.R', sep = '/'))

remove(medications.directory)

source(paste(labs.directory, 'labs_data_processing.R', sep = '/'))

remove(labs.directory)

source(paste(cancer.registry.directory, 'cancer_registry_data_processing.R', sep = '/'))

remove(cancer.registry.directory)
