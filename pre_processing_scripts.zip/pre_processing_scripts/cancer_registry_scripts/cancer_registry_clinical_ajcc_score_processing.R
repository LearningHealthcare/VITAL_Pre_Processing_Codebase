# cancer_registry_clinical_ajcc_score_processing.R

# This script pre-processes clinical TNM scoring data,
# derived from the VITAL Retrospective database.

# By David Cohn

# Convert clinical TNM scoring from numerical encodings to string-based encodings,
# based on VITAL Retrospective codebook
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 1] = "C0"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 2] = "C1"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 3] = "C1A"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 4] = "C1B"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 5] = "C1C"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 6] = "C2"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 7] = "C2A"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 8] = "C2B"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 9] = "C2C"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 10] = "C3"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 11] = "C3A"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 12] = "C3B"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 13] = "C4"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 14] = "C4A"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 15] = "C4B"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 16] = "C4D"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 17] = "CX"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 18] = "PA"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 19] = "PIS"
cancer.registry.data$clinical_t[cancer.registry.data$clinical_t == 20] = "N/A"

cancer.registry.data$clinical_n[cancer.registry.data$clinical_n == 1] = "C0"
cancer.registry.data$clinical_n[cancer.registry.data$clinical_n == 2] = "C1"
cancer.registry.data$clinical_n[cancer.registry.data$clinical_n == 3] = "C1A"
cancer.registry.data$clinical_n[cancer.registry.data$clinical_n == 4] = "C1B"
cancer.registry.data$clinical_n[cancer.registry.data$clinical_n == 5] = "C2"
cancer.registry.data$clinical_n[cancer.registry.data$clinical_n == 6] = "C2A"
cancer.registry.data$clinical_n[cancer.registry.data$clinical_n == 7] = "C2B"
cancer.registry.data$clinical_n[cancer.registry.data$clinical_n == 8] = "C2C"
cancer.registry.data$clinical_n[cancer.registry.data$clinical_n == 9] = "C3"
cancer.registry.data$clinical_n[cancer.registry.data$clinical_n == 10] = "CX"
cancer.registry.data$clinical_n[cancer.registry.data$clinical_n == 11] = "N/A"

cancer.registry.data$clinical_m[cancer.registry.data$clinical_m == 1] = "C0"
cancer.registry.data$clinical_m[cancer.registry.data$clinical_m == 2] = "C1"
cancer.registry.data$clinical_m[cancer.registry.data$clinical_m == 3] = "C1A"
cancer.registry.data$clinical_m[cancer.registry.data$clinical_m == 4] = "C1B"
cancer.registry.data$clinical_m[cancer.registry.data$clinical_m == 5] = "C1C"
cancer.registry.data$clinical_m[cancer.registry.data$clinical_m == 6] = "CX"
cancer.registry.data$clinical_m[cancer.registry.data$clinical_m == 7] = "P1"
cancer.registry.data$clinical_m[cancer.registry.data$clinical_m == 8] = "P1A"
cancer.registry.data$clinical_m[cancer.registry.data$clinical_m == 9] = "P1C"
cancer.registry.data$clinical_m[cancer.registry.data$clinical_m == 10] = "N/A"