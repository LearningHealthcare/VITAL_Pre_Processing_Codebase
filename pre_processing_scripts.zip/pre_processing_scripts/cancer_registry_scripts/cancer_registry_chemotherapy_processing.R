# cancer_registry_chemotherapy_processing.R

# This script performs pre-processing on cancer registry chemotherapy data,
# derived from the VITAL Retrospective Database.

# By David Cohn

# Convert chemotherapy data from numerical encodings to string-based encodings,
# based on VITAL Retrospective codebook
cancer.registry.data$chemotherapy_reason_no_rx[cancer.registry.data$chemotherapy_reason_no_rx == 0] = "Chemotherapy Performed"
cancer.registry.data$chemotherapy_reason_no_rx[cancer.registry.data$chemotherapy_reason_no_rx == 1] = "Not Recommended"
cancer.registry.data$chemotherapy_reason_no_rx[cancer.registry.data$chemotherapy_reason_no_rx == 2] = "Contraindicated"
cancer.registry.data$chemotherapy_reason_no_rx[cancer.registry.data$chemotherapy_reason_no_rx == 5] = "Patient Died"
cancer.registry.data$chemotherapy_reason_no_rx[cancer.registry.data$chemotherapy_reason_no_rx == 6] = "Reason Unknown"
cancer.registry.data$chemotherapy_reason_no_rx[cancer.registry.data$chemotherapy_reason_no_rx == 7] = "Refused"
cancer.registry.data$chemotherapy_reason_no_rx[cancer.registry.data$chemotherapy_reason_no_rx == 8] = "Recommended, Unknown if Given"
cancer.registry.data$chemotherapy_reason_no_rx[cancer.registry.data$chemotherapy_reason_no_rx == 9] = "Unknown if chemotherapy either recommended or given"

cancer.registry.data$chemotherapy_summary[cancer.registry.data$chemotherapy_summary == 0] = "None, Diagnosed At Autopsy"
cancer.registry.data$chemotherapy_summary[cancer.registry.data$chemotherapy_summary == 1] = "Chemotherapy, NOS"
cancer.registry.data$chemotherapy_summary[cancer.registry.data$chemotherapy_summary == 2] = "Single Agent"
cancer.registry.data$chemotherapy_summary[cancer.registry.data$chemotherapy_summary == 3] = "Multiple Agents"
cancer.registry.data$chemotherapy_summary[cancer.registry.data$chemotherapy_summary == 82] = "Contraindicated"
cancer.registry.data$chemotherapy_summary[cancer.registry.data$chemotherapy_summary == 85] = "Patient died prior to therapy"
cancer.registry.data$chemotherapy_summary[cancer.registry.data$chemotherapy_summary == 86] = "Recommended, not given"
cancer.registry.data$chemotherapy_summary[cancer.registry.data$chemotherapy_summary == 87] = "Refused"
cancer.registry.data$chemotherapy_summary[cancer.registry.data$chemotherapy_summary == 88] = "Recommended, unknown if given"
cancer.registry.data$chemotherapy_summary[cancer.registry.data$chemotherapy_summary == 99] = "Unknown or DCO"

cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 0] = "Unreferred Patient"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 10846] = "Highland Hospital"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 10858] = "Kaiser Hayward"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 190385] = "Holy Cross"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 190796] = "UCLA"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 281047] = "Queen Valley Napa"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 301279] = "UCI"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 380857] = "Kaiser SF"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 380920] = "California Pacific"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 381154] = "UCSF"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 430741] = "Lucile Packard"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 430763] = "El Camino"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 430779] = "Good Sam San Jose"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 430837] = "Oconnor San Jose"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 430883] = "Santa Clara Valley"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 430905] = "Stanford"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 431506] = "Kaiser Santa Teresa"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 438800] = "Camino Medical Group"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 439995] = "Palo Alto VA"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 439998] = "Palo Alto Medical Foundation"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 490001] = "Petaluma Valley"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 989035] = "Florida State Registrar"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 989039] = "Mississippi State Registrar"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 999987] = "Unspecified Central California Hospital"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 999988] = "Unspecified Northern California Hosptial"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 999994] = "Unspecified Non-California Hospital"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 999996] = "Physician Only"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 999997] = "Unspecified Bay Area Hospital"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 999998] = "Unspecified California Hospital"
cancer.registry.data$chemotherapy_hospital_of_rx[cancer.registry.data$chemotherapy_hospital_of_rx == 999999] = "Unknown Hospital"