# cancer_registry_pathology_stage_processing.R

# This script pre-processes pathological stage and staged by data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Converts pathological stage and staged by data from numerical encodings,
# to string-based encodings, based on VITAL Retrospective codebook
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 1] = "0"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 2] = "0A"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 3] = "1"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 4] = "1A"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 5] = "1B"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 6] = "1C"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 7] = "2"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 8] = "2A"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 9] = "2B"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 10] = "2C"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 11] = "3"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 12] = "3A"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 13] = "3B"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 14] = "3C"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 15] = "3C1"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 16] = "4"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 17] = "4A"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 18] = "4B"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 19] = "4C"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 20] = "N/A"
cancer.registry.data$pathological_stage[cancer.registry.data$pathological_stage == 21] = "Unknown"

cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 0] = "Not Staged"
cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 10] = "Physician, NOS, or physician not specified"
cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 11] = "Surgeon"
cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 12] = "Radiation Oncologist"
cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 13] = "Medical Oncologist"
cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 14] = "Pathologist"
cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 15] = "Multiple Physicians, Tumor Board etc."
cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 20] = "Cancer Registrar"
cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 30] = "Cancer Registrar and Physician"
cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 40] = "Non-Physician Medical Staff"
cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 50] = "Other Facility"
cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 60] = "Central Registry"
cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 88] = "Not Eligible For Staging"
cancer.registry.data$pathological_staged_by[cancer.registry.data$pathological_staged_by == 99] = "Staged, but unknown who assigned staging"