# cancer_registry_diagnosis_date_grade_metastasis_processing.R

# This script performs pre-processing on cancer registry, diagnosis date flag description,
# grade and metastasis data dervied from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Convert disease date flag description from numerical encodings to string-based encodings,
# based on VITAL Retrospective codebook
cancer.registry.data$dx_date_flag_desc[cancer.registry.data$dx_date_flag_desc == 1] = "Exact"
cancer.registry.data$dx_date_flag_desc[cancer.registry.data$dx_date_flag_desc == 2] = "Day-Approximation"
cancer.registry.data$dx_date_flag_desc[cancer.registry.data$dx_date_flag_desc == 3] = "Month, Day-Approximation"
cancer.registry.data$dx_date_flag_desc[cancer.registry.data$dx_date_flag_desc == 4] = "Unknown"

# Convert cancer grade and differentiation data from numerical encodings to string-based encodings,
# based on VITAL Retrospective codebook
cancer.registry.data$grade_differentiation[cancer.registry.data$grade_differentiation == 1] = "Grade I"
cancer.registry.data$grade_differentiation[cancer.registry.data$grade_differentiation == 2] = "Grade II"
cancer.registry.data$grade_differentiation[cancer.registry.data$grade_differentiation == 3] = "Grade III"
cancer.registry.data$grade_differentiation[cancer.registry.data$grade_differentiation == 4] = "Grade IV"
cancer.registry.data$grade_differentiation[cancer.registry.data$grade_differentiation == 5] = "B-Cell"
cancer.registry.data$grade_differentiation[cancer.registry.data$grade_differentiation == 6] = "T-Cell"
cancer.registry.data$grade_differentiation[cancer.registry.data$grade_differentiation == 7] = "NK-Cell"
cancer.registry.data$grade_differentiation[cancer.registry.data$grade_differentiation == 8] = "Not Stated"

# Convert cancer metastasis data from numerical encodings to string-based encodings,
# based on VITAL Retrospective codebook
cancer.registry.data$metastasis_at_dx_disp[cancer.registry.data$metastasis_at_dx_disp == 1] = "Distant Lymph Node(s)"
cancer.registry.data$metastasis_at_dx_disp[cancer.registry.data$metastasis_at_dx_disp == 2] = "Distant Lymph Node(s) and Distant Metastases"
cancer.registry.data$metastasis_at_dx_disp[cancer.registry.data$metastasis_at_dx_disp == 3] = "Distant Metastases"
cancer.registry.data$metastasis_at_dx_disp[cancer.registry.data$metastasis_at_dx_disp == 4] = "Other"
cancer.registry.data$metastasis_at_dx_disp[cancer.registry.data$metastasis_at_dx_disp == 5] = "None"
cancer.registry.data$metastasis_at_dx_disp[cancer.registry.data$metastasis_at_dx_disp == 6] = "N/A"
cancer.registry.data$metastasis_at_dx_disp[cancer.registry.data$metastasis_at_dx_disp == 7] = "Unknown"