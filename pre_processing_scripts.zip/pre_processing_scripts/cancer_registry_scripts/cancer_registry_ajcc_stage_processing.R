# cancer_registry_ajcc_stage_processing.R

# This script pre-processes Cancer Registry AJCC stage data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Converts AJCC stage from numerical encoding to string-based encoding,
# based on VITAL Retrospective Codebook
cancer.registry.data$stage[cancer.registry.data$stage == 1] = "0"
cancer.registry.data$stage[cancer.registry.data$stage == 2] = "0A"
cancer.registry.data$stage[cancer.registry.data$stage == 3] = "1"
cancer.registry.data$stage[cancer.registry.data$stage == 4] = "1A"
cancer.registry.data$stage[cancer.registry.data$stage == 5] = "1B"
cancer.registry.data$stage[cancer.registry.data$stage == 6] = "1C"
cancer.registry.data$stage[cancer.registry.data$stage == 7] = "2"
cancer.registry.data$stage[cancer.registry.data$stage == 8] = "2A"
cancer.registry.data$stage[cancer.registry.data$stage == 9] = "2B"
cancer.registry.data$stage[cancer.registry.data$stage == 10] = "2C"
cancer.registry.data$stage[cancer.registry.data$stage == 11] = "3"
cancer.registry.data$stage[cancer.registry.data$stage == 12] = "3A"
cancer.registry.data$stage[cancer.registry.data$stage == 13] = "3B"
cancer.registry.data$stage[cancer.registry.data$stage == 14] = "3C"
cancer.registry.data$stage[cancer.registry.data$stage == 15] = "3C1"
cancer.registry.data$stage[cancer.registry.data$stage == 16] = "4"
cancer.registry.data$stage[cancer.registry.data$stage == 17] = "4A"
cancer.registry.data$stage[cancer.registry.data$stage == 18] = "4B"
cancer.registry.data$stage[cancer.registry.data$stage == 19] = "4C"
cancer.registry.data$stage[cancer.registry.data$stage == 98] = "N/A"
cancer.registry.data$stage[cancer.registry.data$stage == 99] = "Unknown"