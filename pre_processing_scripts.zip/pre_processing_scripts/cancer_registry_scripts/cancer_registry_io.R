# cancer_registry_io.R

# This script is responsible for cancer registry data I/O, as well as
# the initial cancer registry pre-processing.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# cancer registry data I/O
cancer.registry.data = read.csv(cancer.registry.file.name, header = TRUE,
                                stringsAsFactors = FALSE)

cancer.registry.data = cancer.registry.data %>%
  filter(redcap_repeat_instrument == "cancer_registry_diagnosis_data") %>%
  select(-redcap_repeat_instrument, -cancer_registry_diagnosis_data_complete,
         -cs_tumor_size_recorded)

names(cancer.registry.data)[2] = "Cancer.Registry.Entry.Number"

# Convert cancer disease date to date/time format
cancer.registry.data$dx_date = as.POSIXct(cancer.registry.data$dx_date)

cancer.registry.data$tnm_ajcc_edition[cancer.registry.data$tnm_ajcc_edition == 99] = NA

cancer.registry.data$cs_tumor_size = as.numeric(cancer.registry.data$cs_tumor_size)

cancer.registry.data$cs_lymph_nodes = as.numeric(cancer.registry.data$cs_lymph_nodes)

# See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
cancer.registry.data$regional_dose_cgy = gsub("[^0-9\\.]", "", cancer.registry.data$regional_dose_cgy)
cancer.registry.data$regional_dose_cgy[cancer.registry.data$regional_dose_cgy == ""] = NA
cancer.registry.data$regional_dose_cgy = as.numeric(cancer.registry.data$regional_dose_cgy)

# See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
cancer.registry.data$boost_dose_cgy = gsub("[^0-9\\.]", "", cancer.registry.data$boost_dose_cgy)
cancer.registry.data$boost_dose_cgy[cancer.registry.data$boost_dose_cgy == ""] = NA
cancer.registry.data$boost_dose_cgy = as.numeric(cancer.registry.data$boost_dose_cgy)

# See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
cancer.registry.data$num_treatments = gsub("[^0-9\\.]", "", cancer.registry.data$num_treatments)
cancer.registry.data$num_treatments[cancer.registry.data$num_treatments == ""] = NA
cancer.registry.data$num_treatments = as.numeric(cancer.registry.data$num_treatments)

# Convert hormone summary data from numerical encodings to string-based encodings,
# based on VITAL Retrospective codebook
cancer.registry.data$hormone_summary[cancer.registry.data$hormone_summary == 1] = "Yes"
cancer.registry.data$hormone_summary[cancer.registry.data$hormone_summary == 0] = "No"

# Convert reason for no radiation from numerical encodings to string-based encodings,
# based on VITAL Retrospective codebook
cancer.registry.data$reason_no_rx[cancer.registry.data$reason_no_rx == 0] = "Radiation Peformed"
cancer.registry.data$reason_no_rx[cancer.registry.data$reason_no_rx == 1] = "Not Recommended"
cancer.registry.data$reason_no_rx[cancer.registry.data$reason_no_rx == 2] = "Contraindicated"
cancer.registry.data$reason_no_rx[cancer.registry.data$reason_no_rx == 5] = "Patient Died"
cancer.registry.data$reason_no_rx[cancer.registry.data$reason_no_rx == 6] = "Reason Unknown"
cancer.registry.data$reason_no_rx[cancer.registry.data$reason_no_rx == 7] = "Refused"
cancer.registry.data$reason_no_rx[cancer.registry.data$reason_no_rx == 8] = "Recommended, Unknown if given"
cancer.registry.data$reason_no_rx[cancer.registry.data$reason_no_rx == 9] = "Unknown if Radiation recommended or given"