# cancer_registry_site_class_processing.R

# This script performs pre-processing on cancer registry site class data,
# derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Convert cancer site class numerical encodings to string-based encodings,
# based on VITAL Retrospective Codebook
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 1] = "Breast"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 2] = "Pancreatic and Biliary"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 3] = "Head and Neck"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 4] = "Prostate"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 5] = "Connective and Soft Tissue"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 6] = "Lung"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 7] = "Kidney and Urether"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 8] = "Bladder"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 9] = "Blood, Bone Marrow, and Hematopoietic System"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 10] = "Colorectal"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 11] = "Cervical and Uterine"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 12] = "Skin: Melanoma"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 13] = "Brain and Other Nervous System"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 14] = "UGI Tract"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 15] = "Meninges"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 16] = "Lymphoma"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 17] = "Unspecified Digestive Organs"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 18] = "Ovarian"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 19] = "Spleen"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 20] = "Orbit and Lacrimal Gland"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 21] = "Retroperitoneum and Peritoneum"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 22] = "Pituitary Gland"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 23] = "Vulva, NOS"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 24] = "Adrenal Glands"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 25] = "Eyeball"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 26] = "Eye, NOS"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 27] = "Pleura"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 28] = "Testicular"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 29] = "Penis and Scrotum"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 30] = "Vagina and Labia"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 31] = "Bones and Joints"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 32] = "Mediastinum"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 98] = "Ill-defined"
cancer.registry.data$sites_st_class[cancer.registry.data$sites_st_class == 99] = "Unknown"