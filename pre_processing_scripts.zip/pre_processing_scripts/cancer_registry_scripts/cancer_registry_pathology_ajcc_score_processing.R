# cancer_registry_pathology_ajcc_score_processing.R

# This script pre-processes pathological TNM scoring data,
# derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Convert Pathological TNM scoring numerical encodings to string-based encodings,
# based on VITAL Retrospective codebook
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 1] = "PO"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 2] = "P1"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 3] = "P1A"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 4] = "P1B"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 5] = "P1C"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 6] = "P2"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 7] = "P2A"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 8] = "P2B"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 9] = "P2C"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 10] = "P3"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 11] = "P3A"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 12] = "P3B"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 13] = "P3C"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 14] = "P4"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 15] = "P4A"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 16] = "P4B"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 17] = "PA"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 18] = "PIS"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 19] = "PX"
cancer.registry.data$pathological_t[cancer.registry.data$pathological_t == 20] = "N/A"

cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 1] = "C0"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 2] = "P0"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 3] = "P0I-"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 4] = "P1"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 5] = "P1A"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 6] = "P1B"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 7] = "P1C"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 8] = "P2"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 9] = "P2A"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 10] = "P2B"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 11] = "P2C"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 12] = "P3"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 13] = "P3A"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 14] = "P3B"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 15] = "PX"
cancer.registry.data$pathological_n[cancer.registry.data$pathological_n == 16] = "N/A"

cancer.registry.data$pathological_m[cancer.registry.data$pathological_m == 1] = "C0"
cancer.registry.data$pathological_m[cancer.registry.data$pathological_m == 2] = "C1"
cancer.registry.data$pathological_m[cancer.registry.data$pathological_m == 3] = "C1A"
cancer.registry.data$pathological_m[cancer.registry.data$pathological_m == 4] = "P1"
cancer.registry.data$pathological_m[cancer.registry.data$pathological_m == 5] = "P1A"
cancer.registry.data$pathological_m[cancer.registry.data$pathological_m == 6] = "P1B"
cancer.registry.data$pathological_m[cancer.registry.data$pathological_m == 7] = "PX"
cancer.registry.data$pathological_m[cancer.registry.data$pathological_m == 8] = "N/A"