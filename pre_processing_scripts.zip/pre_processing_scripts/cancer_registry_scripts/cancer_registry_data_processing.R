# cancer_registry_data_processing.R

# This overarching script is responsible for pre-processing
# the cancer registry data derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

source(paste(cancer.registry.directory, 'cancer_registry_io.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_disease_type_processing.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_diagnosis_date_grade_metastasis_processing.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_site_class_processing.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_histology_class_processing.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_ajcc_stage_processing.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_derived_ajcc_stage_group_processing.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_derived_ajcc_score_processing.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_clinical_ajcc_score_processing.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_clinical_stage_processing.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_pathology_ajcc_score_processing.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_pathology_stage_processing.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_treatment_modality_processing.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_treatment_volume_summary_processing.R', sep = '/'))

source(paste(cancer.registry.directory, 'cancer_registry_chemotherapy_processing.R', sep = '/'))

# Free up Memory
remove(cancer.registry.file.name)
remove(vital.retrospective.data.directory)