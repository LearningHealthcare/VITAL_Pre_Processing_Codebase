# format_collaterals_imaging_data.R

# This script performs pre-processing on collaterals imaging data derived from
# the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing collaterals imaging data
collaterals.imaging.data = select(imaging.data, record_id, Study.Number, collaterals___1, collaterals___2,
  collaterals___3, collaterals___4, collaterals___5, collaterals___6, collaterals___7, collaterals___8,
  collaterals___9, collaterals___10, collaterals___11, collaterals___12, collaterals___13, collaterals___14,
  collaterals___15, collaterals___16, collaterals___17, collaterals___18)

names(collaterals.imaging.data) = c("record_id", "Study.Number", "Enlarged.RILV", "Enlarged.RCIRCV", 
 "Enlarged.RIEPIV", "Enlarged.ROVARV", "Enlarged.RPFEMV", "Enlarged.RGSV", "Enlarged.ROBTUR", "Enlarged.LILV", 
"Enlarged.LCIRCV", "Enlarged.LIEPIV", "Enlarged.LOVARV", "Enlarged.LPFEMV", "Enlarged.LGSV",
  "Enlarged.LOBTUR", "Cross.Pelvic.Coll", "Suprapubic.Coll", "RPOPTPFV.Coll", "LPOPTPFV.Coll")

collaterals.imaging.data = collaterals.imaging.data %>%
  gather(Collateral, Collateral.Value, -record_id, -Study.Number) %>%
  # Convert collaterals numerical encoding to string-based encoding, based on 
  # VITAL Retrospective codebook
  mutate(Collateral.Status = ifelse(Collateral.Value == 1, "Present", 
         ifelse(Collateral.Value == 0, "0", NA))) %>%
  select(-Collateral.Value) %>%
  spread(Collateral, Collateral.Status)

# Remove rows with no collaterals imaging data
collaterals.data.values = select(collaterals.imaging.data, -record_id, -Study.Number)
no.collaterals.rows = which(rowSums(collaterals.data.values == "0") == 
                              ncol(collaterals.data.values))
collaterals.imaging.data = collaterals.imaging.data[-no.collaterals.rows, ]

# Free Up Memory
remove(collaterals.data.values)
remove(no.collaterals.rows)