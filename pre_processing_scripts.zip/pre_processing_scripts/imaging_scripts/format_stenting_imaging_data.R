# format_stenting_imaging_data.R

# This script performs pre-processing on stenting imaging data
# derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

stent.restenosis.imaging.data = select(imaging.data, record_id, Study.Number, suprarenalivc_stent, 
  infrarenalivc_stent, rciv_stent, reiv_stent, rcfv_stent, rpfv_stent, rfemv_stent, rpop_stent,
  lciv_stent, leiv_stent, lcfv_stent, lpfv_stent, lfemv_stent, lpopv_stent)

names(stent.restenosis.imaging.data) = c("record_id", "Study.Number", "Suprarenal.IVC", "Infrarenal.IVC",
        "RCIV", "REIV", "RCFV", "RPFV", "RFEMV", "RPOP", "LCIV", "LEIV", "LCFV", "LPFV",
        "LFEMV", "LPOP")

stent.restenosis.imaging.data = stent.restenosis.imaging.data %>%
  gather(Vein, Restenosis.Value, -record_id, -Study.Number) %>%
  # Convert REDCap Restenosis Numerical Encodings to corresponding String Encodings, based on
  # VITAL Retrospective codebook
  mutate(Restenosis = ifelse(Restenosis.Value == 1, "Present", 
        ifelse(Restenosis.Value == 2, "Absent", 
        ifelse(Restenosis.Value == 3, "In-stent Restenosis", NA)))) %>%
  select(-Restenosis.Value) %>%
  spread(Vein, Restenosis)

# Determine which imaging studies have no stents
stent.restenosis.values = select(stent.restenosis.imaging.data, -record_id, -Study.Number)
restenosis.empty.rows = which(rowSums(is.na(stent.restenosis.values)) == ncol(stent.restenosis.values))
stent.restenosis.imaging.data = stent.restenosis.imaging.data[-restenosis.empty.rows, ]

stent.restenosis.studies = select(stent.restenosis.imaging.data, record_id, Study.Number)

# Dataframe containing Stent Restenosis Percentage Data
stent.restenosis.percentage.imaging.data = select(imaging.data, record_id, Study.Number, suprarenalivc_percent, 
  infrarenalivc_percent, rciv_percent, reiv_percent, rcfv_percent, rpfv_percent, rfemv_percent, 
  rpop_percent, lciv_percent, leiv_percent, lcfv_percent, lpfv_percent, lfemv_percent, lpopv_percent)

names(stent.restenosis.percentage.imaging.data) = c("record_id", "Study.Number", "Suprarenal.IVC", 
  "Infrarenal.IVC", "RCIV", "REIV", "RCFV", "RPFV", "RFEMV", "RPOP", "LCIV", "LEIV", "LCFV", 
  "LPFV", "LFEMV", "LPOP")

stent.restenosis.percentage.imaging.data = inner_join(stent.restenosis.studies, stent.restenosis.percentage.imaging.data,
                                              by = c("record_id", "Study.Number"))

# Remove rows with no stent restenosis percentage data
stent.restenosis.percentage.values = select(stent.restenosis.percentage.imaging.data, -record_id, -Study.Number)
restenosis.percentage.empty.rows = which(rowSums(is.na(stent.restenosis.percentage.values)) == ncol(stent.restenosis.percentage.values))
stent.restenosis.percentage.imaging.data = stent.restenosis.percentage.imaging.data[-restenosis.percentage.empty.rows, ]

if(nrow(stent.restenosis.percentage.imaging.data) > 0){
  stent.restenosis.percentage.imaging.data = stent.restenosis.percentage.imaging.data %>%
    gather(Vein, Percentage.Value, -record_id, -Study.Number) %>%
    # Convert REDCap DVT Numerical Encodings to corresponding String Encodings, based on
    # VITAL Retrospective codebook
    mutate(Percentage = ifelse(Percentage.Value == 1, "1-25%", 
          ifelse(Percentage.Value == 2, "26-50%", 
          ifelse(Percentage.Value == 3, "51-75%",
          ifelse(Percentage.Value == 4, "76-99%", 
          ifelse(Percentage.Value == 5, "Completely Occluded", NA)))))) %>%
    select(-Percentage.Value) %>%
    spread(Vein, Percentage)
}

# Free up memory
remove(stent.restenosis.values)
remove(stent.restenosis.percentage.values)
remove(restenosis.empty.rows)
remove(restenosis.percentage.empty.rows)
remove(stent.restenosis.studies)