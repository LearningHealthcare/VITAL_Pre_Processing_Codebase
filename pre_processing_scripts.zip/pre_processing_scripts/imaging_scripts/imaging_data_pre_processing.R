# imaging_data_pre_processing.R

# This overarching script performs the data pre-processing
# on the imaging data derived from the VITAL Retrospective Database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

source(paste(imaging.data.code.directory, 'imaging_data_io.R', sep = '/'))

source(paste(imaging.data.code.directory, 'format_dvt_imaging_data.R', sep = '/'))

source(paste(imaging.data.code.directory, 'format_stenting_imaging_data.R', sep = '/'))

source(paste(imaging.data.code.directory, 'format_vein_diameter_imaging_data.R', sep = '/'))

source(paste(imaging.data.code.directory, 'format_collaterals_imaging_data.R', sep = '/'))

source(paste(imaging.data.code.directory, 'format_reflux_imaging_data.R', sep = '/'))

source(paste(imaging.data.code.directory, 'format_edema_thickness_enlargement_imaging_data.R', sep = '/'))

# Dataframe containing IVC Filter Imaging Data
ivc.filter.imaging.data = imaging.data %>%
  select(record_id, Study.Number, ivc_filter) %>%
  mutate(IVC.Filter.Status = ifelse(ivc_filter == 1, "Yes",
         ifelse(ivc_filter == 0, "No", NA)))

# Dataframe containing over infrarenal and suprarenal IVC stenting imaging data
over.renal.imaging.data = imaging.data %>%
  filter(suprarenalivc_stent == 1 | infrarenalivc_stent == 1 | suprarenalivc_stent == 3 | 
        infrarenalivc_stent == 3) %>%
  select(record_id, Study.Number, over_renal) 

# Free up memory
remove(imaging.data)
remove(imaging.file.name)