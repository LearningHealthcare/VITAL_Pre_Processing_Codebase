# format_dvt_imaging_data.R

# This script performs pre-processing on the DVT on imaging data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing DVT on imaging data
dvt.imaging.data = select(imaging.data, record_id, Study.Number, suprarenal_ivc, infrarenal_ivc,
                  right_common_iliac_vein, right_external_iliac_vein, right_common_femoral_vein,
                  right_profunda_femoris_vei, right_femoral_vein, right_popliteal_vein, left_common_iliac_vein,
                  left_external_iliac_vein, left_common_femoral_vein, left_profunda_femoris_vein, left_femoral_vein, 
                  left_popliteal_vein)

names(dvt.imaging.data) = c("record_id", "Study.Number", "Suprarenal.IVC", "Infrarenal.IVC",
                    "RCIV", "REIV", "RCFV", "RPFV", "RFEMV", "RPOP", "LCIV", "LEIV", "LCFV", "LPFV",
                    "LFEMV", "LPOP")

dvt.imaging.data = dvt.imaging.data %>%
  gather(Vein, DVT.Value, -record_id, -Study.Number) %>%
  # Convert REDCap DVT Numerical Encodings to corresponding String Encodings, based on
  # VITAL Retrospective codebook
  mutate(DVT = ifelse(DVT.Value == 1, "Acute", 
    ifelse(DVT.Value == 2, "Chronic", 
    ifelse(DVT.Value == 3, "Acute on Chronic",
    ifelse(DVT.Value == 4, "Patent", NA))))) %>%
  select(-DVT.Value) %>%
  spread(Vein, DVT)

# Determine which imaging studies have no DVT values
dvt.values = select(dvt.imaging.data, -record_id, -Study.Number)
dvt.empty.rows = which(rowSums(is.na(dvt.values)) == ncol(dvt.values))
dvt.imaging.data = dvt.imaging.data[-dvt.empty.rows, ]

# Free up memory
remove(dvt.values)
remove(dvt.empty.rows)