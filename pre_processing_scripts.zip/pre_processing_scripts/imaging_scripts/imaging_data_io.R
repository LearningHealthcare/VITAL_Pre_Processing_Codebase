# imaging_data_io.R

# This script handles I/O for the imaging data from VITAL Retrospective,
# as well as the initial pre-processing of the imaging data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# imaging data I/O
imaging.data = read.csv(imaging.file.name, 
              stringsAsFactors = FALSE, header = TRUE)

# Remove imaging studies without imaging date or accession number
imaging.data = imaging.data %>%
  filter(redcap_repeat_instrument == "imaging") %>%
  filter(date != "") %>%
  filter(accession != "") %>%
  select(-redcap_repeat_instrument)

# Remove Imaging Studies performed outside of Stanford
outside.accession.numbers = grep("Outside", imaging.data$accession)
imaging.data = imaging.data[-outside.accession.numbers, ]

imaging.data$date = as.POSIXct(imaging.data$date)

names(imaging.data)[2] = "Study.Number"

imaging.data = imaging.data %>%
  # Convert Imaging Study Modality Numeric Encodings to corresponding strings,
  # based on VITAL Retrospective Codebook
  mutate(Imaging.Study.Modality = ifelse(imaging_study_modality == 1, "Ultrasound",
        ifelse(imaging_study_modality == 2, "MR Venography", 
        ifelse(imaging_study_modality == 3, "CT Venography", "Conventional Venography")))) %>%
  # Convert Imaging Study Laterality Numeric Encodings to corresponding strings,
  # based on VITAL Retrospective Codebook
  mutate(Imaging.Study.Laterality = ifelse(imaging_study_laterality == 1, "Left",
        ifelse(imaging_study_modality == 2, "Right", 
        ifelse(imaging_study_modality == 3, "Bilateral", NA)))) %>%
  select(-imaging_study_modality, -imaging_study_laterality)

imaging.accession.date.mapping = select(imaging.data, record_id, Study.Number, accession, date, 
        Imaging.Study.Modality, Imaging.Study.Laterality)

# Dataframe containing imaging report data
imaging.report.data = imaging.data %>%
  select(record_id, Study.Number, imaging_report) %>%
  filter(imaging_report != "")

# Free up memory
remove(outside.accession.numbers)