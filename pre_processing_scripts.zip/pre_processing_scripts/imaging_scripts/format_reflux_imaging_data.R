# format_reflux_imaging_data.R

# This script performs pre-processing on reflux imaging data derived from
# the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing reflux imaging data
reflux.imaging.data = select(imaging.data, record_id, Study.Number, reflux_present___1,
  reflux_present___2, reflux_present___3, reflux_present___4, reflux_present___5,
  reflux_present___6, reflux_present___7, reflux_present___8, reflux_present___9,
  reflux_present___10)

names(reflux.imaging.data) = c("record_id", "Study.Number", "RGSV", "RSSV", "RCFV",
  "RSFV", "RPOPV", "LGSV", "LSSV", "LCFV", "LSFV", "LPOPV")

reflux.imaging.data = reflux.imaging.data %>%
  gather(Reflux, Reflux.Value, -record_id, -Study.Number) %>%
  # Convert Reflux Numerical Encodings to String based Encodings,
  # based on VITAL Retrospective Codebook
  mutate(Reflux.Status = ifelse(Reflux.Value == 1, "Present", 
        ifelse(Reflux.Value == 0, "0", NA))) %>%
  select(-Reflux.Value) %>%
  spread(Reflux, Reflux.Status)

# Remove rows that have no reflux values
reflux.data.values = select(reflux.imaging.data, -record_id, -Study.Number)
no.reflux.rows = which(rowSums(reflux.data.values == "0") == ncol(reflux.data.values))
reflux.imaging.data = reflux.imaging.data[-no.reflux.rows, ]

# Free up memory
remove(reflux.data.values)
remove(no.reflux.rows)