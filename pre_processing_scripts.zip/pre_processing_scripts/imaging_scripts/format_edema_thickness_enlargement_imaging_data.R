# format_edema_thickness_enlargement_imaging_data.R

# This script performs pre-processing on edema, skin thickness, and enlargement imaging
# data derived from the VITAL Retrospective Database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing Edema, Skin Thickness and enlargement imaging Data
edema.thickness.enlargement.imaging.data = select(imaging.data, record_id, Study.Number,
  r_thigh_edema, r_calf_edema, r_ankle_edema, l_thigh_edema, l_calf_edema, l_ankle_edema,
  r_thigh_thick, r_calf_thick, r_ankle_thick, l_thigh_thick, l_calf_thick, l_ankle_thick,
  r_thigh_enlarge, r_calf_enlarge, r_ankle_enlarge, l_thigh_enlarge, l_calf_enlarge, l_ankle_enlarge,
  r_calf_varicose, l_calf_varicose, r_thigh_varicose, l_thigh_varicose)

edema.thickness.enlargement.imaging.data = edema.thickness.enlargement.imaging.data %>%
  gather(Status, Value, -record_id, -Study.Number) %>%
  # Convert Numerical Encodings to String-based Encodings,
  # based on VITAL Retrospective codebook
  mutate(Status.Value = ifelse(Value == 0, "0",
         ifelse(Value == 1, "Mild",
         ifelse(Value == 2, "Moderate",
         ifelse(Value == 3, "Severe", NA))))) %>%
  select(-Value) %>%
  spread(Status, Status.Value)

# Remove rows with no edema, skin thickness or enlargement data present
edema.thickness.enlargement.data.values = select(edema.thickness.enlargement.imaging.data, 
  -record_id, -Study.Number)
edema.thickness.enlargement.missing.values = which(rowSums(is.na(edema.thickness.enlargement.data.values)) == 
  ncol(edema.thickness.enlargement.data.values))
edema.thickness.enlargement.imaging.data = edema.thickness.enlargement.imaging.data[-edema.thickness.enlargement.missing.values, ]

# Free up memory
remove(edema.thickness.enlargement.missing.values)
remove(edema.thickness.enlargement.data.values)