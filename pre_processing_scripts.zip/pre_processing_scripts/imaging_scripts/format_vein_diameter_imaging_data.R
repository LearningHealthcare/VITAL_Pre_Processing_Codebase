# format_vein_diameter_imaging_data.R

# This script performs pre-processing on the vein diameter imaging data
# derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing Vein Diameter Imaging Data
vein.diameter.imaging.data = select(imaging.data, record_id, Study.Number, suprarenal_long_max, 
  suprarenal_short_max, suprarenal_long_min, suprarenal_short_min, infrarenal_long_max,
  infrarenal_short_max, infrarenal_long_min, infrarenal_short_min, right_civ_max, 
  right_civ_min, right_eiv_max, right_eiv_min, right_cfv_max, right_cfv_min, right_pfv_max,
  right_fv_max, right_fv_min, right_pv_max, right_pv_min, right_psv_max, right_psv_min,
  right_gv_max, right_gv_min, right_ilv_max, left_civ_max, left_civ_min, left_eiv_max,
  left_eiv_min, left_cfv_max, left_cfv_min, left_pfv_max, left_fv_max, left_fv_min,
  left_pv_max, left_pv_min, left_psv_max, left_psv_min, left_gv_max, left_gv_min, left_ilv_max)

names(vein.diameter.imaging.data) = c("record_id", "Study.Number", "Suprarenal.IVC.Long_Max", 
      "Suprarenal.IVC.Short_Max", "Suprarenal.IVC.Long_Min", "Suprarenal.IVC.Short_Min",
      "Infrarenal.IVC.Long_Max", "Infrarenal.IVC.Short_Max", "Infrarenal.IVC.Long_Min",
      "Infrarenal.IVC.Short_Min", "RCIV_Max", "RCIV_Min", "REIV_Max", "REIV_Min",
      "RCFV_Max", "RCFV_Min", "RPFV_Max", "RFEMV_Max", "RFEMV_Min", "RPOP_Max", "RPOP_Min",
      "RPSV_Max", "RPSV_Min", "RGV_Max", "RGV_Min", "RILV_Max", "LCIV_Max", "LCIV_Min",
      "LEIV_Max", "LEIV_Min", "LCFV_Max", "LCFV_Min", "LPFV_Max", "LFEMV_Max",
      "LFEMV_Min", "LPOP_Max", "LPOP_Min", "LPSV_Max", "LPSV_Min", "LGV_Max", "LGV_Min",
      "LILV_Max")

vein.diameter.imaging.data = vein.diameter.imaging.data %>%
  gather(Vein, Diameter.Value, -record_id, -Study.Number) %>%
  # Convert Vein Diameter Encoding to Vein Diameter Numeric Value, based on
  # VITAL Retrospective codebook
  mutate(Diameter = Diameter.Value - 1) %>%
  select(-Diameter.Value) %>%
  spread(Vein, Diameter)

# Determine which imaging studies have no vein diameters
vein.diameter.values = select(vein.diameter.imaging.data, -record_id, -Study.Number)
vein.diameter.empty.rows = which(rowSums(is.na(vein.diameter.values)) == 
                                ncol(vein.diameter.values))
vein.diameter.imaging.data = vein.diameter.imaging.data[-vein.diameter.empty.rows, ]

# Free Up Memory
remove(vein.diameter.values)
remove(vein.diameter.empty.rows)