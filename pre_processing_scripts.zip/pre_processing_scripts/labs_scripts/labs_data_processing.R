# labs_data_processing.R

# This script is responsible for pre-processing labs data derived from
# the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# labs data I/O
labs.data = read.csv(labs.file.name, stringsAsFactors = FALSE,
                     header = TRUE)

labs.data = labs.data %>%
  filter(redcap_repeat_instrument == "labs") %>%
  select(record_id, redcap_repeat_instance, lab_taken_date, lab_name, lab_value, reference_low,
         reference_high, reference_unit)

names(labs.data)[2] = "Lab.Test.Number"

# Convert Lab Name from Numerical Encoding to String-based Encoding,
# based on VITAL Retrospective database
labs.data$lab_name[labs.data$lab_name == 1] = "INR"
labs.data$lab_name[labs.data$lab_name == 2] = "Anti-Xa"
labs.data$lab_name[labs.data$lab_name == 3] = "Arixtra"
labs.data$lab_name[labs.data$lab_name == 4] = "Rivaroxaban"
labs.data$lab_name[labs.data$lab_name == 5] = "Apixaban"

labs.data$lab_value[labs.data$lab_value == ""] = NA
labs.data$reference_high[labs.data$reference_high == ""] = NA

# Free up memory
remove(labs.file.name)