# demographics_follow_up_pre_processing.R

# This script converts patient follow-up information, from numeric encodings to their
# corresponding strings, based on the VITAL Retrospective Codebook. In addition,
# this script also creates dataframes, storing patient follow-up and death data, derived
# from the Demographics data table.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Convert Last Follow Up Type encodings to strings, based on VITAL Retrospective Codebook
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 1] = "Hospital.Encounter"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 2] = "Office.Visit"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 3] = "Appointment"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 4] = "Death"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 5] = "Lab.Draw"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 6] = "LPCH"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 7] = "Telemedicine.Visit.Phone"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 8] = "Telehealth.Visit"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 9] = "Cancer.Registry"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 10] = "PANES.Visit"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 11] = "Non.EPIC.Clinic.Visit"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 12] = "Anti.Coagulation.Telephone.Followup"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 13] = "Hx.Hospital"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 14] = "Physical.Therapy"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 15] = "Hx.Clinic"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 16] = "Procedure.Visit"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 17] = "Clinical.Support"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 18] = "Audiology.Visit"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 19] = "Tumor.Board"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 20] = "Cardiopulmonary"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 21] = "Device.Check.Visit"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 22] = "Immunotherapy"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 23] = "Anticoagulation.SHC"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 24] = "Occupational.Therapy"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 25] = "Sleep.Study"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 26] = "Surgery"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 27] = "Pre.Visit.Planning"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 28] = "Off.Site.Visit"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 29] = "Historical.Ambulatory.Encounter"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 30] = "Nutrition"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 31] = "AMB.Care.Pharmicist.Visit"
demographics.data$Last.Follow.Up.Type[demographics.data$lfu_type == 32] = "Anesthesia"
demographics.data$Last.Follow.Up.Type[demographics.data$Last.Follow.Up.Type == ""] = NA

# Create Demographics death dataframe
demographics.death.data = demographics.data %>%
  select(record_id, death_date, Death.Date.Info.Source) %>%
  filter(death_date != "")

# Convert death date to date/time format
demographics.death.data$death_date = as.POSIXct(demographics.death.data$death_date)

# Create Demographics last follow up dataframe
demographics.follow.up.data = demographics.data %>%
  select(record_id, lfu_date, Last.Follow.Up.Type) %>%
  filter(lfu_date != "")

# Convert Last Follow Up Date to date/time format
demographics.follow.up.data$lfu_date = as.POSIXct(demographics.follow.up.data$lfu_date)

demographics.data = select(demographics.data, -lfu_type, -death_info_source, -death_date, 
                          -lfu_date, -Death.Date.Info.Source, -Last.Follow.Up.Type)