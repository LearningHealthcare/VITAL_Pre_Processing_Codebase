# demographics_io.R

# This script reads in demographics data from a .csv file, and
# serves as the overarching script for demographics data pre-processing.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Demographics data I/O
demographics.data = read.csv(demographics.file.name, 
                    header = TRUE, stringsAsFactors = FALSE)

demographics.data = demographics.data %>%
  select(-redcap_repeat_instrument, -redcap_repeat_instance, 
        -mrn, -demographics_complete, -lfu_utd) %>%
  # Convert gender numeric encodings to strings, based on VITAL Retrospective Codebook
  mutate(Gender = ifelse(sex == 0, "Male", ifelse(sex == 1, "Female", NA))) %>%
  # Convert Death Date numeric encodings to strings, based on VITAL Retrospective Codebook
  mutate(Death.Date.Info.Source = ifelse(death_info_source == 1, "Cancer Registry",
                                  ifelse(death_info_source == 2, "EPIC",
                                  ifelse(death_info_source == 3, "SSDI",
                                  ifelse(death_info_source == 4, "STRIDE",
                                  ifelse(death_info_source == 5, "SSA",
                                  ifelse(death_info_source == 6, "LPP",
                                  ifelse(death_info_source == 7, "ONCORE",
                                  ifelse(death_info_source == 8, "BMT",
                                  ifelse(death_info_source == 9, "Kidney",
                                  ifelse(death_info_source == 99, "Other", NA))))))))))) %>%
  mutate(Last.Follow.Up.Type = "") %>%
  select(-sex)

source(paste(demographics.code.directory, 'demographics_follow_up_pre_processing.R', sep = '/'))

# Convert race/ethnicity encodings to strings, based on VITAL Retrospective Codebook
ethnicity.vector = rep("", times = nrow(demographics.data))
ethnicity.vector[demographics.data$race == 1] = "White"
ethnicity.vector[demographics.data$race == 2] = "African-American"
ethnicity.vector[demographics.data$race == 3] = "Asian"
ethnicity.vector[demographics.data$race == 4] = "Pacific Islander"
ethnicity.vector[demographics.data$race == 5] = "Native-American"
ethnicity.vector[demographics.data$race == 6] = "Other"
ethnicity.vector[demographics.data$race == 7] = "Unknown"
ethnicity.vector[demographics.data$ethnicity == 1] = "Hispanic/Latino"

demographics.data = cbind.data.frame(demographics.data, ethnicity.vector)

names(demographics.data) = c("record_id", "Last.Name", "First.Name", "DOB", "Race", "ethnicity",
                                   "Gender", "Ethnicity")

demographics.data = select(demographics.data, -Race, -ethnicity)

demographics.data$Gender = as.factor(demographics.data$Gender)

demographics.data$Ethnicity = as.factor(demographics.data$Ethnicity)

# Convert date of birth to date/time format
demographics.data$DOB = as.POSIXct(demographics.data$DOB)

# Free up memory, by removing variables/dataframes that will not be used 
# in subsequent pre-processing or analysis
remove(ethnicity.vector)
remove(demographics.file.name)