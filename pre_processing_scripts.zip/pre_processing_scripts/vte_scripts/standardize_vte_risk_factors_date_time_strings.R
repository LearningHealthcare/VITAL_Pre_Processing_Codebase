# standardize_vte_risk_factors_date_time_strings.R

# This script standardizes the format of a VTE date-time entry, based on one of five possible input formats.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Example of Date in specified format: 2000-01-31
vte.risk.factor.date.first.format = as.Date(vte.risk.factor.dates.data$Date.Value, format = '%Y-%m-%d')
# Example of Date in specified format: 01-31-2000
vte.risk.factor.date.second.format = as.Date(vte.risk.factor.dates.data$Date.Value, format = '%m-%d-%Y')
# Example of Date in specified format: 01-31-00
vte.risk.factor.date.third.format = as.Date(vte.risk.factor.dates.data$Date.Value, format = '%m-%d-%y')
# Example of Date in specified format: 01/31/2000
vte.risk.factor.date.fourth.format = as.Date(vte.risk.factor.dates.data$Date.Value, format = '%m/%d/%Y')
# Example of Date in specified format: 01/31/00
vte.risk.factor.date.fifth.format = as.Date(vte.risk.factor.dates.data$Date.Value, format = '%m/%d/%y')

vte.risk.factor.date = rep("", times = nrow(vte.risk.factor.dates.data))

for(i in 1:length(vte.risk.factor.date)){
  num.dashes = unlist(strsplit(vte.risk.factor.dates.data$Date.Value[i], split = '-'))
  # Checks if month, day and year are separated by dashes
  if(length(num.dashes) == 3){
    # Identification of one of date-time formats above using dashes (Examples #1-#3)
    potential.date = vte.risk.factor.date.second.format[i]
    if(is.na(potential.date) | year(potential.date) < initial.medical.history.year | year(potential.date) > year(Sys.Date())){
      potential.date = vte.risk.factor.date.first.format[i]
      if(is.na(potential.date) | year(potential.date) < initial.medical.history.year | year(potential.date) > year(Sys.Date())){
        potential.date = vte.risk.factor.date.third.format[i]
        if(!is.na(potential.date) & year(potential.date) >= initial.medical.history.year & year(potential.date) <= year(Sys.Date())){
          vte.risk.factor.date[i] = as.character(potential.date)
        }
      }else{
        vte.risk.factor.date[i] = as.character(potential.date)
      }
    }else{
      vte.risk.factor.date[i] = as.character(potential.date)
    }
  # Checks if month, day and year are separated by backslashes
  }else if(length(num.dashes) == 1){
    # Identification of one of date-time formats above using backslashes (Examples #4-#5)
    potential.date = vte.risk.factor.date.fourth.format[i]
    if(is.na(potential.date) | year(potential.date) < initial.medical.history.year | year(potential.date) > year(Sys.Date())){
      potential.date = vte.risk.factor.date.fifth.format[i]
      if(!is.na(potential.date) & year(potential.date) >= initial.medical.history.year & year(potential.date) <= year(Sys.Date())){
        vte.risk.factor.date[i] = as.character(potential.date)
      }
    }else{
      vte.risk.factor.date[i] = as.character(potential.date)
    }
  }
}

vte.risk.factor.dates.data$Date.Value = vte.risk.factor.date

# Remove date-times without proper format/missing datetimes
vte.risk.factor.dates.data = filter(vte.risk.factor.dates.data, Date.Value != "")

vte.risk.factor.dates.data = spread(vte.risk.factor.dates.data, Date.Type, Date.Value)