# vte_risk_factors_data_processing.R

# This script is responsible for performing data pre-processing
# on various components of the VTE Risk factors data derived from
# the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# VTE Risk Factors Dates data dataframe
vte.risk.factor.dates.data = vte.data %>% 
  select(record_id, VTE.Event.Number, vtedate, fracture_date, hipkneereplace_date, gensurg_date, 
  trauma_date, sci_date, arthknee_date, cvc_date, chemo_date, chf_date, respfailure_date, 
  hrt_date, malig_date, ocp_date, stroke_date, surg_14_date, trauma_14_date, preg_post_date, 
  bedrest_date, immobility_date, lapsurg_date, varicose_date, cellulitis_date) %>%
  gather(Date.Type, Date, -record_id, -VTE.Event.Number) %>%
  filter(!is.na(Date) & Date != "")

for(i in 1:nrow(vte.risk.factor.dates.data)){
  vte.date = vte.risk.factor.dates.data$Date[i]
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  if(gsub("[^0-9]", "", vte.date) == ""){
    vte.risk.factor.dates.data$Date[i] = ""
  }else{
    # Separate multiple vte date(s) on semicolon
    vte.date = unlist(strsplit(vte.date, ";"))
    vte.risk.factor.dates.data$Date[i] = vte.date[1]
  }
}

# Remove missing VTE Risk Factor date data
vte.risk.factor.dates.data = filter(vte.risk.factor.dates.data, Date != "")

vte.risk.factor.dates.data$Date = trimws(vte.risk.factor.dates.data$Date)

source(paste(vte.code.directory, 'determine_vte_risk_factors_datetime_format.R', sep = '/'))

source(paste(vte.code.directory, 'create_complete_vte_risk_factors_date_time_string.R', sep = '/'))

source(paste(vte.code.directory, 'standardize_vte_risk_factors_date_time_strings.R', sep = '/'))

source(paste(vte.code.directory, 'combine_vte_risk_factor_date_data.R', sep = '/'))

source(paste(vte.code.directory, 'supplementary_vte_data_processing.R', sep = '/'))