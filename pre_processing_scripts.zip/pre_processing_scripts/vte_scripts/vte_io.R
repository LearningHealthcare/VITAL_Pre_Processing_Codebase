# vte_io.R

# This overarching script is responsible for pre-processing
# VTE Risk Factor data derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# VTE risk factor data i/o
vte.data = read.csv(vte.file.name, 
          stringsAsFactors = FALSE, header = TRUE)

# Remove rows without VTE risk factor data
vte.data = vte.data %>%
  filter(redcap_repeat_instrument == "vte_risk_factors") %>%
  select(-redcap_repeat_instrument)

names(vte.data)[2] = "VTE.Event.Number"

source(paste(vte.code.directory, 'dvt_pe_lymphedema_vte_data_processing.R', sep = '/'))

source(paste(vte.code.directory, 'vte_risk_factors_cohort_selection.R', sep = '/'))

source(paste(vte.code.directory, 'vte_risk_factors_data_processing.R', sep = '/'))

source(paste(vte.code.directory, 'free_up_memory_vte_data.R', sep = '/'))
