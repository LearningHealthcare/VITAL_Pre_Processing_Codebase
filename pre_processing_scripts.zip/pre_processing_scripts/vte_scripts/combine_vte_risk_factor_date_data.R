# combine_vte_risk_factor_date_data.R

# This script combines the pre-processed VTE risk factors dates, with
# their corresponding patients, VTE Event Number, and other
# non-date-time VTE data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

if("fracture_date" %in% names(vte.risk.factor.dates.data)){
  hip.leg.fracture.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, fracture_date) %>%
    right_join(hip.leg.fracture.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("hipkneereplace_date" %in% names(vte.risk.factor.dates.data)){
  hip.knee.replacement.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, hipkneereplace_date) %>%
    right_join(hip.knee.replacement.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("gensurg_date" %in% names(vte.risk.factor.dates.data)){
  major.general.surgery.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, gensurg_date) %>%
    right_join(major.general.surgery.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("trauma_date" %in% names(vte.risk.factor.dates.data)){
  major.trauma.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, trauma_date) %>%
    right_join(major.trauma.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("sci_date" %in% names(vte.risk.factor.dates.data)){
  spinal.cord.injury.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, sci_date) %>%
    right_join(spinal.cord.injury.vte.data, by = c("record_id", "VTE.Event.Number")) 
}

if("arthknee_date" %in% names(vte.risk.factor.dates.data)){
  arthroscopic.knee.surgery.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, arthknee_date) %>%
    right_join(arthroscopic.knee.surgery.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("cvc_date" %in% names(vte.risk.factor.dates.data)){
  central.venous.lines.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, cvc_date) %>%
    right_join(central.venous.lines.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("chemo_date" %in% names(vte.risk.factor.dates.data)){
  chemotherapy.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, chemo_date) %>%
    right_join(chemotherapy.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("chf_date" %in% names(vte.risk.factor.dates.data)){
  CHF.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, chf_date) %>%
    right_join(CHF.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("respfailure_date" %in% names(vte.risk.factor.dates.data)){
  respiratory.failure.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, respfailure_date) %>%
    right_join(respiratory.failure.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("hrt_date" %in% names(vte.risk.factor.dates.data)){
  hormone.replacement.therapy.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, hrt_date) %>%
    right_join(hormone.replacement.therapy.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("malig_date" %in% names(vte.risk.factor.dates.data)){
  malignancy.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, malig_date) %>%
    right_join(malignancy.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("ocp_date" %in% names(vte.risk.factor.dates.data)){
  oral.contraceptive.therapy.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, ocp_date) %>%
    right_join(oral.contraceptive.therapy.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("stroke_date" %in% names(vte.risk.factor.dates.data)){
  stroke.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, stroke_date) %>%
    right_join(stroke.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("preg_post_date" %in% names(vte.risk.factor.dates.data)){
  postpartum.pregnancy.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, preg_post_date) %>%
    right_join(postpartum.pregnancy.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("bedrest_date" %in% names(vte.risk.factor.dates.data)){
  bed.rest.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, bedrest_date) %>%
    right_join(bed.rest.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("immobility_date" %in% names(vte.risk.factor.dates.data)){
  immobility.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, immobility_date) %>%
    right_join(immobility.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("lapsurg_date" %in% names(vte.risk.factor.dates.data)){
  laparo.surgery.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, lapsurg_date) %>%
    right_join(laparo.surgery.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("varicose_date" %in% names(vte.risk.factor.dates.data)){
  varicose.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, varicose_date) %>%
    right_join(varicose.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("surg_14_date" %in% names(vte.risk.factor.dates.data)){
  surgery.fourteen.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, surg_14_date) %>%
    right_join(surgery.fourteen.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("trauma_14_date" %in% names(vte.risk.factor.dates.data)){
  trauma.fourteen.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, trauma_14_date) %>%
    right_join(trauma.fourteen.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("cellulitis_date" %in% names(vte.risk.factor.dates.data)){
  cellulitis.vte.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, cellulitis_date) %>%
    right_join(cellulitis.vte.data, by = c("record_id", "VTE.Event.Number"))
}

if("vtedate" %in% names(vte.risk.factor.dates.data)){
  
  dvt.risk.factor.data = select(dvt.risk.factor.data, -vtedate)
  lymphedema.risk.factor.data = select(lymphedema.risk.factor.data, -vtedate)
  pe.risk.factor.data = select(pe.risk.factor.data, -vtedate)
  
  dvt.risk.factor.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, vtedate) %>%
    right_join(dvt.risk.factor.data, by = c("record_id", "VTE.Event.Number"))
  
  lymphedema.risk.factor.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, vtedate) %>%
    right_join(lymphedema.risk.factor.data, by = c("record_id", "VTE.Event.Number"))
  
  pe.risk.factor.data = vte.risk.factor.dates.data %>%
    select(record_id, VTE.Event.Number, vtedate) %>%
    right_join(pe.risk.factor.data, by = c("record_id", "VTE.Event.Number"))
}