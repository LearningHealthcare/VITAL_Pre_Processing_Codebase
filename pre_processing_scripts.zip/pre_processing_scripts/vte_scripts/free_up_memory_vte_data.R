# free_up_memory_vte_data.R

# This script frees up memory by removing variables/dataframes
# that will not be used in subsequent pre-processing or analysis.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

remove(Clinic.Visit.Month.Status)
remove(i)
remove(month.status)
remove(month.value)
remove(month.vector)
remove(month.year.potential.value)
remove(month.year.values)
remove(num.backslashes)
remove(num.dashes)
remove(Symptoms.Month.Status)
remove(potential.date)
remove(time.value)
remove(vte.date)
remove(vte.file.name)
remove(year.value)
remove(year.potential.value)
remove(vte.risk.factor.date)
remove(vte.risk.factor.date.first.format)
remove(vte.risk.factor.date.second.format)
remove(vte.risk.factor.date.third.format)
remove(vte.risk.factor.date.fourth.format)
remove(vte.risk.factor.date.fifth.format)
remove(vte.data)
remove(vte.risk.factor.dates.data)