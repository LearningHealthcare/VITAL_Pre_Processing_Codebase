# vte_risk_factors_cohort_selection.R

# This script identifies vte risk factor data, for factors
# other than DVT, pulmonary embolism, and lymphedema.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing Hip/Leg Fracture VTE data
hip.leg.fracture.vte.data = vte.data %>%
  # Remove non Hip/Leg Fracture VTE data
  filter(vte_rfs___1 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(fracture_date != "" | fracture_notes != "") %>%
  select(record_id, VTE.Event.Number, fracture_notes)

# Dataframe containing Hip/Knee Replacement VTE data
hip.knee.replacement.vte.data = vte.data %>%
  # Remove non Hip/Knee Replacement VTE data
  filter(vte_rfs___2 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(hipkneereplace_date != "" | hipkneereplace_notes != "") %>%
  select(record_id, VTE.Event.Number, hipkneereplace_notes)

# Dataframe containing Major General Surgery VTE data
major.general.surgery.vte.data = vte.data %>%
  # Remove non Major General Surgery VTE data
  filter(vte_rfs___3 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(gensurg_date != "" | gensurg_notes != "") %>%
  select(record_id, VTE.Event.Number, gensurg_notes)

# Dataframe containing Major Trauma VTE data
major.trauma.vte.data = vte.data %>%
  # Remove non Major Trauma VTE data
  filter(vte_rfs___4 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(trauma_date != "" | trauma_notes != "") %>%
  select(record_id, VTE.Event.Number, trauma_notes)

# Dataframe containing Spinal Cord injury VTE data
spinal.cord.injury.vte.data = vte.data %>%
  # Remove non Spinal Cord injury VTE data
  filter(vte_rfs___5 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(sci_date != "" | sci_notes != "") %>%
  select(record_id, VTE.Event.Number, sci_notes)

# Dataframe containing Arthoscopic Knee Surgery VTE Data
arthroscopic.knee.surgery.vte.data = vte.data %>%
  # Remove non Arthoscopic Knee Surgery VTE data
  filter(vte_rfs___6 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(arthknee_date != "" | arthknee_notes != "") %>%
  select(record_id, VTE.Event.Number, arthknee_notes)

# Dataframe containing Central Venous Lines VTE Data
central.venous.lines.vte.data = vte.data %>%
  # Remove non Central Venous Lines VTE data
  filter(vte_rfs___7 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(cvc_date != "" | cvc_notes != "") %>%
  select(record_id, VTE.Event.Number, cvc_notes)

# Dataframe containing chemotherapy VTE Data
chemotherapy.vte.data = vte.data %>%
  # Remove non chemotherapy VTE data
  filter(vte_rfs___8 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(chemo_date != "" | chemo_notes != "") %>%
  select(record_id, VTE.Event.Number, chemo_notes)

# Dataframe containing congestive heart failure VTE Data
CHF.vte.data = vte.data %>%
  # Remove non congestive heart failure VTE Data
  filter(vte_rfs___9 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(chf_date != "" | chf_notes != "") %>%
  select(record_id, VTE.Event.Number, chf_notes)

# Dataframe containing respiratory failure VTE Data
respiratory.failure.vte.data = vte.data %>%
  # Remove non respiratory failure VTE Data
  filter(vte_rfs___10 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(respfailure_date != "" | respfailure_notes != "") %>%
  select(record_id, VTE.Event.Number, respfailure_notes) 

# Dataframe containing hormone replacement therapy VTE Data
hormone.replacement.therapy.vte.data = vte.data %>%
  # Remove non hormone replacement therapy VTE Data
  filter(vte_rfs___11 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(hrt_date != "" | hrt_notes != "") %>%
  select(record_id, VTE.Event.Number, hrt_notes)

# Dataframe containing malignancy VTE Data
malignancy.vte.data = vte.data %>%
  # Remove non malignancy VTE Data
  filter(vte_rfs___12 == 1) %>%
  # Remove rows without either VTE date or clinical notes or active malignancy status
  filter(malig_date != "" | malig_notes != "" | !is.na(malig_active)) %>%
  select(record_id, VTE.Event.Number, malig_active, malig_notes) %>%
  mutate(Active.Malignancy.Status = ifelse(malig_active == 0, "No",
        ifelse(malig_active == 1, "Yes", NA))) %>%
  select(-malig_active)

# Dataframe containing oral contraceptive therapy VTE Data
oral.contraceptive.therapy.vte.data = vte.data %>%
  # Remove non oral contraceptive therapy VTE Data
  filter(vte_rfs___13 == 1) %>%
  # Remove rows without either VTE date or clinical notes or current OCP status
  filter(ocp_date != "" | ocp_notes != "" | !is.na(ocp_current)) %>%
  select(record_id, VTE.Event.Number, ocp_current, ocp_notes) %>%
  mutate(Current.OCP.Status = ifelse(ocp_current == 0, "No",
        ifelse(ocp_current == 1, "Yes", NA))) %>%
  select(-ocp_current)

# Dataframe containing stroke VTE Data
stroke.vte.data = vte.data %>%
  # Remove non stroke VTE Data
  filter(vte_rfs___14 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(stroke_date != "" | stroke_notes != "") %>%
  select(record_id, VTE.Event.Number, stroke_notes)

# Dataframe containing postpartum pregnancy VTE Data
postpartum.pregnancy.vte.data = vte.data %>%
  # Remove non postpartum pregnancy VTE data
  filter(vte_rfs___15 == 1) %>%
  # Remove rows without either VTE date or clinical notes or number of postpartum pregnancies
  filter(preg_post_date != "" | preg_num != "" | preg_notes != "") %>%
  select(record_id, VTE.Event.Number, preg_num, preg_notes)

# Dataframe containing thrombophilia VTE Data
thrombophilia.vte.data = vte.data %>%
  # Remove non thrombophilia data
  filter(vte_rfs___16 == 1) %>%
  select(record_id, VTE.Event.Number, vte_rfs___16) %>%
  mutate(Thrombophilia.Risk.Factor.Status = "Yes") 

# Dataframe containing Bed Rest VTE Data
bed.rest.vte.data = vte.data %>%
  # Remove non Bed Rest data
  filter(vte_rfs___17 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(bedrest_date != "" | bedrest_notes != "") %>%
  select(record_id, VTE.Event.Number, bedrest_notes)

# Dataframe containing Immobility VTE Data
immobility.vte.data = vte.data %>%
  # Remove non Immobility data
  filter(vte_rfs___18 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(immobility_date != "" | immobility_notes != "") %>%
  select(record_id, VTE.Event.Number, immobility_notes)

# Dataframe containing laparoscopic surgery VTE data
laparo.surgery.vte.data = vte.data %>%
  # Remove non laparoscopic data
  filter(vte_rfs___19 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(lapsurg_date != "" | lapsurg_notes != "") %>%
  select(record_id, VTE.Event.Number, lapsurg_notes)

# Dataframe containing obesity VTE Data
obseity.vte.data = vte.data %>%
  # Remove non obesity data
  filter(vte_rfs___20 == 1) %>%
  # Remove rows without either a body mass index (BMI) value or clinical notes 
  filter(!is.na(bmi) | obesity_notes != "") %>%
  select(record_id, VTE.Event.Number, height_obesity, weight_obesity, 
         bmi, obesity_notes) 

# Dataframe containing varicose veins VTE Data
varicose.vte.data = vte.data %>%
  # Remove non varicose veins data
  filter(vte_rfs___21 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(varicose_date != "" | varicose_notes != "") %>%
  select(record_id, VTE.Event.Number, varicose_notes)

# Dataframe containing premature birth VTE Data
premature.birth.vte.data = vte.data %>%
  # Remove non premature birth data
  filter(vte_rfs___22 == 1) %>%
  select(record_id, VTE.Event.Number, premature_notes) 

# Dataframe containing congenital heart disease VTE Data
congenital.heart.disease.vte.data = vte.data %>%
  # Remove non congenital heart disease data
  filter(vte_rfs___23 == 1) %>%
  select(record_id, VTE.Event.Number, chd_notes) 

# Dataframe containing surgery under the age of fourteen VTE Data
surgery.fourteen.vte.data = vte.data %>%
  # Remove non surgery under the age of fourteen data
  filter(vte_rfs___24 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(surg_14_date != "" | surg_14_notes != "") %>%
  select(record_id, VTE.Event.Number, surg_14_notes) 

# Dataframe containing trauma under the age of fourteen VTE Data
trauma.fourteen.vte.data = vte.data %>%
  # Remove non trauma under the age of fourteen data
  filter(vte_rfs___25 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(trauma_14_date != "" | trauma_14_notes != "") %>%
  select(record_id, VTE.Event.Number, trauma_14_notes)

# Dataframe containing antepartum pregnancy VTE Data
antepartum.pregnancy.vte.data = vte.data %>%
  # Remove non antepartum pregnancy data
  filter(vte_rfs___26 == 1) %>%
  # Remove rows without either information about antepartum pregnancy or clinical notes or number of pregnancies
  filter(preg_ante_weeks != "" | preg_ante_weeks_now != "" | preg_notes != "" | preg_num != "") %>%
  select(record_id, VTE.Event.Number, preg_ante_weeks, preg_ante_weeks_now, preg_num,
         preg_notes) 

# Dataframe containing cellulitis VTE Data
cellulitis.vte.data = vte.data %>%
  # Remove non cellulitis data
  filter(vte_rfs___27 == 1) %>%
  # Remove rows without either VTE date or clinical notes
  filter(cellulitis_date != "" | cellulitis_notes != "") %>%
  select(record_id, VTE.Event.Number, cellulitis_notes) 

# Dataframe containing smoking VTE Data
smoking.vte.data = vte.data %>%
  # Remove non smoking data
  filter(vte_rfs___28 == 1) %>%
  select(record_id, VTE.Event.Number, smoking_notes)