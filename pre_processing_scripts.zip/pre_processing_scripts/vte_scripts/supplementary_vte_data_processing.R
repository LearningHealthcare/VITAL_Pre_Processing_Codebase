# supplementary_vte_data_processing.R

# This script performs remaining VTE data processing on non-VTE date-time data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

postpartum.pregnancy.vte.data = postpartum.pregnancy.vte.data %>%
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  mutate(Pregnancy.Number = gsub("[^0-9]", "", preg_num)) %>%
  select(-preg_num)

postpartum.pregnancy.vte.data$Pregnancy.Number = as.integer(postpartum.pregnancy.vte.data$Pregnancy.Number)


antepartum.pregnancy.vte.data = antepartum.pregnancy.vte.data %>%
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  mutate(Pregnancy.Number = gsub("[^0-9]", "", preg_num)) %>%
  select(-preg_num)
  
antepartum.pregnancy.vte.data$Pregnancy.Number = as.integer(antepartum.pregnancy.vte.data$Pregnancy.Number)

# Identify time duration units in antepartum pregnancy symptoms and clinic visit variables
Symptoms.Month.Status = rep(FALSE, times = nrow(antepartum.pregnancy.vte.data))
Clinic.Visit.Month.Status = rep(FALSE, times = nrow(antepartum.pregnancy.vte.data))
for(i in 1:nrow(antepartum.pregnancy.vte.data)){
  time.value = antepartum.pregnancy.vte.data$preg_ante_weeks[i]
  # Check if symptoms value provided in terms of months
  Symptoms.Month.Status[i] = grepl("month", time.value)
  time.value = antepartum.pregnancy.vte.data$preg_ante_weeks_now[i]
  # Check if clinic visit value provided in terms of months
  Clinic.Visit.Month.Status[i] = grepl("month", time.value)
}

antepartum.pregnancy.vte.data = cbind.data.frame(antepartum.pregnancy.vte.data, Symptoms.Month.Status,
                                                 Clinic.Visit.Month.Status)

antepartum.pregnancy.vte.data = antepartum.pregnancy.vte.data %>%
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  mutate(Symptoms.Numeric.String = gsub("[^0-9]", "", preg_ante_weeks)) %>%
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  mutate(Clinic.Visit.Numeric.String = gsub("[^0-9]", "", preg_ante_weeks_now))

antepartum.pregnancy.vte.data$Symptoms.Numeric.String = as.integer(antepartum.pregnancy.vte.data$Symptoms.Numeric.String)
antepartum.pregnancy.vte.data$Clinic.Visit.Numeric.String = as.integer(antepartum.pregnancy.vte.data$Clinic.Visit.Numeric.String)

antepartum.pregnancy.vte.data = antepartum.pregnancy.vte.data %>%
  # Calculate antepartum pregnancy symptoms value, depending on whether value was provided in terms of weeks or months
  mutate(Preg.Ante.Weeks = ifelse(Symptoms.Month.Status == TRUE, Symptoms.Numeric.String * 4, Symptoms.Numeric.String)) %>%
  # Calculate antepartum pregnancy clinic visit value, depending on whether value was provided in terms of weeks or months
  mutate(Preg.Ante.Weeks.Now = ifelse(Clinic.Visit.Month.Status == TRUE, Clinic.Visit.Numeric.String * 4, Clinic.Visit.Numeric.String)) %>%
  select(-Symptoms.Month.Status, -Symptoms.Numeric.String, -Clinic.Visit.Numeric.String, -Clinic.Visit.Month.Status,
         -preg_ante_weeks, -preg_ante_weeks_now)