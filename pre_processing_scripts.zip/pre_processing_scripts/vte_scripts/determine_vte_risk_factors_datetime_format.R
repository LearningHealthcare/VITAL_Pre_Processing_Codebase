# determine_vte_risk_factors_datetime_format.R

# This script identifies the format of a VTE Risk Factor date-time entry.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

num.dashes = rep(0, times = nrow(vte.risk.factor.dates.data))

num.backslashes = rep(0, times = nrow(vte.risk.factor.dates.data))

# Identify number of dashes or backlashes in date-time entry (i.e. 01-01-2000, or 01/01/2000)
for(i in 1:nrow(vte.risk.factor.dates.data)){
  num.dashes[i] = length(unlist(strsplit(vte.risk.factor.dates.data$Date[i], split = "-")))
  num.backslashes[i] = length(unlist(strsplit(vte.risk.factor.dates.data$Date[i], split = "/")))
}

month.status = rep("", times = nrow(vte.risk.factor.dates.data))
month.value = rep("", nrow(vte.risk.factor.dates.data))
year.value = rep("", nrow(vte.risk.factor.dates.data))

# Check whether month name is present in date-time entry
month.status[grepl("January", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Jan", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("February", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Feb", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("March", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Mar", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("April", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Apr", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("May", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("June", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Jun", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("July", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Jul", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("August", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Aug", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("September", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Sep", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("October", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Oct", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("November", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Nov", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("December", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Dec", vte.risk.factor.dates.data$Date) == TRUE] = "Yes"

for(i in 1:nrow(vte.risk.factor.dates.data)){
  if(num.dashes[i] != 3 & num.backslashes[i] != 3){
    # Checks if date is given as month space year (i.e. January 2000)
    if(month.status[i] == "Yes"){
      month.year.potential.value = vte.risk.factor.dates.data$Date[i]
      # Split month and year
      month.year.values = unlist(strsplit(month.year.potential.value, split = "\\s+"))
      month.value[i] = month.year.values[1]
      if(length(month.year.values) == 2){
        year.potential.value = month.year.values[2]
        year.potential.value = trimws(year.potential.value)
        # Verify year is in proper format (4 numeric characters within time period covered by the VITAL Retrospective Database)
        if(nchar(year.potential.value) == 4 & year.potential.value == gsub("[^0-9]", "", year.potential.value)){
          if(as.integer(year.potential.value) >= initial.medical.history.year & as.integer(year.potential.value) <= year(Sys.Date())){
            year.value[i] = year.potential.value
          }
        }
      }
    # Checks if date given as year (i.e. 2000)
    }else{
      year.potential.value = vte.risk.factor.dates.data$Date[i]
      # Verify year is in proper format (4 numeric characters within time period covered by the VITAL Retrospective Database)
      if(nchar(year.potential.value) == 4 & year.potential.value == gsub("[^0-9]", "", year.potential.value)){
        if(as.integer(year.potential.value) >= initial.medical.history.year & as.integer(year.potential.value) <= year(Sys.Date())){
          year.value[i] = year.potential.value
        }
      }
    }
  }
}