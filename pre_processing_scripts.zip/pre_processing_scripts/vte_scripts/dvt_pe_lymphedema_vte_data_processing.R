# dvt_pe_lymphedema_data_processing.R

# This script performs data pre-processing on DVT, pulmonary embolism,
# and lymphedema risk factor data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing DVT risk factor data
dvt.risk.factor.data = vte.data %>%
  select(record_id, VTE.Event.Number, vtedate, isvteprovoked, vtetype___1, 
         vtelocation___1, vtelocation___2, vtelaterality___1, vtelaterality___2) %>%
  # Remove non-DVT data
  filter(vtetype___1 == 1) %>%
  mutate(VTE.Provoked.Status = ifelse(isvteprovoked == 0, "No", 
         ifelse(isvteprovoked == 1, "Yes", NA))) %>%
  mutate(DVT.Extremity.Status = ifelse(vtelocation___1 == 1 & vtelocation___2 != 1, "Upper.Extremity", 
         ifelse(vtelocation___2 == 1 & vtelocation___1 != 1, "Lower.Extremity", 
         ifelse(vtelocation___2 == 1 & vtelocation___1 == 1, "Upper.and.Lower.Extremity", NA)))) %>%
  mutate(DVT.Laterality.Status = ifelse(vtelaterality___1 == 1 & vtelaterality___2 != 1, "Right", 
         ifelse(vtelaterality___2 == 1 & vtelaterality___1 != 1, "Left", 
         ifelse(vtelaterality___2 == 1 & vtelaterality___1 == 1, "Bilateral", NA)))) %>%
  select(-isvteprovoked, -vtetype___1, -vtelocation___1, -vtelocation___2,
         -vtelaterality___1, -vtelaterality___2)

# Dataframe containing pulmonary embolism risk factor data
pe.risk.factor.data = vte.data %>%
  select(record_id, VTE.Event.Number, vtedate, isvteprovoked, vtetype___2, petype) %>%
  # Remove non-Pulmonary Embolism data
  filter(vtetype___2 == 1) %>%
  mutate(VTE.Provoked.Status = ifelse(isvteprovoked == 0, "No",
        ifelse(isvteprovoked == 1, "Yes", NA))) %>%
  mutate(PE.Type = ifelse(petype == 1, "Massive",
        ifelse(petype == 2, "Sub-massive", 
        ifelse(petype == 3, "Clinically Symptomatic",
        ifelse(petype == 4, "Clinically Asymptomatic", NA))))) %>%
  select(-vtetype___2, -petype, -isvteprovoked)

# Dataframe containing lymphedema risk factor data
lymphedema.risk.factor.data = vte.data %>%
  select(record_id, VTE.Event.Number, vtedate, vtetype___3, vtelaterality___1, vtelaterality___2) %>%
  # Remove non-lymphedema data
  filter(vtetype___3 == 1) %>%
  mutate(Lymphedema.Laterality.Status = ifelse(vtelaterality___1 == 1 & vtelaterality___2 != 1, "Right", 
        ifelse(vtelaterality___2 == 1 & vtelaterality___1 != 1,"Left", 
        ifelse(vtelaterality___2 == 1 & vtelaterality___1 == 1, "Bilateral", NA)))) %>%
  select(-vtetype___3, -vtelaterality___1, -vtelaterality___2)