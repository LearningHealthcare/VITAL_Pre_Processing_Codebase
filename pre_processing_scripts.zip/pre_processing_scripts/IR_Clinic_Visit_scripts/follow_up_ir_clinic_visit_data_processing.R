# follow_up_ir_clinic_visit_data_processing.R

# This script performs pre-processing on IR Clinic visit followup data,
# as derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing IR Clinic Visit followup data
follow.up.clinic.visit.data = ir.clinic.visit.data %>%
  select(record_id, IR.Clinic.Visit.Number, prior_proc, left_cc_past___0, 
         left_cc_past___1, left_cc_past___2, left_cc_past___3, left_cc_past___4,
         left_cc_past___5, left_cc_past___6, right_cc_past___0, right_cc_past___1,
         right_cc_past___2, right_cc_past___3, right_cc_past___4, right_cc_past___5, 
         right_cc_past___6, l_pain_change, l_pain_pp, l_edema_change, l_edema_pp,
         l_ulcer_change, l_ulcer_pp, l_claud_change, l_claud_pp, l_edema_change, 
         l_edema_pp, l_erythema_change, l_erythema_pp, r_pain_change, r_pain_pp,
         r_edema_change, r_edema_pp, r_ulcer_change, r_ulcer_pp, r_claud_change,
         r_claud_pp, r_erythema_change, r_erythema_pp, exer_int_change, exer_int_pp,
         follow_up___1, follow_up___2, follow_up___3, follow_up___4, follow_up___99,
         bleed_complication_name, bleed_comp_major_minor, bleed_complication_time,
         thromb_complication_name, thromb_comp_major_minor, thromb_complication_time,
         backpain_comp_major_minor, backpain_complication_time, other_complication_name, 
         other_comp_major_minor, other_complication_time, followup_details) %>%
  mutate(Prior.Procedure.Status = ifelse(prior_proc == 1, "Yes",
        ifelse(prior_proc == 0, "No", NA))) %>%
  select(-prior_proc)

follow.up.clinic.visit.data = follow.up.clinic.visit.data %>%
  mutate(Left.Follow.Up.Pain.Status = ifelse(left_cc_past___0 == 1, "Yes", 
        ifelse(left_cc_past___0 == 0, "No", NA))) %>%
  mutate(Left.Follow.Up.Swelling.Edema.Status = ifelse(left_cc_past___1 == 1, "Yes",
        ifelse(left_cc_past___1 == 0, "No", NA))) %>%
  mutate(Left.Follow.Up.Active.Ulcer.Status = ifelse(left_cc_past___2 == 1, "Yes",
        ifelse(left_cc_past___2 == 0, "No", NA))) %>%
  mutate(Left.Follow.Up.Healed.Ulcer.Status = ifelse(left_cc_past___3 == 1, "Yes",
        ifelse(left_cc_past___3 == 0, "No", NA))) %>%
  mutate(Left.Follow.Up.Venous.Claudication.Status = ifelse(left_cc_past___4 == 1, "Yes",
        ifelse(left_cc_past___4 == 0, "No", NA))) %>%
  mutate(Left.Follow.Up.Exercise.Intolerance.Status = ifelse(left_cc_past___5 == 1, "Yes",
        ifelse(left_cc_past___5 == 0, "No", NA))) %>%
  mutate(Left.Follow.Up.Erythema.Status = ifelse(left_cc_past___6 == 1, "Yes", 
        ifelse(left_cc_past___6 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Pain.Status = ifelse(right_cc_past___0 == 1, "Yes", 
        ifelse(right_cc_past___0 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Swelling.Edema.Status = ifelse(right_cc_past___1 == 1, "Yes",
        ifelse(right_cc_past___1 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Active.Ulcer.Status = ifelse(right_cc_past___2 == 1, "Yes",
        ifelse(right_cc_past___2 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Healed.Ulcer.Status = ifelse(right_cc_past___3 == 1, "Yes",
        ifelse(right_cc_past___3 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Venous.Claudication.Status = ifelse(right_cc_past___4 == 1, "Yes",
        ifelse(right_cc_past___4 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Exercise.Intolerance.Status = ifelse(right_cc_past___5 == 1, "Yes",
        ifelse(right_cc_past___5 == 0, "No", NA))) %>%
  mutate(Right.Follow.Up.Erythema.Status = ifelse(right_cc_past___6 == 1, "Yes", 
        ifelse(right_cc_past___6 == 0, "No", NA))) %>%
  select(-left_cc_past___0, -left_cc_past___1, -left_cc_past___2, -left_cc_past___3,
         -left_cc_past___4, -left_cc_past___5, -left_cc_past___6, -right_cc_past___0,
         -right_cc_past___1, -right_cc_past___2, -right_cc_past___3, -right_cc_past___4,
         -right_cc_past___5, -right_cc_past___6)

# Dataframe containing IR Clinic Visit Followup Status Data
ir.follow.up.status.data = select(follow.up.clinic.visit.data, record_id, IR.Clinic.Visit.Number, Left.Follow.Up.Pain.Status, 
   Left.Follow.Up.Swelling.Edema.Status, Left.Follow.Up.Active.Ulcer.Status, Left.Follow.Up.Healed.Ulcer.Status, 
   Left.Follow.Up.Venous.Claudication.Status, Left.Follow.Up.Exercise.Intolerance.Status, Left.Follow.Up.Erythema.Status,
   Right.Follow.Up.Pain.Status, Right.Follow.Up.Swelling.Edema.Status, Right.Follow.Up.Active.Ulcer.Status, Right.Follow.Up.Healed.Ulcer.Status, 
   Right.Follow.Up.Venous.Claudication.Status, Right.Follow.Up.Exercise.Intolerance.Status, Right.Follow.Up.Erythema.Status)

# Dataframe containing IR Clinic Visit Followup Provider Data
ir.follow.up.provider.data = follow.up.clinic.visit.data %>%
  select(record_id, IR.Clinic.Visit.Number, l_pain_pp, l_edema_pp, l_ulcer_pp, l_claud_pp,
         l_erythema_pp, exer_int_pp, r_pain_pp, r_edema_pp, r_ulcer_pp, r_claud_pp,
         r_erythema_pp) %>%
  gather(Follow.Up.Data.Type, Data.Value, -record_id, -IR.Clinic.Visit.Number) %>%
  filter(!is.na(Data.Value)) %>%
  mutate(Provider.Status = ifelse(Data.Value == 2, "Provider", 
        ifelse(Data.Value == 1, "Patient", NA))) %>%
  select(-Data.Value) %>%
  spread(Follow.Up.Data.Type, Provider.Status)

# Dataframe containing IR Clinic Visit Condition Change Data
ir.condition.change.data = follow.up.clinic.visit.data %>%
  select(record_id, IR.Clinic.Visit.Number, l_pain_change, l_edema_change, l_ulcer_change,
         l_claud_change, l_erythema_change, r_pain_change, r_edema_change, 
         r_ulcer_change, r_claud_change, r_erythema_change, exer_int_change) %>%
  gather(Follow.Up.Data.Type, Data.Value, -record_id, -IR.Clinic.Visit.Number) %>%
  filter(!is.na(Data.Value)) %>%
  mutate(Change.Status = ifelse(Data.Value == 1, "Completely.Improved",
        ifelse(Data.Value == 2, "Somewhat.Improved",
        ifelse(Data.Value == 4, "No.Improvement",
        ifelse(Data.Value == 5, "Worse", NA))))) %>%
  select(-Data.Value) %>%
  spread(Follow.Up.Data.Type, Change.Status)