# left_CEAP_data_processing.R

# This script performs pre-processing on left lower extremity CEAP IR Clinic Visit data,
# as derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing left lower extremity CEAP data
left.ceap.clinic.visit.data = ir.clinic.visit.data %>%
  filter(collected___2 == 1) %>%
  select(record_id, IR.Clinic.Visit.Number, l_c_ceap___0, l_c_ceap___1, l_c_ceap___2, 
        l_c_ceap___3, l_c_ceap___4, l_c_ceap___5, l_c_ceap___6, l_c_ceap___7, l_e_ceap___0,
        l_e_ceap___1, l_e_ceap___2, l_e_ceap___3, l_a_ceap___0, l_a_ceap___1, l_a_ceap___2,
        l_a_ceap___3, l_p_ceap___0, l_p_ceap___1, l_p_ceap___2) %>%
  mutate(C0.Status = ifelse(l_c_ceap___0 == 1, "Yes", NA)) %>%
  mutate(C1.Status = ifelse(l_c_ceap___1 == 1, "Yes", NA)) %>%
  mutate(C2.Status = ifelse(l_c_ceap___2 == 1, "Yes", NA)) %>%
  mutate(C3.Status = ifelse(l_c_ceap___3 == 1, "Yes", NA)) %>%
  mutate(C4.Status = ifelse(l_c_ceap___4 == 1, "Yes", NA)) %>%
  mutate(C5.Status = ifelse(l_c_ceap___5 == 1, "Yes", NA)) %>%
  mutate(C6.Status = ifelse(l_c_ceap___6 == 1, "Yes", NA)) %>%
  mutate(C.NA.Status = ifelse(l_c_ceap___7 == 1, "N/A", NA)) %>%
  mutate(EC.Status = ifelse(l_e_ceap___0 == 1, "Yes", NA)) %>%
  mutate(EP.Status = ifelse(l_e_ceap___1 == 1, "Yes", NA)) %>%
  mutate(ES.Status = ifelse(l_e_ceap___2 == 1, "Yes", NA)) %>%
  mutate(E.NA.Status = ifelse(l_e_ceap___3 == 1, "N/A", NA)) %>%
  mutate(AS.Status = ifelse(l_a_ceap___0 == 1, "Yes", NA)) %>%
  mutate(AD.Status = ifelse(l_a_ceap___1 == 1, "Yes", NA)) %>%
  mutate(AP.Status = ifelse(l_a_ceap___2 == 1, "Yes", NA)) %>%
  mutate(A.NA.Status = ifelse(l_a_ceap___3 == 1, "N/A", NA)) %>%
  mutate(PR.Status = ifelse(l_p_ceap___0 == 1, "Yes", NA)) %>%
  mutate(PO.Status = ifelse(l_p_ceap___1 == 1, "Yes", NA)) %>%
  mutate(P.NA.Status = ifelse(l_p_ceap___2 == 1, "N/A", NA)) %>%
  select(-l_c_ceap___0, -l_c_ceap___1, -l_c_ceap___2, -l_c_ceap___3, -l_c_ceap___4, -l_c_ceap___5, 
         -l_c_ceap___6, -l_c_ceap___7, -l_e_ceap___0, -l_e_ceap___1, -l_e_ceap___2, -l_e_ceap___3, 
         -l_a_ceap___0, -l_a_ceap___1, -l_a_ceap___2, -l_a_ceap___3, -l_p_ceap___0, -l_p_ceap___1, -l_p_ceap___2)
