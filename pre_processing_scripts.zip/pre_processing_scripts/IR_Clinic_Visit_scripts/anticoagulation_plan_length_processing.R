# anticoagulation_plan_length_processing.R

# This script performs pre-processing on IR Clinic Visit anticoagulation plan
# length data, as derived from VITAL Retrospective database. 

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing IR Clinic Visit Anticoagulation Plan Length Data
ir.clinic.visit.anticoagulation.plan.length.data = ir.clinic.visit.data %>%
  select(record_id, IR.Clinic.Visit.Number, lovenox_length, coumadin_length, 
         heparin_length, fragmin_length, arixtra_length, xarelto_length, 
         eliquis_length, plavix_length, asa_length, other_length) %>%
  gather(Anticoagulant.Type, Length.Value, -record_id, -IR.Clinic.Visit.Number) %>%
  filter(!is.na(Length.Value) & Length.Value != "")

Anticoagulant = rep("", times = nrow(ir.clinic.visit.anticoagulation.plan.length.data))

for(i in 1:nrow(ir.clinic.visit.anticoagulation.plan.length.data)){
  # Extract Anticoagulation Name from Anticoagulant Type
  anticoagulation.type = ir.clinic.visit.anticoagulation.plan.length.data$Anticoagulant.Type[i]
  anticoagulation.type = unlist(strsplit(anticoagulation.type, "_"))
  Anticoagulant[i] = anticoagulation.type[1]
}

ir.clinic.visit.anticoagulation.plan.length.data = cbind.data.frame(ir.clinic.visit.anticoagulation.plan.length.data, Anticoagulant)

ir.clinic.visit.anticoagulation.plan.length.data$Anticoagulant = as.character(ir.clinic.visit.anticoagulation.plan.length.data$Anticoagulant)

# Capitalize first letter of every word in Anticoagulation Name
ir.clinic.visit.anticoagulation.plan.length.data$Anticoagulant = toTitleCase(ir.clinic.visit.anticoagulation.plan.length.data$Anticoagulant)

ir.clinic.visit.anticoagulation.plan.length.data = select(ir.clinic.visit.anticoagulation.plan.length.data, -Anticoagulant.Type)

names(ir.clinic.visit.anticoagulation.plan.length.data)[3] = "Length"