# IR_Clinic_Visit_data_processing.R

# This overarching script performs the pre-processing on the IR Clinic Visit data,
# as derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

source(paste(ir.clinic.visit.directory, 'IR_Clinic_Visit_io.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'ir_clinic_visit_date_practitioner_data_processing.R', 
             sep = '/'))

source(paste(ir.clinic.visit.directory, 'left_lower_extremity_data_processing.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'right_lower_extremity_data_processing.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'left_CEAP_data_processing.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'right_CEAP_data_processing.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'villalta_ir_clinic_visit_data_processing.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'vcss_ir_clinic_visit_data_processing.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'follow_up_ir_clinic_visit_data_processing.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'complication_ir_clinic_visit_data_processing.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'anticoagulation_ir_clinic_visit_data_processing.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'free_up_memory_ir_clinic_visit_data.R', sep = '/'))