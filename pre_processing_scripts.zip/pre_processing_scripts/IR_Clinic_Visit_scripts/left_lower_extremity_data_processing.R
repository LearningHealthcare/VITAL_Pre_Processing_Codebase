# left_lower_extremity_data_processing.R

# This script performs left lower extremity IR Clinic Visit data pre-processing,
# as derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing left lower extremity IR Clinic Visit data
left.lower.extremity.clinic.visit.data = ir.clinic.visit.data %>%
  select(record_id, IR.Clinic.Visit.Number, l_cc___0, l_cc___1, l_cc___2,
  l_cc___3, l_cc___4, l_cc___5, l_edema_type, l_edema_elevation, l_claudication_distance, l_misc_signs___1,
  l_misc_signs___2, l_misc_signs___3, l_compression_style, l_compression_pressure, l_thigh_cir, l_calf_cir, l_ankle_cir) %>%
  mutate(Pain.Status = ifelse(l_cc___0 == 1, "Yes", ifelse(l_cc___0 == 0, "No", NA))) %>%
  mutate(Edema.Status = ifelse(l_cc___1 == 1, "Yes", ifelse(l_cc___1 == 0, "No", NA))) %>%
  mutate(Active.Ulcer.Status = ifelse(l_cc___2 == 1, "Yes", ifelse(l_cc___2 == 0, "No", NA))) %>%
  mutate(Healed.Ulcer.Status = ifelse(l_cc___3 == 1, "Yes", ifelse(l_cc___3 == 0, "No", NA))) %>%
  mutate(Venous.Claudication.Status = ifelse(l_cc___4 == 1, "Yes", ifelse(l_cc___4 == 0, "No", NA))) %>%
  mutate(Exercise.Intolerance.Status = ifelse(l_cc___5 == 1, "Yes", ifelse(l_cc___5 == 0, "No", NA))) %>%
  mutate(Edema.Type = ifelse(Edema.Status != 1, NA, ifelse(l_edema_type == 1, "Non-Pitting",
         ifelse(l_edema_type == 2, "1+ Pitting Edema", ifelse(l_edema_type == 3, "2+ Pitting Edema",
         ifelse(l_edema_type == 4, "3+ Pitting Edema", "Pitting Edema (not specified)")))))) %>%
  mutate(Edema.Elevation = ifelse(Edema.Status != 1, NA, ifelse(l_edema_elevation == 1, "Yes", "No"))) %>%
  mutate(Stemmers.sign.status = ifelse(l_misc_signs___1 == 1, "Yes", ifelse(l_misc_signs___1 == 0, "No", NA))) %>%
  mutate(Compression.stockings.status = ifelse(l_misc_signs___2 == 1, "Yes", ifelse(l_misc_signs___2 == 0, "No", NA))) %>%
  mutate(Dependent.Rubor.status = ifelse(l_misc_signs___3 == 1, "Yes", ifelse(l_misc_signs___3 == 0, "No", NA))) %>%
  mutate(Compression.Style = ifelse(Compression.stockings.status != "Yes", NA, ifelse(l_compression_style == 1, "Knee",
         ifelse(l_compression_style == 2, "Thigh", ifelse(l_compression_style == 3, "Chaps",
         ifelse(l_compression_style == 4, "Maternity", ifelse(l_compression_style == 5, "Arm",
         ifelse(l_compression_style == 6, "Glove", "Gauntlet")))))))) %>%
  mutate(Compression.Style = ifelse(Compression.stockings.status != "Yes", NA, ifelse(l_compression_pressure == 1, "15-20",
         ifelse(l_compression_style == 2, "20-30", ifelse(l_compression_style == 3, "30-40",
         ifelse(l_compression_style == 4, "40+", "Other")))))) %>%
  select(-l_cc___0, -l_cc___1, -l_cc___2, -l_cc___3, -l_cc___4, -l_cc___5, -l_edema_type, -l_edema_elevation,
         -l_misc_signs___1, -l_misc_signs___2, -l_misc_signs___3, -l_compression_style, -l_compression_pressure)

left.lower.extremity.clinic.visit.data$l_thigh_cir = as.numeric(left.lower.extremity.clinic.visit.data$l_thigh_cir)
left.lower.extremity.clinic.visit.data$l_calf_cir = as.numeric(left.lower.extremity.clinic.visit.data$l_calf_cir)
left.lower.extremity.clinic.visit.data$l_ankle_cir = as.numeric(left.lower.extremity.clinic.visit.data$l_ankle_cir)