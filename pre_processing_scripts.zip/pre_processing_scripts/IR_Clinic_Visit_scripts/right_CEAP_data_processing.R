# right_CEAP_data_processing.R

# This script performs pre-processing on right lower extremity CEAP IR Clinic Visit data,
# as derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing right lower extremity CEAP data
right.ceap.clinic.visit.data = ir.clinic.visit.data %>%
  filter(collected___2 == 1) %>%
  select(record_id, IR.Clinic.Visit.Number, r_c_ceap___0, r_c_ceap___1, r_c_ceap___2, 
         r_c_ceap___3, r_c_ceap___4, r_c_ceap___5, r_c_ceap___6, r_c_ceap___7, r_e_ceap___0,
         r_e_ceap___1, r_e_ceap___2, r_e_ceap___3, r_a_ceap___0, r_a_ceap___1, r_a_ceap___2,
         r_a_ceap___3, r_p_ceap___0, r_p_ceap___1, r_p_ceap___2) %>%
  mutate(C0.Status = ifelse(r_c_ceap___0 == 1, "Yes", NA)) %>%
  mutate(C1.Status = ifelse(r_c_ceap___1 == 1, "Yes", NA)) %>%
  mutate(C2.Status = ifelse(r_c_ceap___2 == 1, "Yes", NA)) %>%
  mutate(C3.Status = ifelse(r_c_ceap___3 == 1, "Yes", NA)) %>%
  mutate(C4.Status = ifelse(r_c_ceap___4 == 1, "Yes", NA)) %>%
  mutate(C5.Status = ifelse(r_c_ceap___5 == 1, "Yes", NA)) %>%
  mutate(C6.Status = ifelse(r_c_ceap___6 == 1, "Yes", NA)) %>%
  mutate(C.NA.Status = ifelse(r_c_ceap___7 == 1, "N/A", NA)) %>%
  mutate(EC.Status = ifelse(r_e_ceap___0 == 1, "Yes", NA)) %>%
  mutate(EP.Status = ifelse(r_e_ceap___1 == 1, "Yes", NA)) %>%
  mutate(ES.Status = ifelse(r_e_ceap___2 == 1, "Yes", NA)) %>%
  mutate(E.NA.Status = ifelse(r_e_ceap___3 == 1, "N/A", NA)) %>%
  mutate(AS.Status = ifelse(r_a_ceap___0 == 1, "Yes", NA)) %>%
  mutate(AD.Status = ifelse(r_a_ceap___1 == 1, "Yes", NA)) %>%
  mutate(AP.Status = ifelse(r_a_ceap___2 == 1, "Yes", NA)) %>%
  mutate(A.NA.Status = ifelse(r_a_ceap___3 == 1, "N/A", NA)) %>%
  mutate(PR.Status = ifelse(r_p_ceap___0 == 1, "Yes", NA)) %>%
  mutate(PO.Status = ifelse(r_p_ceap___1 == 1, "Yes", NA)) %>%
  mutate(P.NA.Status = ifelse(r_p_ceap___2 == 1, "N/A", NA)) %>%
  select(-r_c_ceap___0, -r_c_ceap___1, -r_c_ceap___2, -r_c_ceap___3, -r_c_ceap___4, -r_c_ceap___5, 
         -r_c_ceap___6, -r_c_ceap___7, -r_e_ceap___0, -r_e_ceap___1, -r_e_ceap___2, -r_e_ceap___3, 
         -r_a_ceap___0, -r_a_ceap___1, -r_a_ceap___2, -r_a_ceap___3, -r_p_ceap___0, -r_p_ceap___1, -r_p_ceap___2)
