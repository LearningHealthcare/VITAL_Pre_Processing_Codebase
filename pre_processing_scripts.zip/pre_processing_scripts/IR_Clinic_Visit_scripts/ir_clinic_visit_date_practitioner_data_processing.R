# ir_clinic_visit_date_practitioner_data_processing.R

# This script performs pre-processing on IR Clinic Visit Practitioner and Clinic Visit
# date-time data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

ir.clinic.visit.practitioner.visit.date.data = select(ir.clinic.visit.data,
  record_id, IR.Clinic.Visit.Number, practitioner, visitdate)

# Convert practitioner data from numerical encodings to string-based encodings, based on
# VITAL Retrospective codebook
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 1] = "Irina Axelrod"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 2] = "Pejman Ghanouni"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 3] = "Lawrence Hofmann"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 4] = "David Hovsepian"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 5] = "Gloria Hwang"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 6] = "Ibrahim Idakoji"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 7 |
                                                            ir.clinic.visit.practitioner.visit.date.data$practitioner == 16] = "Danielle Katz"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 8] = "Andrew Kesselman"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 9] = "Nishita Kothary"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 10] = "William Kuo"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 11] = "John Louie"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 12] = "Kara Maceda"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 13] = "Rajesh Shah"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 14] = "Daniel Sze"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 15] = "David Wang"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 17] = "Michael Dake"
ir.clinic.visit.practitioner.visit.date.data$practitioner[ir.clinic.visit.practitioner.visit.date.data$practitioner == 18] = "Stephen Kee"

for(i in 1:nrow(ir.clinic.visit.practitioner.visit.date.data)){
  ir.encounter.date = ir.clinic.visit.practitioner.visit.date.data$visitdate[i]
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  if(gsub("[^0-9]", "", ir.encounter.date) == ""){
    ir.clinic.visit.practitioner.visit.date.data$visitdate[i] = ""
  }else{
    # Separate multiple non-IR encounter date(s) on semicolon
    ir.encounter.date = unlist(strsplit(ir.encounter.date, ";"))
    # Remove IR Clinic Visits with multiple listed dates
    if(length(ir.encounter.date) > 1){
      ir.clinic.visit.practitioner.visit.date.data$visitdate[i] = ""
    }
  }
}

# Remove missing/improper date-time entries/encounters with multiple date-time entries
ir.clinic.visit.practitioner.visit.date.data = filter(ir.clinic.visit.practitioner.visit.date.data, visitdate != "")

source(paste(ir.clinic.visit.directory, 'determine_ir_clinic_visit_datetime_format.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'create_complete_ir_clinic_visit_date_time_string.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'standardize_ir_clinic_visit_date_time_strings.R', sep = '/'))