# complication_ir_clinic_visit_data_processing.R

# This script performs pre-processing on IR Clinic Visit Complication Data,
# as derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing IR Clinic Visit Complication Time Data
ir.complication.time.data = follow.up.clinic.visit.data %>% 
  select(record_id, IR.Clinic.Visit.Number,
         bleed_complication_time, backpain_complication_time, thromb_complication_time,
         other_complication_time) %>%
  gather(Complication.Type, Complication.Value, -record_id, -IR.Clinic.Visit.Number) %>%
  filter(!is.na(Complication.Value)) %>%
  mutate(Time.Period = ifelse(Complication.Value == 1, "< 1 day", 
        ifelse(Complication.Value == 2, "1-30 days",
        ifelse(Complication.Value == 3, "> 30 days", NA)))) %>%
  select(-Complication.Value) %>%
  spread(Complication.Type, Time.Period)

# Dataframe containing IR Clinic Visit Complication Status data
ir.complication.status.data = follow.up.clinic.visit.data %>%
  select(record_id, IR.Clinic.Visit.Number, bleed_comp_major_minor, thromb_comp_major_minor, 
         backpain_comp_major_minor, backpain_comp_major_minor, other_comp_major_minor) %>%
  gather(Complication.Type, Complication.Value, -record_id, -IR.Clinic.Visit.Number) %>%
  filter(!is.na(Complication.Value)) %>%
  mutate(Complication.Degree = ifelse(Complication.Value == 1, "Minor",
        ifelse(Complication.Value == 2, "Major", NA))) %>%
  select(-Complication.Value) %>%
  spread(Complication.Type, Complication.Degree)

# Dataframe containing IR Clinic Visit Complication Name data
ir.complication.name.data = follow.up.clinic.visit.data %>% 
  select(record_id, IR.Clinic.Visit.Number, bleed_complication_name,
         thromb_complication_name, other_complication_name) %>%
  filter(bleed_complication_name != "" | thromb_complication_name != "" | other_complication_name != "")