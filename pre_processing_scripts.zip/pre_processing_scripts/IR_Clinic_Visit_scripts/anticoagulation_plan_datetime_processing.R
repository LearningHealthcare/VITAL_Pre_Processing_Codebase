# anticoagulation_plan_datetime_processing.R

# This overarching script is responsible for performing pre-processing
# on the IR Clinic Visit Anticoagulation Plan date-time data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing IR Clinic Visit Anticoagulation Plan datetime data
ir.clinic.visit.anticoagulation.plan.dates.data = ir.clinic.visit.data %>%
  select(record_id, IR.Clinic.Visit.Number, lovenox_start, coumadin_start, 
         heparin_start, fragmin_start, arixtra_start, xarelto_start, eliquis_start, 
         plavix_start, asa_start, other_start) %>%
  gather(Anticoagulant.Type, Date, -record_id, -IR.Clinic.Visit.Number) %>%
  filter(!is.na(Date) & Date != "")

for(i in 1:nrow(ir.clinic.visit.anticoagulation.plan.dates.data)){
  anticoagulation.date = ir.clinic.visit.anticoagulation.plan.dates.data$Date[i]
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  if(gsub("[^0-9]", "", anticoagulation.date) == ""){
    ir.clinic.visit.anticoagulation.plan.dates.data$Date[i] = ""
  }else{
    # Separate multiple non-IR encounter date(s) on semicolon
    anticoagulation.date = unlist(strsplit(anticoagulation.date, ";"))
    ir.clinic.visit.anticoagulation.plan.dates.data$Date[i] = anticoagulation.date[1]
  }
}

# Remove missing/improper date-time entries
ir.clinic.visit.anticoagulation.plan.dates.data = filter(ir.clinic.visit.anticoagulation.plan.dates.data,
                                                         Date != "")

ir.clinic.visit.anticoagulation.plan.dates.data$Date = trimws(ir.clinic.visit.anticoagulation.plan.dates.data$Date)

source(paste(ir.clinic.visit.directory, 'determine_anticoagulation_plan_start_date_datetime_format.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'create_complete_anticoagulation_plan_start_date_date_time_string.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'standardize_anticoagulation_plan_start_date_date_time_strings.R', sep = '/'))