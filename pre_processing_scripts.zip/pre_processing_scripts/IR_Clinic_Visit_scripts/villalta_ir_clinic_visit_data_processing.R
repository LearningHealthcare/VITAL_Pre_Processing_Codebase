# villalta_ir_clinic_visit_data_processing.R

# This script performs pre-processing on villalta IR Clinic Visit data,
# as derived from the VITAL Retrospective Database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing left lower extremity Villalta data
left.villalta.clinic.visit.data = ir.clinic.visit.data %>%
  filter(collected___3 == 1) %>%
  select(record_id, IR.Clinic.Visit.Number, l_heaviness, l_pain, l_cramps, l_pruritis,
         l_paresthesia, l_pretibial_edema, l_hyperpigmentation, l_venous_ectasia, l_redness, 
         l_skin_induration, l_pain_compress, l_ulcer, l_villalta_calculated) %>%
  gather(Villalta.Criteria, Villata.Value, -record_id, -IR.Clinic.Visit.Number, -l_ulcer, 
         -l_villalta_calculated) %>%
  mutate(Villalta.Encoding = ifelse(Villata.Value == 0, "None", 
         ifelse(Villata.Value == 1, "Mild",
         ifelse(Villata.Value == 2, "Moderate", 
         ifelse(Villata.Value == 3, "Severe", NA))))) %>%
  select(-Villata.Value) %>%
  mutate(Left.Ulcer.Status = ifelse(l_ulcer == 1, "Yes", 
         ifelse(l_ulcer == 0, "No", NA))) %>%
  select(-l_ulcer) %>%
  spread(Villalta.Criteria, Villalta.Encoding)

left.villalta.clinic.visit.data$l_villalta_calculated = as.numeric(left.villalta.clinic.visit.data$l_villalta_calculated)

# Dataframe containing right lower extremity Villalta Data
right.villalta.clinic.visit.data = ir.clinic.visit.data %>%
  filter(collected___3 == 1) %>%
  select(record_id, IR.Clinic.Visit.Number, r_heaviness, r_pain, r_cramps, r_pruritis,
         r_paresthesia, r_pretibial_edema, r_hyperpigmentation, r_venous_ectasia, r_redness, 
         r_skin_induration, r_pain_compress, r_ucler, r_villalta_calc) %>%
  gather(Villalta.Criteria, Villata.Value, -record_id, -IR.Clinic.Visit.Number, -r_ucler, 
         -r_villalta_calc) %>%
  mutate(Villalta.Encoding = ifelse(Villata.Value == 0, "None", 
         ifelse(Villata.Value == 1, "Mild",
         ifelse(Villata.Value == 2, "Moderate", 
         ifelse(Villata.Value == 3, "Severe", NA))))) %>%
  select(-Villata.Value) %>%
  mutate(Right.Ulcer.Status = ifelse(r_ucler == 1, "Yes", ifelse(r_ucler == 0, "No", NA))) %>%
  select(-r_ucler) %>%
  spread(Villalta.Criteria, Villalta.Encoding)

right.villalta.clinic.visit.data$r_villalta_calc = as.numeric(right.villalta.clinic.visit.data$r_villalta_calc)
