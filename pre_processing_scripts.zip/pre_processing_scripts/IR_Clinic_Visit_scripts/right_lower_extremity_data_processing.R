# right_lower_extremity_data_processing.R

# This script performs pre-processing on right lower extremity IR Clinic Visit data,
# as derived from VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing right lower extremity IR Clinic Visit Data
right.lower.extremity.clinic.visit.data = ir.clinic.visit.data %>%
  select(record_id, IR.Clinic.Visit.Number, r_cc___0, r_cc___1, r_cc___2,
         r_cc___3, r_cc___4, r_cc___5, r_edema_type, r_edema_elevation, r_claudication_distance, r_misc_signs___1,
         r_misc_signs___2, r_misc_signs___3, r_compression_style, r_compression_pressure, r_thigh_cir, r_calf_cir, r_ankle_cir) %>%
  mutate(Pain.Status = ifelse(r_cc___0 == 1, "Yes", ifelse(r_cc___0 == 0, "No", NA))) %>%
  mutate(Edema.Status = ifelse(r_cc___1 == 1, "Yes", ifelse(r_cc___1 == 0, "No", NA))) %>%
  mutate(Active.Ulcer.Status = ifelse(r_cc___2 == 1, "Yes", ifelse(r_cc___2 == 0, "No", NA))) %>%
  mutate(Healed.Ulcer.Status = ifelse(r_cc___3 == 1, "Yes", ifelse(r_cc___3 == 0, "No", NA))) %>%
  mutate(Venous.Claudication.Status = ifelse(r_cc___4 == 1, "Yes", ifelse(r_cc___4 == 0, "No", NA))) %>%
  mutate(Exercise.Intolerance.Status = ifelse(r_cc___5 == 1, "Yes", ifelse(r_cc___5 == 0, "No", NA))) %>%
  mutate(Edema.Type = ifelse(Edema.Status != 1, NA, ifelse(r_edema_type == 1, "Non-Pitting",
         ifelse(r_edema_type == 2, "1+ Pitting Edema", ifelse(r_edema_type == 3, "2+ Pitting Edema",
         ifelse(r_edema_type == 4, "3+ Pitting Edema", "Pitting Edema (not specified)")))))) %>%
  mutate(Edema.Elevation = ifelse(Edema.Status != 1, NA, ifelse(r_edema_elevation == 1, "Yes", "No"))) %>%
  mutate(Stemmers.sign.status = ifelse(r_misc_signs___1 == 1, "Yes", ifelse(r_misc_signs___1 == 0, "No", NA))) %>%
  mutate(Compression.stockings.status = ifelse(r_misc_signs___2 == 1, "Yes", ifelse(r_misc_signs___2 == 0, "No", NA))) %>%
  mutate(Dependent.Rubor.status = ifelse(r_misc_signs___3 == 1, "Yes", ifelse(r_misc_signs___3 == 0, "No", NA))) %>%
  mutate(Compression.Style = ifelse(Compression.stockings.status != "Yes", NA, ifelse(r_compression_style == 1, "Knee",
         ifelse(r_compression_style == 2, "Thigh", ifelse(r_compression_style == 3, "Chaps",
         ifelse(r_compression_style == 4, "Maternity", ifelse(r_compression_style == 5, "Arm",
         ifelse(r_compression_style == 6, "Glove", "Gauntlet")))))))) %>%
  mutate(Compression.Style = ifelse(Compression.stockings.status != "Yes", NA, ifelse(r_compression_pressure == 1, "15-20",
         ifelse(r_compression_style == 2, "20-30", ifelse(r_compression_style == 3, "30-40",
         ifelse(r_compression_style == 4, "40+", "Other")))))) %>%
  select(-r_cc___0, -r_cc___1, -r_cc___2, -r_cc___3, -r_cc___4, -r_cc___5, -r_edema_type, -r_edema_elevation,
         -r_misc_signs___1, -r_misc_signs___2, -r_misc_signs___3, -r_compression_style, -r_compression_pressure)

right.lower.extremity.clinic.visit.data$r_thigh_cir = as.numeric(right.lower.extremity.clinic.visit.data$r_thigh_cir)
right.lower.extremity.clinic.visit.data$r_calf_cir = as.numeric(right.lower.extremity.clinic.visit.data$r_calf_cir)
right.lower.extremity.clinic.visit.data$r_ankle_cir = as.numeric(right.lower.extremity.clinic.visit.data$r_ankle_cir)