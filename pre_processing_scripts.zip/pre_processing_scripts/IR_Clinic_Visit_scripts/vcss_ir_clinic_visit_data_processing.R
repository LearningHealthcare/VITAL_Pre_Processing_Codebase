# vcss_ir_clinic_visit_data_processing.R

# This script performs data pre-processing on VCSS and lymphedema 
# IR Clinic Visit data, as derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing left lower extremity VCSS data
left.vcss.clinic.visit.data = ir.clinic.visit.data %>%
  filter(collected___4 == 1) %>%
  select(record_id, IR.Clinic.Visit.Number, l_pain_vcss, l_varicose, l_venousedema, 
         l_skinpigmentation, l_inflammation, l_induration, l_numulcers, l_actulcerduration,
         l_activeulcersize, l_compressive, l_vcss_calc) %>%
  gather(VCSS.Criteria, VCSS.Value, -record_id, -IR.Clinic.Visit.Number, -l_vcss_calc) %>%
  mutate(VCSS.Encoding = ifelse(VCSS.Value == 0, "0", 
         ifelse(VCSS.Value == 1, "Mild", 
         ifelse(VCSS.Value == 2, "Moderate", 
         ifelse(VCSS.Value == 3, "Severe", NA))))) %>%
  select(-VCSS.Value) %>%
  spread(VCSS.Criteria, VCSS.Encoding) 

# Dataframe containing left lower extremity lymphedema data
left.lymphedema.clinic.visit.data = ir.clinic.visit.data %>%
  select(l_lymphedema_signs___0, l_lymphedema_signs___1, l_lymphedema_signs___2, 
         l_lymphedema_signs___3, l_lymphedema_signs___4, l_lymphedema_signs___5, l_lymphedema_signs___6) %>%
  mutate(Skin.Thickening.Status = ifelse(l_lymphedema_signs___0 == 1, "Yes", ifelse(l_lymphedema_signs___0 == 0, "No", NA))) %>%
  mutate(Digitial.Edema.Status = ifelse(l_lymphedema_signs___0 == 1, "Yes", ifelse(l_lymphedema_signs___0 == 0, "No", NA))) %>%
  mutate(Edema.Dorsum.Foot.Status = ifelse(l_lymphedema_signs___0 == 1, "Yes", ifelse(l_lymphedema_signs___0 == 0, "No", NA))) %>%
  mutate(Hyperkeratosis.Status = ifelse(l_lymphedema_signs___0 == 1, "Yes", ifelse(l_lymphedema_signs___0 == 0, "No", NA))) %>%
  mutate(Erythema.Status = ifelse(l_lymphedema_signs___0 == 1, "Yes", ifelse(l_lymphedema_signs___0 == 0, "No", NA))) %>%
  mutate(Lymph.Cysts.Status = ifelse(l_lymphedema_signs___0 == 1, "Yes", ifelse(l_lymphedema_signs___0 == 0, "No", NA))) %>%
  select(-l_lymphedema_signs___0,
         -l_lymphedema_signs___1, -l_lymphedema_signs___2, -l_lymphedema_signs___3, -l_lymphedema_signs___4, -l_lymphedema_signs___5,
         -l_lymphedema_signs___6)

left.vcss.clinic.visit.data$l_vcss_calc = as.numeric(left.vcss.clinic.visit.data$l_vcss_calc)

# Dataframe containing right lower extremity VCSS data
right.vcss.clinic.visit.data = ir.clinic.visit.data %>%
  filter(collected___4 == 1) %>%
  select(record_id, IR.Clinic.Visit.Number, r_pain_vcss, r_varicose, r_venousedema, 
         r_skinpigmentation, r_inflammation, r_induration, r_numulcers, r_actulcerduration,
         r_activeulcersize, r_compressive, r_vcss_calc) %>%
  gather(VCSS.Criteria, VCSS.Value, -record_id, -IR.Clinic.Visit.Number, -r_vcss_calc) %>%
  mutate(VCSS.Encoding = ifelse(VCSS.Value == 0, "0", 
         ifelse(VCSS.Value == 1, "Mild", 
         ifelse(VCSS.Value == 2, "Moderate", 
         ifelse(VCSS.Value == 3, "Severe", NA))))) %>%
  select(-VCSS.Value) %>%
  spread(VCSS.Criteria, VCSS.Encoding)

# Dataframe containing right lower extremity lymphedema data
right.lymphedema.clinic.visit.data = ir.clinic.visit.data %>%
  select(r_lymphedema_signs___0, r_lymphedema_signs___1, r_lymphedema_signs___2, r_lymphedema_signs___3, 
         r_lymphedema_signs___4, r_lymphedema_signs___5, r_lymphedema_signs___6) %>%
  mutate(Skin.Thickening.Status = ifelse(r_lymphedema_signs___0 == 1, "Yes", ifelse(r_lymphedema_signs___0 == 0, "No", NA))) %>%
  mutate(Digitial.Edema.Status = ifelse(r_lymphedema_signs___0 == 1, "Yes", ifelse(r_lymphedema_signs___0 == 0, "No", NA))) %>%
  mutate(Edema.Dorsum.Foot.Status = ifelse(r_lymphedema_signs___0 == 1, "Yes", ifelse(r_lymphedema_signs___0 == 0, "No", NA))) %>%
  mutate(Hyperkeratosis.Status = ifelse(r_lymphedema_signs___0 == 1, "Yes", ifelse(r_lymphedema_signs___0 == 0, "No", NA))) %>%
  mutate(Erythema.Status = ifelse(r_lymphedema_signs___0 == 1, "Yes", ifelse(r_lymphedema_signs___0 == 0, "No", NA))) %>%
  mutate(Lymph.Cysts.Status = ifelse(r_lymphedema_signs___0 == 1, "Yes", ifelse(r_lymphedema_signs___0 == 0, "No", NA))) %>%
  select(-r_lymphedema_signs___0, -r_lymphedema_signs___1, -r_lymphedema_signs___2, -r_lymphedema_signs___3, -r_lymphedema_signs___4, 
         -r_lymphedema_signs___5, -r_lymphedema_signs___6)

right.vcss.clinic.visit.data$r_vcss_calc = as.numeric(right.vcss.clinic.visit.data$r_vcss_calc)