# anticoagulation_plan_dosage_processing.R

# This script performs pre-processing on IR Clinic Visit anticoagulation plan dosage data,
# as derived from the VITAL Retrospective Database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing IR Clinic Visit Anticoagulation Plan Dosage Data
ir.clinic.visit.anticoagulation.plan.dosage.data = ir.clinic.visit.data %>%
  select(record_id, IR.Clinic.Visit.Number, lovenox_dose, coumadin_dose, heparin_dose,
         fragmin_dose, arixtra_dose, xarelto_dose, eliquis_dose, plavix_dose, asa_dose,
         other_dose) %>%
  gather(Anticoagulant.Type, Dose.Value, -record_id, -IR.Clinic.Visit.Number) %>%
  filter(!is.na(Dose.Value) & Dose.Value != "")

for(i in 1:nrow(ir.clinic.visit.anticoagulation.plan.dosage.data)){
  anticoagulation.dosage = ir.clinic.visit.anticoagulation.plan.dosage.data$Dose.Value[i]
  # Split multiple dosage amounts on three possible separators
  anticoagulation.dosage = unlist(strsplit(anticoagulation.dosage, ","))
  anticoagulation.dosage = anticoagulation.dosage[1]
  anticoagulation.dosage = unlist(strsplit(anticoagulation.dosage, ";"))
  anticoagulation.dosage = anticoagulation.dosage[1]
  anticoagulation.dosage = unlist(strsplit(anticoagulation.dosage, "/"))
  ir.clinic.visit.anticoagulation.plan.dosage.data$Dose.Value[i] = anticoagulation.dosage[1]
}

# See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
ir.clinic.visit.anticoagulation.plan.dosage.data$Dose.Value = gsub("[^0-9.]", "", 
                                                                   ir.clinic.visit.anticoagulation.plan.dosage.data$Dose.Value)

ir.clinic.visit.anticoagulation.plan.dosage.data$Dose.Value[ir.clinic.visit.anticoagulation.plan.dosage.data$Dose.Value == ""] = NA

ir.clinic.visit.anticoagulation.plan.dosage.data$Dose.Value = as.numeric(ir.clinic.visit.anticoagulation.plan.dosage.data$Dose.Value)

Anticoagulant = rep("", times = nrow(ir.clinic.visit.anticoagulation.plan.dosage.data))

for(i in 1:nrow(ir.clinic.visit.anticoagulation.plan.dosage.data)){
  # Extract Anticoagulant Name from Anticoagulant Type
  anticoagulation.type = ir.clinic.visit.anticoagulation.plan.dosage.data$Anticoagulant.Type[i]
  anticoagulation.type = unlist(strsplit(anticoagulation.type, "_"))
  Anticoagulant[i] = anticoagulation.type[1]
}

ir.clinic.visit.anticoagulation.plan.dosage.data = cbind.data.frame(ir.clinic.visit.anticoagulation.plan.dosage.data, Anticoagulant)

ir.clinic.visit.anticoagulation.plan.dosage.data$Anticoagulant = as.character(ir.clinic.visit.anticoagulation.plan.dosage.data$Anticoagulant)

# Capitalize first letter of every word in Anticoagulant Name
ir.clinic.visit.anticoagulation.plan.dosage.data$Anticoagulant = toTitleCase(ir.clinic.visit.anticoagulation.plan.dosage.data$Anticoagulant)

ir.clinic.visit.anticoagulation.plan.dosage.data = select(ir.clinic.visit.anticoagulation.plan.dosage.data, -Anticoagulant.Type)

names(ir.clinic.visit.anticoagulation.plan.dosage.data)[3] = "Dosage"