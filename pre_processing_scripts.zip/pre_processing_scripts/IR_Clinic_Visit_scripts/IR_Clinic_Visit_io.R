# IR_Clinic_Visit_io.R

# This script performs the IR Clinic Visit data I/O, as well as the
# initial pre-processing on the IR Clinic Visit data.

# By David Cohn

# Rubin and Hofmann Labs

# IR Clinic Visit data I/O
ir.clinic.visit.data = read.csv(ir.clinic.visit.file.name, 
                                stringsAsFactors = FALSE, header = TRUE)

ir.clinic.visit.data = ir.clinic.visit.data %>%
  filter(redcap_repeat_instrument == "ir_clinic_visit") %>%
  # Remove IR Clinic Vists without Clinic Date
  filter(visitdate != "") %>%
  select(-redcap_repeat_instrument)

names(ir.clinic.visit.data)[2] = "IR.Clinic.Visit.Number"

# Dataframe containing bilateral characteristics IR Clinic Visit data
bilateral.characteristics.clinic.visit.data = ir.clinic.visit.data %>%
  select(record_id, IR.Clinic.Visit.Number, vds, b_misc_signs___0) %>%
  mutate(B.Misc.Signs.Status = ifelse(b_misc_signs___0 == 1, "IVC.Filter.Present", NA)) %>%
  select(-B.Misc.Signs.Status)

# Dataframe containing procedural planning IR Clinic Visit data
procedural.planning.ir.clinic.visit.data = ir.clinic.visit.data %>% 
  select(record_id, IR.Clinic.Visit.Number, procedural_planning,
         plan_access, anticoag_plan) %>%
  mutate(Procedural.Planning.Status = ifelse(procedural_planning == 1, "Yes",
        ifelse(procedural_planning == 0, "No", NA))) %>%
  select(-procedural_planning)