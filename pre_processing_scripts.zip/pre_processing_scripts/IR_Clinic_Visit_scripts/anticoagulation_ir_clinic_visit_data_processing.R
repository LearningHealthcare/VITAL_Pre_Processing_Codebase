# anticoagulation_ir_clinic_visit_data_processing.R

# This overarching script is responsible for pre-processing IR Clinic Visit anticoagulation Plan
# data, as derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

source(paste(ir.clinic.visit.directory, 'anticoagulation_plan_datetime_processing.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'anticoagulation_plan_dosage_processing.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'anticoagulation_plan_frequency_processing.R', sep = '/'))

source(paste(ir.clinic.visit.directory, 'anticoagulation_plan_length_processing.R', sep = '/'))

# Dataframe containing IR Clinic Visit Anticoagulation Plan Name Data
ir.clinic.visit.anticoagulation.plan.name.data = ir.clinic.visit.data %>%
  select(record_id, IR.Clinic.Visit.Number, other) %>%
  filter(!is.na(other) & other != "") %>%
  mutate(Anticoagulant = "Other")

names(ir.clinic.visit.anticoagulation.plan.name.data)[3] = "Other.Anticoagulant.Name (If Applicable)"

# Combination of IR Anticoagulation Plan Date-time, Dosage, Frequency, Length of Regimen, and Anticoagulation
# Name data in a single dataframe
ir.clinic.visit.anticoagulation.plan.data = ir.clinic.visit.practitioner.visit.date.data %>%
  select(record_id, IR.Clinic.Visit.Number) %>%
  left_join(ir.clinic.visit.anticoagulation.plan.dates.data, by = c("record_id", "IR.Clinic.Visit.Number")) %>%
  full_join(ir.clinic.visit.anticoagulation.plan.dosage.data, by = c("record_id", "IR.Clinic.Visit.Number", "Anticoagulant")) %>%
  full_join(ir.clinic.visit.anticoagulation.plan.frequency.data, by = c("record_id", "IR.Clinic.Visit.Number", "Anticoagulant")) %>%
  full_join(ir.clinic.visit.anticoagulation.plan.length.data, by = c("record_id", "IR.Clinic.Visit.Number", "Anticoagulant")) %>%
  full_join(ir.clinic.visit.anticoagulation.plan.name.data, by = c("record_id", "IR.Clinic.Visit.Number", "Anticoagulant")) %>%
  filter(!is.na(Anticoagulant))

ir.clinic.visit.anticoagulation.plan.data$Anticoagulant[ir.clinic.visit.anticoagulation.plan.data$Anticoagulant == "Asa"] = "Aspirin"

# Dataframe containing IR Clinic Visit Anticoagulation Plan INR Data
ir.clinic.visit.anticoagulation.plan.inr.data = ir.clinic.visit.data %>%
  select(record_id, IR.Clinic.Visit.Number, inrcurrent, inrtarget) %>%
  filter((!is.na(inrcurrent) & inrcurrent != "")| (!is.na(inrtarget) & inrtarget != ""))

# Dataframe containing IR Clinic Vist Anticoagulation Plan anti-XA Data
ir.clinic.visit.anticoagulation.plan.anti.xa.data = ir.clinic.visit.data %>%
  select(record_id, IR.Clinic.Visit.Number, antixacurrent, antixatarget) %>%
  filter((!is.na(antixacurrent) & antixacurrent != "")| (!is.na(antixatarget) & antixatarget != ""))
