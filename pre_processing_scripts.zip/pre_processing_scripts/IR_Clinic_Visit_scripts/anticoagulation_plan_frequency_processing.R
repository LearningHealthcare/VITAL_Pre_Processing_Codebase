# anticoagulation_plan_frequency_processing.R

# This script performs pre-processing on IR Clinic Visit Anticoagulation Plan Frequency data,
# as derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing IR Clinic Visit Anticoagulation Plan Frequncy Data
ir.clinic.visit.anticoagulation.plan.frequency.data = ir.clinic.visit.data %>% 
  select(record_id, IR.Clinic.Visit.Number, lovenox_freq, coumadin_freq, heparin_freq, 
         fragmin_freq, arixtra_freq, xarelto_freq, eliquis_freq, plavix_freq, asa_freq, other_freq) %>%
  gather(Anticoagulant.Type, Frequency.Value, -record_id, -IR.Clinic.Visit.Number) %>%
  filter(!is.na(Frequency.Value) & Frequency.Value != "")

ir.clinic.visit.anticoagulation.plan.frequency.data$Frequency.Value[ir.clinic.visit.anticoagulation.plan.frequency.data$Frequency.Value == "?"] = ""

ir.clinic.visit.anticoagulation.plan.frequency.data$Frequency.Value = toupper(ir.clinic.visit.anticoagulation.plan.frequency.data$Frequency.Value)

ir.clinic.visit.anticoagulation.plan.frequency.data = filter(ir.clinic.visit.anticoagulation.plan.frequency.data, Frequency.Value != "")

Anticoagulant = rep("", times = nrow(ir.clinic.visit.anticoagulation.plan.frequency.data))

for(i in 1:nrow(ir.clinic.visit.anticoagulation.plan.frequency.data)){
  # Extract Anticoagulant Name from Anticoagulant Type
  anticoagulation.type = ir.clinic.visit.anticoagulation.plan.frequency.data$Anticoagulant.Type[i]
  anticoagulation.type = unlist(strsplit(anticoagulation.type, "_"))
  Anticoagulant[i] = anticoagulation.type[1]
}

ir.clinic.visit.anticoagulation.plan.frequency.data = cbind.data.frame(ir.clinic.visit.anticoagulation.plan.frequency.data, Anticoagulant)

ir.clinic.visit.anticoagulation.plan.frequency.data$Anticoagulant = as.character(ir.clinic.visit.anticoagulation.plan.frequency.data$Anticoagulant)

# Capitalize first letter of every word in Anticoagulant Name
ir.clinic.visit.anticoagulation.plan.frequency.data$Anticoagulant = toTitleCase(ir.clinic.visit.anticoagulation.plan.frequency.data$Anticoagulant)

ir.clinic.visit.anticoagulation.plan.frequency.data = select(ir.clinic.visit.anticoagulation.plan.frequency.data, -Anticoagulant.Type)

names(ir.clinic.visit.anticoagulation.plan.frequency.data)[3] = "Frequency"