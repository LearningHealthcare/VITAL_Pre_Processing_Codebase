# determine_anticoagulation_plan_start_date_datetime_format.R

# This script identifies the format of a IR Clinic Visit Anticoagulation Plan date-time entry.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

num.dashes = rep(0, times = nrow(ir.clinic.visit.anticoagulation.plan.dates.data))

num.backslashes = rep(0, times = nrow(ir.clinic.visit.anticoagulation.plan.dates.data))

# Identify number of dashes or backlashes in date-time entry (i.e. 01-01-2000, or 01/01/2000)
for(i in 1:nrow(ir.clinic.visit.anticoagulation.plan.dates.data)){
  num.dashes[i] = length(unlist(strsplit(ir.clinic.visit.anticoagulation.plan.dates.data$Date[i], split = "-")))
  num.backslashes[i] = length(unlist(strsplit(ir.clinic.visit.anticoagulation.plan.dates.data$Date[i], split = "/")))
}

month.status = rep("", times = nrow(ir.clinic.visit.anticoagulation.plan.dates.data))
month.value = rep("", nrow(ir.clinic.visit.anticoagulation.plan.dates.data))
year.value = rep("", nrow(ir.clinic.visit.anticoagulation.plan.dates.data))

# Check whether month name is present in date-time entry
month.status[grepl("January", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Jan", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("February", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Feb", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("March", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Mar", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("April", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Apr", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("May", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("June", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Jun", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("July", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Jul", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("August", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Aug", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("September", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Sep", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("October", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Oct", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("November", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Nov", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("December", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Dec", ir.clinic.visit.anticoagulation.plan.dates.data$Date) == TRUE] = "Yes"

for(i in 1:nrow(ir.clinic.visit.anticoagulation.plan.dates.data)){
  if(num.dashes[i] != 3 & num.backslashes[i] != 3){
    # Checks if date is given as month space year (i.e. January 2000)
    if(month.status[i] == "Yes"){
      month.year.potential.value = ir.clinic.visit.anticoagulation.plan.dates.data$Date[i]
      # Split month and year
      month.year.values = unlist(strsplit(month.year.potential.value, split = "\\s+"))
      month.value[i] = month.year.values[1]
      if(length(month.year.values) == 2){
        year.potential.value = month.year.values[2]
        year.potential.value = trimws(year.potential.value)
        # Verify year is in proper format (4 numeric characters within time period covered by the VITAL Retrospective Database)
        if(nchar(year.potential.value) == 4 & year.potential.value == gsub("[^0-9]", "", year.potential.value)){
          if(as.integer(year.potential.value) >= initial.medical.history.year & as.integer(year.potential.value) <= year(Sys.Date())){
            year.value[i] = year.potential.value
          }
        }
      }
    # Checks if date given as year (i.e. 2000)
    }else{
      year.potential.value = ir.clinic.visit.anticoagulation.plan.dates.data$Date[i]
      # Verify year is in proper format (4 numeric characters within time period covered by the VITAL Retrospective Database)
      if(nchar(year.potential.value) == 4 & year.potential.value == gsub("[^0-9]", "", year.potential.value)){
        if(as.integer(year.potential.value) >= initial.medical.history.year & as.integer(year.potential.value) <= year(Sys.Date())){
          year.value[i] = year.potential.value
        }
      }
    }
  }
}