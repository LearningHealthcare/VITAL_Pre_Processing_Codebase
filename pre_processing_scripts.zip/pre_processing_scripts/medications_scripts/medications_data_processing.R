# medications_data_processing.R

# This overarching script performs the data pre-processing on
# medication data derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

medications.data = read.csv(medications.file.name, 
  stringsAsFactors = FALSE, header = TRUE)

medications.data = medications.data %>%
  filter(redcap_repeat_instrument == "medications") %>%
  select(-redcap_repeat_instrument, -med_sig, -med_ordering_date, 
         -med_quantity, -med_unit, -med_refills, -med_order_status,
         -med_order_class, -med_order_mode, -medications_complete)

names(medications.data)[2] = "Medication.Number"

# Convert medication start date to date-time format
medications.data$med_start_date = as.POSIXct(medications.data$med_start_date)

medications.data$med_end_date[medications.data$med_end_date == ""] = NA

source(paste(medications.directory, 'medication_class_generic_name_processing.R', sep = '/'))

source(paste(medications.directory, 'medication_dose_frequency_processing.R', sep = '/'))

# Medications Med Route Conversion from Numerical Encodings to String
# Encodings, based on VITAL Retrospective codebook
medications.data$med_route[medications.data$med_route == 1] = "Intravenous"
medications.data$med_route[medications.data$med_route == 2] = "Subcutaneous"
medications.data$med_route[medications.data$med_route == 3] = "Oral"
medications.data$med_route[medications.data$med_route == 4] = "Hemodialysis"
medications.data$med_route[medications.data$med_route == 5] = "Thru Sheath"
medications.data$med_route[medications.data$med_route == 6] = "Rectal"
medications.data$med_route[medications.data$med_route == 7] = "Feeding Tube"
medications.data$med_route[medications.data$med_route == 8] = "Intraperitoneal"
medications.data$med_route[medications.data$med_route == 9] = "Intra-arterial"
medications.data$med_route[medications.data$med_route == 10] = "Swish & Swallow"

# Free up memory
remove(medication.strength)
remove(i)
remove(Medication.Stength.Amount)
remove(Medication.Strength.Units)
remove(medications.file.name)