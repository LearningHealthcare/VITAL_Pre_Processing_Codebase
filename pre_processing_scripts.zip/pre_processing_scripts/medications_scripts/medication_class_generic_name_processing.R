# medication_class_generic_name_processing.R

# This script performs pre-processing on medications therapeutic and pharmalogical classes,
# as well as the generic names of the medications.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Conversion of Therapeutic Class from numerical encodings to String-based Encodings,
# based on VITAL Retrospective codebook
medications.data$thera_class[medications.data$thera_class == 1] = "Anticoagulants"
medications.data$thera_class[medications.data$thera_class == 2] = "Anti-platelet Drugs"
medications.data$thera_class[medications.data$thera_class == 3] = "Analgesics"
medications.data$thera_class[medications.data$thera_class == 4] = "Analgesics & Anesthetics"

# Conversion of Pharmalogical Class from numerical encodings to String-based Encodings,
# based on VITAL Retrospective codebook
medications.data$pharm_class[medications.data$pharm_class == 1] = "Heparin and Related Preparations"
medications.data$pharm_class[medications.data$pharm_class == 2] = "Anticoagulants, Coumarin Type"
medications.data$pharm_class[medications.data$pharm_class == 3] = "Direct Factor XA Inhibitors"
medications.data$pharm_class[medications.data$pharm_class == 4] = "Platelet Aggregation Inhibitors"
medications.data$pharm_class[medications.data$pharm_class == 5] = "Analgesic/Antipyretics, Salicyates"
medications.data$pharm_class[medications.data$pharm_class == 6] = "Thrombin Inhibitors, Selected, Direct, Reversible"
medications.data$pharm_class[medications.data$pharm_class == 7] = "Thrombin Inhibitors, Selected, Direct, Reversible-Hirudin"
medications.data$pharm_class[medications.data$pharm_class == 8] = "Analgesics, Non-Narcotic"
medications.data$pharm_class[medications.data$pharm_class == 9] = "Analgesic, Salicylate, Barbiturate, Xanthine Combination"
medications.data$pharm_class[medications.data$pharm_class == 10] = "Narcotic and Salicylate Analgesics, Barbiturate, Xanthine"
medications.data$pharm_class[medications.data$pharm_class == 11] = "Narcotic Analgesic and Salicylate Analgesic Combination"

# Conversion of Generic Medication Name from numerical encodings to String-based Encodings,
# based on VITAL Retrospective codebook
medications.data$simple_generic[medications.data$simple_generic == 1] = "Heparin"
medications.data$simple_generic[medications.data$simple_generic == 2] = "Enoxaparin"
medications.data$simple_generic[medications.data$simple_generic == 3] = "Warfarin"
medications.data$simple_generic[medications.data$simple_generic == 4] = "Aspirin"
medications.data$simple_generic[medications.data$simple_generic == 5] = "Rivaroxaban"
medications.data$simple_generic[medications.data$simple_generic == 6] = "Apixaban"
medications.data$simple_generic[medications.data$simple_generic == 7] = "Fondaparinux"
medications.data$simple_generic[medications.data$simple_generic == 8] = "Clopidogrel"
medications.data$simple_generic[medications.data$simple_generic == 9] = "Argatroban"
medications.data$simple_generic[medications.data$simple_generic == 10] = "Bivalirudin"
medications.data$simple_generic[medications.data$simple_generic == 11] = "Dabigatran Etexilate"
medications.data$simple_generic[medications.data$simple_generic == 12] = "Aspirin, Butalbital, Caffeine"
medications.data$simple_generic[medications.data$simple_generic == 13] = "Lepirudin"
medications.data$simple_generic[medications.data$simple_generic == 14] = "Prasugrel"
medications.data$simple_generic[medications.data$simple_generic == 15] = "Acetaminophen, Aspirin, Caffeine"
medications.data$simple_generic[medications.data$simple_generic == 16] = "Tirofiban"
medications.data$simple_generic[medications.data$simple_generic == 17] = "Dalteparin"
medications.data$simple_generic[medications.data$simple_generic == 18] = "Cilostazol"
medications.data$simple_generic[medications.data$simple_generic == 19] = "Aspirin, Oxycodone"
medications.data$simple_generic[medications.data$simple_generic == 20] = "Aspirin, Hydrocodone"
medications.data$simple_generic[medications.data$simple_generic == 21] = "Aspirin, Dipyridamole"
medications.data$simple_generic[medications.data$simple_generic == 22] = "Aspirin, Citric Acid, Sodium Bicarbonate"
medications.data$simple_generic[medications.data$simple_generic == 23] = "Aspirin, Calcium Carbonate"