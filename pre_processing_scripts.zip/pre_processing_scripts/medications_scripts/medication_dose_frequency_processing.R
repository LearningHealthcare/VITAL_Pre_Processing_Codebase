# medication_dose_frequency_processing.R

# This script is responsible for performing pre-processing
# on Medication Strength amount and units data.

Medication.Stength.Amount = rep(NA, times = nrow(medications.data))
Medication.Strength.Units = rep(NA, times = nrow(medications.data))

for(i in 1:nrow(medications.data)){
  medication.strength = medications.data$med_strength[i]
  # Separate Medication Strength Amount from units by splitting on white-space
  medication.strength = unlist(strsplit(medication.strength, " "))
  if(!is.na(medication.strength[1])){
    # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
    if(gsub("[^0-9.]", "", medication.strength[1]) != ""){
      medication.strength[1] = gsub("[^0-9.]", "", medication.strength[1])
    }
    Medication.Stength.Amount[i] = trimws(medication.strength[1])
  }
  # Identify Medication Strength Units string
  if(length(medication.strength) == 2){
    Medication.Strength.Units[i] = trimws(medication.strength[2])
  }else if(length(medication.strength) >= 3){
    Medication.Strength.Units[i] = paste(trimws(medication.strength[2]), trimws(medication.strength[3]), sep = "")
  }
}

medications.data = cbind.data.frame(medications.data, Medication.Stength.Amount, Medication.Strength.Units)

medications.data$Medication.Strength.Units = tolower(medications.data$Medication.Strength.Units)

medications.data = select(medications.data, -med_strength)

# Conversion of Medications Frequency numerical encodings to string-based encodings,
# based on VITAL Retrospective codebook
medications.data$med_frequency[medications.data$med_frequency == 1] = "PRN"
medications.data$med_frequency[medications.data$med_frequency == 2] = "Daily"
medications.data$med_frequency[medications.data$med_frequency == 3] = "Once"
medications.data$med_frequency[medications.data$med_frequency == 4] = "Q12H"
medications.data$med_frequency[medications.data$med_frequency == 5] = "QPM"
medications.data$med_frequency[medications.data$med_frequency == 6] = "Continuous"
medications.data$med_frequency[medications.data$med_frequency == 7] = "BID"
medications.data$med_frequency[medications.data$med_frequency == 8] = "QAM"
medications.data$med_frequency[medications.data$med_frequency == 9] = "Q8H"
medications.data$med_frequency[medications.data$med_frequency == 10] = "Once PRN"
medications.data$med_frequency[medications.data$med_frequency == 11] = "QPM PRN"
medications.data$med_frequency[medications.data$med_frequency == 12] = "TID"
medications.data$med_frequency[medications.data$med_frequency == 13] = "Every M W F"
medications.data$med_frequency[medications.data$med_frequency == 14] = "Every TU TH SA SU"
medications.data$med_frequency[medications.data$med_frequency == 15] = "Every Other Day"
medications.data$med_frequency[medications.data$med_frequency == 16] = "Every M F"
medications.data$med_frequency[medications.data$med_frequency == 17] = "Every W"
medications.data$med_frequency[medications.data$med_frequency == 18] = "Every TU TH SA"
medications.data$med_frequency[medications.data$med_frequency == 19] = "PCA"
medications.data$med_frequency[medications.data$med_frequency == 20] = "Every F"
medications.data$med_frequency[medications.data$med_frequency == 21] = "Every M"
medications.data$med_frequency[medications.data$med_frequency == 22] = "Every M W F SU"
medications.data$med_frequency[medications.data$med_frequency == 23] = "Every SA"
medications.data$med_frequency[medications.data$med_frequency == 24] = "Every SA SU"
medications.data$med_frequency[medications.data$med_frequency == 25] = "Every TU"
medications.data$med_frequency[medications.data$med_frequency == 26] = "Every TU TH SU"
medications.data$med_frequency[medications.data$med_frequency == 27] = "Q4H PRN"
medications.data$med_frequency[medications.data$med_frequency == 28] = "Q6H PRN"
medications.data$med_frequency[medications.data$med_frequency == 29] = "BID PRN"
medications.data$med_frequency[medications.data$med_frequency == 30] = "Continuous PRN"
medications.data$med_frequency[medications.data$med_frequency == 31] = "Every M TH"
medications.data$med_frequency[medications.data$med_frequency == 32] = "Every TH"
medications.data$med_frequency[medications.data$med_frequency == 33] = "Every TU TH"
medications.data$med_frequency[medications.data$med_frequency == 34] = "Every TU W F"
medications.data$med_frequency[medications.data$med_frequency == 35] = "Every W SU"
medications.data$med_frequency[medications.data$med_frequency == 36] = "Once PRN, May Repeat X1"
medications.data$med_frequency[medications.data$med_frequency == 37] = "Q1H"
medications.data$med_frequency[medications.data$med_frequency == 38] = "Weekly"