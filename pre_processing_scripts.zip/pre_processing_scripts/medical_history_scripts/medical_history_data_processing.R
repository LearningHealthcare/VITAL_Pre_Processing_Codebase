# medical_history_data_processing.R

# This script serves as the overarching script for pre-processing medical history
# data derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# medical history data I/O
medical.history.data = read.csv(medical.history.file.name, 
                                stringsAsFactors = FALSE, header = TRUE)

medical.history.data = select(medical.history.data, -redcap_repeat_instrument,
-redcap_repeat_instance)

# Dataframe containing thrombophilia medical history data
thrombophilia.medical.history.data = medical.history.data %>%
  select(record_id, lupus, anticardio, prothrombin, proteinc, proteins, antithrombin,
       homocyst, factorviii, fibrinogen, g20210a, factorv, factorvtype) %>%
  gather(Factor, Factor.Value, -record_id, -factorvtype) %>%
  mutate(Factor.Encoding = ifelse(Factor.Value == 1, "Positive",
         ifelse(Factor.Value == 2, "Negative", 
         ifelse(Factor.Value == 3, "Not Tested", NA)))) %>%
  select(-Factor.Value) %>%
  spread(Factor, Factor.Encoding) %>%
  mutate(Factor.V.Type = ifelse(factorvtype == 1, "Heterozygous",
         ifelse(factorvtype == 2, "Homozygous", NA))) %>%
  select(-factorvtype)

source(paste(medical.history.code.directory, 'outside_venous_procedure_medical_history_pre_processing.R', sep = '/'))

source(paste(medical.history.code.directory, 'venous_medical_history_pre_processing.R', sep = '/'))

source(paste(medical.history.code.directory, 'other_medical_history_pre_processing.R', sep = '/'))

source(paste(medical.history.code.directory, 'free_up_memory_medical_history_data.R', sep = '/'))