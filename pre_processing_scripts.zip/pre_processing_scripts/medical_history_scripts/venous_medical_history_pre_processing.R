# venous_medical_history_pre_processing.R

# This script performs pre-processing on the venous medical history data
# derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing venous medical history data
venous.medical.history.data = medical.history.data %>%
  filter(venous_med_history___1 == 1 | venous_med_history___2 == 1 | venous_med_history___3 == 1) %>%
  select(record_id, varicocele_date, venous_med_history___1, venous_med_history___2, venous_med_history___3, 
         varicocele_notes, malignancy_diagnosis, malignancy_remission, malignancy_type, malignancy_notes) %>%
  mutate(May.Thurner.Status = ifelse(venous_med_history___1 == 1, "Yes", NA)) %>%
  mutate(Varicocele.Status = ifelse(venous_med_history___2 == 1, "Yes", NA)) %>%
  mutate(Malignancy.Status = ifelse(venous_med_history___3 == 1, "Yes", NA)) %>%
  select(-venous_med_history___1, -venous_med_history___2, -venous_med_history___3)

venous.medical.history.data$malignancy_remission[venous.medical.history.data$malignancy_remission == "?"] = ""

# Dataframe containing venous medical history date data
venous.medical.history.dates.data = venous.medical.history.data %>%
  select(-varicocele_notes, -malignancy_type, -malignancy_notes, 
         -May.Thurner.Status, -Varicocele.Status, -Malignancy.Status) %>%
  gather(Date.Type, Date, -record_id) %>%
  # Remove missing Date-time entries
  filter(!is.na(Date) & Date != "")

for(i in 1:nrow(venous.medical.history.dates.data)){
  venous.medical.history.date = venous.medical.history.dates.data$Date[i]
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  if(gsub("[^0-9]", "", venous.medical.history.date) == ""){
    venous.medical.history.dates.data$Date[i] = ""
  }else{
    # Separate multiple medical history dates by splitting on a semi-colon
    venous.medical.history.date = unlist(strsplit(venous.medical.history.date, ";"))
    venous.medical.history.dates.data$Date[i] = venous.medical.history.date[1]
  }
}

# Remove missing/improper format date-time entries
venous.medical.history.dates.data = filter(venous.medical.history.dates.data, Date != "")

venous.medical.history.dates.data$Date = trimws(venous.medical.history.dates.data$Date)

source(paste(medical.history.code.directory, 'determine_venous_medical_history_datetime_format.R', sep = '/'))

source(paste(medical.history.code.directory, 'create_complete_venous_medical_history_date_time_string.R', sep = '/'))

source(paste(medical.history.code.directory, 'standardize_venous_medical_history_date_time_strings.R', sep = '/'))

# Combine Venous medical history date-time data with non date-time data
venous.medical.history.data = venous.medical.history.data %>%
  select(-varicocele_date, -malignancy_diagnosis, -malignancy_remission) %>%
  left_join(venous.medical.history.dates.data, by = "record_id")