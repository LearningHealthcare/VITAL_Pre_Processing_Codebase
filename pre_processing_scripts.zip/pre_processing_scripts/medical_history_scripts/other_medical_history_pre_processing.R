# other_medical_history_pre_processing.R

# This script performs pre-processing on other medical history data (Radiation, Pelvic Surgery,
# Groin Surgery etc.) derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing other medical history data
other.medical.history.data = medical.history.data %>%
  filter(other_medhistory___1 == 1 | other_medhistory___2 == 1 | other_medhistory___3 == 1) %>%
  select(record_id, other_medhistory___1, other_medhistory___2, other_medhistory___3, radiation_date,
         radiation_notes, pelvicsurg_date, pelvicsurg_notes, groinsurg_date, groinsurg_notes) %>%
  mutate(Radiation.Status = ifelse(other_medhistory___1 == 1, "Yes", NA)) %>%
  mutate(Pelvic.Surgery.Status = ifelse(other_medhistory___2 == 1, "Yes", NA)) %>%
  mutate(Groin.Surgery.Status = ifelse(other_medhistory___3 == 1, "Yes", NA)) %>%
  select(-other_medhistory___1, -other_medhistory___2, -other_medhistory___3)

# Dataframe containing other medical history date data
other.medical.history.dates.data = other.medical.history.data %>%
  select(record_id, radiation_date, pelvicsurg_date, groinsurg_date) %>%
  gather(Date.Type, Date, -record_id) %>%
  filter(!is.na(Date) & Date != "")

for(i in 1:nrow(other.medical.history.dates.data)){
  other.medical.history.date = other.medical.history.dates.data$Date[i]
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  if(gsub("[^0-9]", "", other.medical.history.date) == ""){
    other.medical.history.dates.data$Date[i] = ""
  }else{
    # Separate multiple medical history dates by splitting on a semi-colon
    other.medical.history.date = unlist(strsplit(other.medical.history.date, ";"))
    other.medical.history.dates.data$Date[i] = other.medical.history.date[1]
  }
}

# Remove missing/improper format date-time entries
other.medical.history.dates.data = filter(other.medical.history.dates.data, Date != "") 

other.medical.history.dates.data$Date = trimws(other.medical.history.dates.data$Date)

source(paste(medical.history.code.directory, 'determine_other_medical_history_datetime_format.R', sep = '/'))

source(paste(medical.history.code.directory, 'create_complete_other_medical_history_date_time_string.R', sep = '/'))

source(paste(medical.history.code.directory, 'standardize_other_medical_history_date_time_strings.R', sep = '/'))

# Combine other medical history date-time data with non date-time data
other.medical.history.data = other.medical.history.data %>%
  select(-radiation_date, -pelvicsurg_date, -groinsurg_date) %>%
  left_join(other.medical.history.dates.data, by = "record_id")