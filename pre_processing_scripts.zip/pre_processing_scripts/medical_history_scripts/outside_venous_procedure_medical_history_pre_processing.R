# outside_venous_procedure_medical_history_pre_processing.R

# This script performs pre-processing on outside venous procedure medical history data
# derived from the VITAL Retrospective database.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

source(paste(medical.history.code.directory, 'outside_venous_procedures_dates_processing.R', sep = '/'))

source(paste(medical.history.code.directory, 'outside_venous_procedures_procedure_type_details_pre_processing.R', 
            sep = '/'))

# Combine outside venous procedure date-time data with non date-time data 
outside.venous.procedure.medical.history.data = medical.history.data %>%
  filter(outside_venous == 1) %>%
  select(record_id, outside_venous_num) %>%
  left_join(medical.history.outside.venous.procedures.dates, by = "record_id") %>%
  left_join(outside.venous.procedure.type.data, by = "record_id") %>%
  left_join(outside.venous.procedure.other.procedure.names, by = "record_id") %>%
  left_join(outside.venous.procedure.details, by = "record_id")
