# determine_venous_medical_history_datetime_format.R

# This script identifies the date-time format of a medical history date entry.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

num.dashes = rep(0, times = nrow(venous.medical.history.dates.data))

num.backslashes = rep(0, times = nrow(venous.medical.history.dates.data))

# Identify number of dashes or backlashes in date-time entry (i.e. 01-01-2000, or 01/01/2000)
for(i in 1:nrow(venous.medical.history.dates.data)){
  num.dashes[i] = length(unlist(strsplit(venous.medical.history.dates.data$Date[i], split = "-")))
  num.backslashes[i] = length(unlist(strsplit(venous.medical.history.dates.data$Date[i], split = "/")))
}

month.status = rep("", times = nrow(venous.medical.history.dates.data))
month.value = rep("", nrow(venous.medical.history.dates.data))
year.value = rep("", nrow(venous.medical.history.dates.data))

# Check whether month name is present in date-time entry
month.status[grepl("January", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Jan", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("February", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Feb", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("March", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Mar", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("April", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Apr", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("May", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("June", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Jun", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("July", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Jul", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("August", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Aug", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("September", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Sep", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("October", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Oct", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("November", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Nov", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("December", venous.medical.history.dates.data$Date) == TRUE] = "Yes"
month.status[grepl("Dec", venous.medical.history.dates.data$Date) == TRUE] = "Yes"

for(i in 1:nrow(venous.medical.history.dates.data)){
  if(num.dashes[i] != 3 & num.backslashes[i] != 3){
    # Checks if date is given as month space year (i.e. January 2000)
    if(month.status[i] == "Yes"){
      month.year.potential.value = venous.medical.history.dates.data$Date[i]
      # Split month and year
      month.year.values = unlist(strsplit(month.year.potential.value, split = "\\s+"))
      month.value[i] = month.year.values[1]
      if(length(month.year.values) == 2){
        year.potential.value = month.year.values[2]
        year.potential.value = trimws(year.potential.value)
        # Verify year is in proper format (4 numeric characters within time period covered by the VITAL Retrospective Database)
        if(nchar(year.potential.value) == 4 & year.potential.value == gsub("[^0-9]", "", year.potential.value)){
          if(as.integer(year.potential.value) >= initial.medical.history.year & as.integer(year.potential.value) <= year(Sys.Date())){
            year.value[i] = year.potential.value
          }
        }
      }
    # Checks if date given as year (i.e. 2000)
    }else{
      year.potential.value = venous.medical.history.dates.data$Date[i]
      # Verify year is in proper format (4 numeric characters within time period covered by the VITAL Retrospective Database)
      if(nchar(year.potential.value) == 4 & year.potential.value == gsub("[^0-9]", "", year.potential.value)){
        if(as.integer(year.potential.value) >= initial.medical.history.year & as.integer(year.potential.value) <= year(Sys.Date())){
          year.value[i] = year.potential.value
        }
      }
    }
  }
}