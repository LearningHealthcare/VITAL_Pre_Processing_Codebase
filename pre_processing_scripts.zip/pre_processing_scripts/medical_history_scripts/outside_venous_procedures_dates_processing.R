# outside_venous_procedures_dates_processing.R

# This script performs pre-processing on outside venous procedures date-time data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Dataframe containing outside venous procedures datetime data
medical.history.outside.venous.procedures.dates = medical.history.data %>%
  select(record_id, outside_venous_date_1, 
         outside_venous_date_2, outside_venous_date_3, outside_venous_date_4, outside_venous_date_5,
         outside_venous_date_6, outside_venous_date_7, outside_venous_date_8, outside_venous_date_9,
         outside_venous_date_10) %>%
  gather(Date.Type, Date, -record_id) %>%
  filter(!is.na(Date) & Date != "")

for(i in 1:nrow(medical.history.outside.venous.procedures.dates)){
  medical.history.date = medical.history.outside.venous.procedures.dates$Date[i]
  # See citation in standalone angioplasty procedure script regarding removing non-numeric characters from strings in R
  if(gsub("[^0-9]", "", medical.history.date) == ""){
    medical.history.outside.venous.procedures.dates$Date[i] = ""
  }else{
    # Separate multiple medical history dates by splitting on a semi-colon
    medical.history.date = unlist(strsplit(medical.history.date, ";"))
    medical.history.outside.venous.procedures.dates$Date[i] = medical.history.date[1]
  }
}

# Remove missing/improper format date-time entries
medical.history.outside.venous.procedures.dates = filter(medical.history.outside.venous.procedures.dates, Date != "")

medical.history.outside.venous.procedures.dates$Date = trimws(medical.history.outside.venous.procedures.dates$Date)

source(paste(medical.history.code.directory, 'determine_outside_venous_procedure_datetime_format.R', sep = '/'))

source(paste(medical.history.code.directory, 'create_complete_outside_venous_procedure_date_time_string.R', sep = '/'))

source(paste(medical.history.code.directory, 'standardize_outside_venous_procedure_date_time_strings.R', sep = '/'))