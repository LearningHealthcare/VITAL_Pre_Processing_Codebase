# standardize_outside_venous_procedure_date_time_strings.R

# This script standardizes the format of an Outside Venous Procedure Medical History date-time entry, based on one of five possible input formats.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Example of Date in specified format: 2000-01-31
outside.venous.procedure.date.first.format = as.Date(medical.history.outside.venous.procedures.dates$Date.Value, format = '%Y-%m-%d')
# Example of Date in specified format: 01-31-2000
outside.venous.procedure.date.second.format = as.Date(medical.history.outside.venous.procedures.dates$Date.Value, format = '%m-%d-%Y')
# Example of Date in specified format: 01-31-00
outside.venous.procedure.date.third.format = as.Date(medical.history.outside.venous.procedures.dates$Date.Value, format = '%m-%d-%y')
# Example of Date in specified format: 01/31/2000
outside.venous.procedure.date.fourth.format = as.Date(medical.history.outside.venous.procedures.dates$Date.Value, format = '%m/%d/%Y')
# Example of Date in specified format: 01/31/00
outside.venous.procedure.date.fifth.format = as.Date(medical.history.outside.venous.procedures.dates$Date.Value, format = '%m/%d/%y')

outside.venous.procedure.date = rep("", times = nrow(medical.history.outside.venous.procedures.dates))

for(i in 1:length(outside.venous.procedure.date)){
  num.dashes = unlist(strsplit(medical.history.outside.venous.procedures.dates$Date.Value[i], split = '-'))
  # Checks if month, day and year are separated by dashes
  if(length(num.dashes) == 3){
    # Identification of one of date-time formats above using dashes (Examples #1-#3)
    potential.date = outside.venous.procedure.date.second.format[i]
    if(is.na(potential.date) | year(potential.date) < initial.medical.history.year | year(potential.date) > year(Sys.Date())){
      potential.date = outside.venous.procedure.date.first.format[i]
      if(is.na(potential.date) | year(potential.date) < initial.medical.history.year | year(potential.date) > year(Sys.Date())){
        potential.date = outside.venous.procedure.date.third.format[i]
        if(!is.na(potential.date) & year(potential.date) >= initial.medical.history.year & year(potential.date) <= year(Sys.Date())){
          outside.venous.procedure.date[i] = as.character(potential.date)
        }
      }else{
        outside.venous.procedure.date[i] = as.character(potential.date)
      }
    }else{
      outside.venous.procedure.date[i] = as.character(potential.date)
    }
  # Checks if month, day and year are separated by backslashes
  }else if(length(num.dashes) == 1){
    # Identification of one of date-time formats above using backslashes (Examples #4-#5)
    potential.date = outside.venous.procedure.date.fourth.format[i]
    if(is.na(potential.date) | year(potential.date) < initial.medical.history.year | year(potential.date) > year(Sys.Date())){
      potential.date = outside.venous.procedure.date.fifth.format[i]
      if(!is.na(potential.date) & year(potential.date) >= initial.medical.history.year & year(potential.date) <= year(Sys.Date())){
        outside.venous.procedure.date[i] = as.character(potential.date)
      }
    }else{
      outside.venous.procedure.date[i] = as.character(potential.date)
    }
  }
}

medical.history.outside.venous.procedures.dates$Date.Value = outside.venous.procedure.date

# Remove date-times without proper format/missing datetimes
medical.history.outside.venous.procedures.dates = filter(medical.history.outside.venous.procedures.dates, Date.Value != "")

medical.history.outside.venous.procedures.dates = spread(medical.history.outside.venous.procedures.dates, Date.Type, Date.Value)