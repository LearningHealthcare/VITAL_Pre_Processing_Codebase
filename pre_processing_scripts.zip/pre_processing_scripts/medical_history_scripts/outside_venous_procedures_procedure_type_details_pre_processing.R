# outside_venous_procedures_procedure_type_details_pre_processing.R

# This script performs additional, non date-time pre-processing on outside venous procedures 
# medical history data.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Create list of procedure names by outside venous procedure number, in order to efficiently select columns
# containing outside venous procedure data
outside.venous.procedure.number = seq(1, max.outside.procedures)
outside.venous.procedure.types = seq(1, num.outside.procedure.types)
outside.venous.procedure.names = paste(rep("outside_venous_procedure", 
  times = length(outside.venous.procedure.number)), outside.venous.procedure.number, sep = "_")
outside.venous.procedure.names = as.vector(outer(outside.venous.procedure.names, 
  outside.venous.procedure.types, paste, sep = "___"))
outside.venous.procedure.names = c("record_id", outside.venous.procedure.names)

# Create new, string-based column names, for the various types of Outside Venous procedures
outside.venous.procedures.new.names = paste(rep("Outside.Venous.Procedure", times = length(outside.venous.procedure.number)),
                                                outside.venous.procedure.number, sep = ".")
outside.venous.procedure.type.names = c("Venous.Stenting", "Venoplasty", "IVC.Filter.Placement", "Successful.IVC.Filter.Removal",
  "Unsuccessful.IVC.Filter.Removal", "Thromoblysis", "Thrombectomy", "Ovarian.Vein.Embolization.Ablation", "GSV.Ablation", "Vein.Scelrosis",
  "Ligation.Stripping.Veins", "Other.Venous.Procedure", "Recanalization")
outside.venous.procedures.new.names = as.vector(outer(outside.venous.procedures.new.names, outside.venous.procedure.type.names, paste, sep = "."))
outside.venous.procedures.new.names = paste(outside.venous.procedures.new.names, rep("Status", 
  times = length(outside.venous.procedures.new.names)), sep = ".")
outside.venous.procedures.new.names = c("record_id", outside.venous.procedures.new.names)

outside.venous.procedure.type.data = select(medical.history.data, outside.venous.procedure.names)

# Assign string-based procedure type names as columns to outside venous procedure type dataframe
names(outside.venous.procedure.type.data) = outside.venous.procedures.new.names

# Dataframe containing outside venous procedure type data
outside.venous.procedure.type.data = outside.venous.procedure.type.data %>%
  gather(Procedure.Type, Encoding, -record_id) %>%
  mutate(Status = ifelse(Encoding == 1, "Yes", NA)) %>%
  select(-Encoding) %>%
  spread(Procedure.Type, Status)

# Dataframe containing outside venous procedure name data
outside.venous.procedure.other.procedure.names = select(medical.history.data, record_id, outside_venous_other_1, outside_venous_other_2,
  outside_venous_other_3, outside_venous_other_4, outside_venous_other_5, outside_venous_other_6, outside_venous_other_7, 
  outside_venous_other_8, outside_venous_other_9, outside_venous_other_10)

names(outside.venous.procedure.other.procedure.names) = c("record_id", "Outside.Venous.Procedure.1.Other.Procedure.Name", 
  "Outside.Venous.Procedure.2.Other.Procedure.Name", "Outside.Venous.Procedure.3.Other.Procedure.Name",
  "Outside.Venous.Procedure.4.Other.Procedure.Name", "Outside.Venous.Procedure.5.Other.Procedure.Name",
  "Outside.Venous.Procedure.6.Other.Procedure.Name", "Outside.Venous.Procedure.7.Other.Procedure.Name",
  "Outside.Venous.Procedure.8.Other.Procedure.Name", "Outside.Venous.Procedure.9.Other.Procedure.Name",
  "Outside.Venous.Procedure.10.Other.Procedure.Name")

# Dataframe containing outside venous procedure details data
outside.venous.procedure.details = select(medical.history.data, record_id, outside_venous_details_1, outside_venous_details_2, 
  outside_venous_details_3,outside_venous_details_4, outside_venous_details_5, outside_venous_details_6, outside_venous_details_7, 
  outside_venous_details_8, outside_venous_details_9, outside_venous_details_10)

names(outside.venous.procedure.details) = c("record_id", "Outside.Venous.Procedure.1.Details", "Outside.Venous.Procedure.2.Details",
  "Outside.Venous.Procedure.3.Details", "Outside.Venous.Procedure.4.Details", "Outside.Venous.Procedure.5.Details", 
  "Outside.Venous.Procedure.6.Details", "Outside.Venous.Procedure.7.Details", "Outside.Venous.Procedure.8.Details",
  "Outside.Venous.Procedure.9.Details", "Outside.Venous.Procedure.10.Details")