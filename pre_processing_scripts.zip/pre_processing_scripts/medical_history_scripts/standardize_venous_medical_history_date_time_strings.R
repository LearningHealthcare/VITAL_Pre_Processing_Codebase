# standardize_venous_medical_history_date_time_strings.R

# This script standardizes the format of a venous medical history date-time entry, based on one of five possible input formats.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

# Example of Date in specified format: 2000-01-31
venous.medical.history.date.first.format = as.Date(venous.medical.history.dates.data$Date.Value, format = '%Y-%m-%d')
# Example of Date in specified format: 01-31-2000
venous.medical.history.date.second.format = as.Date(venous.medical.history.dates.data$Date.Value, format = '%m-%d-%Y')
# Example of Date in specified format: 01-31-00
venous.medical.history.date.third.format = as.Date(venous.medical.history.dates.data$Date.Value, format = '%m-%d-%y')
# Example of Date in specified format: 01/31/2000
venous.medical.history.date.fourth.format = as.Date(venous.medical.history.dates.data$Date.Value, format = '%m/%d/%Y')
# Example of Date in specified format: 01/31/00
venous.medical.history.date.fifth.format = as.Date(venous.medical.history.dates.data$Date.Value, format = '%m/%d/%y')

venous.medical.history.date = rep("", times = nrow(venous.medical.history.dates.data))

for(i in 1:length(venous.medical.history.date)){
  num.dashes = unlist(strsplit(venous.medical.history.dates.data$Date.Value[i], split = '-'))
  # Checks if month, day and year are separated by dashes
  if(length(num.dashes) == 3){
    # Identification of one of date-time formats above using dashes (Examples #1-#3)
    potential.date = venous.medical.history.date.second.format[i]
    if(is.na(potential.date) | year(potential.date) < initial.medical.history.year | year(potential.date) > year(Sys.Date())){
      potential.date = venous.medical.history.date.first.format[i]
      if(is.na(potential.date) | year(potential.date) < initial.medical.history.year | year(potential.date) > year(Sys.Date())){
        potential.date = venous.medical.history.date.third.format[i]
        if(!is.na(potential.date) & year(potential.date) >= initial.medical.history.year & year(potential.date) <= year(Sys.Date())){
          venous.medical.history.date[i] = as.character(potential.date)
        }
      }else{
        venous.medical.history.date[i] = as.character(potential.date)
      }
    }else{
      venous.medical.history.date[i] = as.character(potential.date)
    }
  # Checks if month, day and year are separated by backslashes
  }else if(length(num.dashes) == 1){
    # Identification of one of date-time formats above using backslashes (Examples #4-#5)
    potential.date = venous.medical.history.date.fourth.format[i]
    if(is.na(potential.date) | year(potential.date) < initial.medical.history.year | year(potential.date) > year(Sys.Date())){
      potential.date = venous.medical.history.date.fifth.format[i]
      if(!is.na(potential.date) & year(potential.date) >= initial.medical.history.year & year(potential.date) <= year(Sys.Date())){
        venous.medical.history.date[i] = as.character(potential.date)
      }
    }else{
      venous.medical.history.date[i] = as.character(potential.date)
    }
  }
}

venous.medical.history.dates.data$Date.Value = venous.medical.history.date

# Remove date-times without proper format/missing datetimes
venous.medical.history.dates.data = filter(venous.medical.history.dates.data, Date.Value != "")

venous.medical.history.dates.data = spread(venous.medical.history.dates.data, Date.Type, Date.Value)