# determine_outside_venous_procedure_datetime_format.R

# This script identifies the date-time format of a medical history date entry.

# By David Cohn

# Rubin and Hofmann Labs, July 2018

num.dashes = rep(0, times = nrow(medical.history.outside.venous.procedures.dates))

num.backslashes = rep(0, times = nrow(medical.history.outside.venous.procedures.dates))

# Identify number of dashes or backlashes in date-time entry (i.e. 01-01-2000, or 01/01/2000)
for(i in 1:nrow(medical.history.outside.venous.procedures.dates)){
  num.dashes[i] = length(unlist(strsplit(medical.history.outside.venous.procedures.dates$Date[i], split = "-")))
  num.backslashes[i] = length(unlist(strsplit(medical.history.outside.venous.procedures.dates$Date[i], split = "/")))
}

month.status = rep("", times = nrow(medical.history.outside.venous.procedures.dates))
month.value = rep("", nrow(medical.history.outside.venous.procedures.dates))
year.value = rep("", nrow(medical.history.outside.venous.procedures.dates))

# Check whether month name is present in date-time entry
month.status[grepl("January", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("Jan", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("February", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("Feb", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("March", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("Mar", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("April", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("Apr", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("May", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("June", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("Jun", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("July", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("Jul", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("August", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("Aug", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("September", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("Sep", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("October", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("Oct", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("November", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("Nov", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("December", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"
month.status[grepl("Dec", medical.history.outside.venous.procedures.dates$Date) == TRUE] = "Yes"

for(i in 1:nrow(medical.history.outside.venous.procedures.dates)){
  if(num.dashes[i] != 3 & num.backslashes[i] != 3){
    # Checks if date is given as month space year (i.e. January 2000)
    if(month.status[i] == "Yes"){
      month.year.potential.value = medical.history.outside.venous.procedures.dates$Date[i]
      # Split month and year
      month.year.values = unlist(strsplit(month.year.potential.value, split = "\\s+"))
      month.value[i] = month.year.values[1]
      if(length(month.year.values) == 2){
        year.potential.value = month.year.values[2]
        year.potential.value = trimws(year.potential.value)
        # Verify year is in proper format (4 numeric characters within time period covered by the VITAL Retrospective Database)
        if(nchar(year.potential.value) == 4 & year.potential.value == gsub("[^0-9]", "", year.potential.value)){
          if(as.integer(year.potential.value) >= initial.medical.history.year & as.integer(year.potential.value) <= year(Sys.Date())){
            year.value[i] = year.potential.value
          }
        }
      }
    # Checks if date given as year (i.e. 2000)
    }else{
      year.potential.value = medical.history.outside.venous.procedures.dates$Date[i]
      # Verify year is in proper format (4 numeric characters within time period covered by the VITAL Retrospective Database)
      if(nchar(year.potential.value) == 4 & year.potential.value == gsub("[^0-9]", "", year.potential.value)){
        if(as.integer(year.potential.value) >= initial.medical.history.year & as.integer(year.potential.value) <= year(Sys.Date())){
          year.value[i] = year.potential.value
        }
      }
    }
  }
}